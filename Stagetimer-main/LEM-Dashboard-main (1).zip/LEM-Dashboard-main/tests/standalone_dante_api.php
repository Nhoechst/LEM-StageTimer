<?php

declare(strict_types=1);

// Run a real API instance against a disposable, project-local fixture, never deployed data.
$fixture = __DIR__ . '/.dante-api-' . getmypid();
$process = null;
function verify(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}
function removeFixture(string $directory): void
{
    foreach (scandir($directory) as $name) {
        if ($name === '.' || $name === '..') {
            continue;
        }
        $path = $directory . '/' . $name;
        if (is_dir($path)) {
            removeFixture($path);
        } else {
            unlink($path);
        }
    }
    rmdir($directory);
}

try {
    mkdir($fixture);
    mkdir($fixture . '/src');
    mkdir($fixture . '/config');
    foreach (glob(dirname(__DIR__) . '/src/*.php') as $source) {
        copy($source, $fixture . '/src/' . basename($source));
    }
    copy(dirname(__DIR__) . '/api.php', $fixture . '/api.php');
    $listener = stream_socket_server('tcp://127.0.0.1:0', $errno, $error);
    verify($listener !== false, 'Cannot reserve an API test port.');
    $address = stream_socket_get_name($listener, false);
    fclose($listener);
    $config = [
        'database' => $fixture . '/dashboard.db',
        'header_devices' => [], 'rate_limits' => [], 'manual_check_cooldown_seconds' => 0,
        'corporate_networks' => ['10.0.0.0/8'], 'external_networks' => ['127.0.0.0/8'],
        'ping' => ['method' => 'tcp', 'timeout_seconds' => 1, 'tcp_ports' => [(int) substr(strrchr($address, ':'), 1)]],
    ];
    file_put_contents($fixture . '/config/config.php', '<?php return ' . var_export($config, true) . ';');
    $process = proc_open([PHP_BINARY, '-d', 'session.save_path=' . $fixture, '-S', $address, '-t', $fixture],
        [0 => ['pipe', 'r'], 1 => ['file', $fixture . '/server.log', 'a'], 2 => ['file', $fixture . '/server.log', 'a']], $pipes);
    verify(is_resource($process), 'Cannot start PHP API test server.');
    fclose($pipes[0]);
    $ready = false;
    for ($i = 0; $i < 100; $i++) {
        $socket = @stream_socket_client('tcp://' . $address, $errno, $error, 0.1);
        if ($socket !== false) {
            fclose($socket);
            $ready = true;
            break;
        }
        usleep(20000);
    }
    verify($ready, 'API test server did not become responsive.');
    $cookie = '';
    $csrf = '';
    $request = static function (string $action, ?array $body = null, ?string $token = null) use ($address, &$cookie, &$csrf): array {
        $headers = ['Content-Type: application/json', 'X-Lang: en'];
        if ($cookie !== '') {
            $headers[] = 'Cookie: ' . $cookie;
        }
        if ($body !== null) {
            $headers[] = 'X-CSRF-Token: ' . ($token ?? $csrf);
        }
        $context = stream_context_create(['http' => [
            'method' => $body === null ? 'GET' : 'POST',
            'header' => implode("\r\n", $headers),
            'content' => $body === null ? '' : json_encode($body),
            'ignore_errors' => true, 'timeout' => 15,
        ]]);
        $response = file_get_contents('http://' . $address . '/api.php?action=' . $action, false, $context);
        foreach ($http_response_header as $header) {
            if (preg_match('/^Set-Cookie: ([^;]+)/i', $header, $match)) {
                $cookie = $match[1];
            }
        }
        $decoded = json_decode($response, true, 512, JSON_THROW_ON_ERROR);
        if (isset($decoded['state']['csrf'])) {
            $csrf = $decoded['state']['csrf'];
        }
        preg_match('/\s(\d{3})\s/', $http_response_header[0], $status);
        return [(int) $status[1], $decoded];
    };
    [$status] = $request('state');
    verify($status === 200, 'Anonymous state must remain readable.');
    verify($request('traffic_usage')[0] === 401, 'Anonymous viewers must not read traffic usage.');
    verify($request('discovery_log')[0] === 401, 'Anonymous viewers must not read shared discovery snapshots.');
    verify($request('check', ['site_id' => 1])[0] === 401, 'Anonymous visitors must not be able to initiate status checks.');
    $input = ['name' => 'Audio 127.0.0.1', 'ip' => 'http://127.0.0.1:' . substr(strrchr($address, ':'), 1),
        'ownership' => 'standalone', 'type' => 'Dante', 'site_id' => 0, 'team' => 'de'];
    verify($request('save_device', $input)[0] === 401, 'Anonymous viewers must not create Dante devices.');
    verify($request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => true])[0] === 401, 'Anonymous viewers must not change exemptions.');
    $password = bin2hex(random_bytes(16));
    verify($request('setup', ['username' => 'Admin', 'password' => $password])[0] === 200, 'First-run admin setup must work.');
    $loginDb = new PDO('sqlite:' . $fixture . '/dashboard.db');
    $lastLogin = static fn (string $name) => $loginDb->query('SELECT last_login FROM users WHERE username = ' . $loginDb->quote($name))->fetchColumn();
    verify((int) $lastLogin('Admin') > 0, 'First-run setup must record the initial successful login.');
    $loginDb->exec("UPDATE users SET last_login = 1 WHERE username = 'Admin'");
    verify($request('change_password', ['current' => $password, 'password' => $password])[0] === 200
        && (int) $lastLogin('Admin') === 1, 'Password changes must not count as another login.');
    [$usageStatus, $usageResponse] = $request('traffic_usage');
    verify($usageStatus === 200 && isset($usageResponse['usage']['hours'], $usageResponse['usage']['totals'])
        && $usageResponse['usage']['totals']['24h']['requests'] >= 2,
        'Admins must be able to read traffic history collected from prior API requests.');
    verify($request('save_device', $input, 'invalid-csrf')[0] === 403, 'Dante writes must require CSRF.');
    [$status, $response] = $request('save_device', $input);
    $id = $response['result']['id'];
    verify($status === 200 && $response['state']['sites'] === [] && count($response['state']['devices']) === 1, 'Adding Dante without any locations must work.');
    $device = $response['state']['devices'][0];
    verify($device['ip'] === '127.0.0.1' && $device['status'] === 'unknown' && $device['team'] === 'de', 'Authenticated data must preserve address/team and bypass external CIDRs.');
    verify($request('save_site', ['name' => 'Studio', 'team' => 'us'])[0] === 200, 'Location creation must remain supported.');
    verify($request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => true], 'invalid-csrf')[0] === 403, 'Exemption writes must require CSRF.');
    verify($request('set_firmware_exemption', ['model' => '', 'exempt' => true])[0] === 422, 'Empty exempt model names must be rejected.');
    verify($request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => 'yes'])[0] === 422, 'Exempt flags must be booleans.');
    verify($request('save_device', ['id' => $id, 'model' => 'Audio box', 'firmware' => 'Product v1.2.0'] + $input)[0] === 200, 'Firmware test device must be editable.');
    [$status, $response] = $request('save_firmware', ['model' => 'Audio box', 'approved' => '1.3']);
    verify($status === 200 && $response['state']['devices'][0]['compliance'] === 'non_compliant', 'Older normalized firmware must be non-compliant.');
    [$status, $response] = $request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => true]);
    verify($status === 200 && $response['state']['devices'][0]['compliance'] === 'compliant'
        && $response['state']['devices'][0]['firmware_exempt']
        && $response['state']['config']['firmware_exemptions'] === ['Audio box'], 'Adding exemptions must immediately recompute state and expose the saved list.');
    [$status, $response] = $request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => false]);
    verify($status === 200 && $response['state']['devices'][0]['compliance'] === 'non_compliant'
        && !$response['state']['devices'][0]['firmware_exempt'], 'Removing exemptions must immediately restore the normal result.');
    [$status, $response] = $request('save_device', ['name' => 'Location audio', 'site_id' => 2, 'type' => 'Dante', 'ip' => '127.0.0.1']);
    verify($status === 200 && count($response['state']['devices']) === 2, 'Location Dante must coexist with standalone Dante at the same address.');
    $locationId = $response['result']['id'];
    [$status, $response] = $request('check', ['site_id' => 2, 'device_id' => $locationId]);
    verify($status === 200 && $response['result']['checked'] === 0, 'A single location device can be checked without checking other devices; external targets remain excluded.');
    verify($request('check', ['site_id' => 2, 'device_id' => $id])[0] === 422, 'Single-device checks must reject devices belonging to another location.');
    verify($request('check', ['site_id' => 2, 'device_id' => -1])[0] === 422, 'Single-device checks must reject invalid device IDs instead of checking the whole location.');
    [$status, $response] = $request('check', ['target' => 'standalone', 'team' => 'us']);
    verify($status === 200 && $response['result']['checked'] === 0, 'Standalone checks must respect country ownership.');
    [$status, $response] = $request('check', ['target' => 'standalone', 'team' => 'de']);
    verify($status === 200 && $response['result']['checked'] === 1 && $response['result']['online'] === 1, 'Standalone loopback must be checked despite external/corporate exclusions.');
    $rows = array_column($response['state']['devices'], null, 'id');
    verify($rows[$locationId]['status'] === 'external' && $rows[$locationId]['site_id'] === 2, 'Standalone checks must not alter/move location devices.');
    [$status, $response] = $request('device_history&id=' . $id);
    verify($status === 200 && $response['telemetry']['checks'] === 1, 'Standalone manual checks must record telemetry.');
    verify($request('save_device', ['id' => $id, 'site_id' => 2, 'ownership' => 'location'] + $input)[0] === 422, 'Standalone ownership cannot be changed into a location.');
    [$status, $response] = $request('save_device', ['name' => 'US audio', 'team' => 'us'] + $input);
    verify($status === 200, 'Countries may have standalone endpoints with the same address.');
    $usId = $response['result']['id'];
    $scheduled = proc_open([PHP_BINARY, '-r',
        'require ' . var_export($fixture . '/src/bootstrap.php', true)
        . '; echo json_encode(run_status_check(null, null, false, "de", "all"));'],
        [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['file', $fixture . '/server.log', 'a']], $scheduledPipes);
    verify(is_resource($scheduled), 'Cannot start the scheduled-check test.');
    fclose($scheduledPipes[0]);
    $scheduledResult = json_decode(stream_get_contents($scheduledPipes[1]), true, 512, JSON_THROW_ON_ERROR);
    fclose($scheduledPipes[1]);
    verify(proc_close($scheduled) === 0 && $scheduledResult['checked'] === 1, 'Country scheduler path must include standalone devices and exclude other countries.');
    [$status, $response] = $request('state');
    $scheduledRows = array_column($response['state']['devices'], null, 'id');
    verify($scheduledRows[$usId]['status'] === 'unknown', 'Scheduled checks must not touch another country.');
    verify($request('delete_device', ['id' => $usId])[0] === 200, 'Admin standalone delete must work.');
    $temporaryPasswords = [];
    foreach (['user', 'lead', 'admin'] as $role) {
        $name = $role === 'admin' ? 'NewAdmin' : $role;
        [$status, $response] = $request('add_user', ['username' => $name, 'role' => $role]);
        verify($status === 200, 'Admin must be able to create test roles without supplying a password.');
        $temporaryPasswords[$name] = $response['result']['temporary_password'];
        verify(strlen($temporaryPasswords[$name]) === 24 && $response['result']['username'] === $name, 'Creation must return generated credentials once.');
        verify($lastLogin($name) === null, 'Account creation must leave last login unknown.');
        [$status, $response] = $request('state');
        verify(!str_contains(json_encode($response), $temporaryPasswords[$name]), 'Subsequent state must never expose the temporary password.');
    }
    verify(count(array_unique($temporaryPasswords)) === 3, 'Each account must receive its own password.');
    verify($request('logout', [])[0] === 200, 'Logout must work.');
    $activate = static function (string $name) use ($request, $temporaryPasswords, $password): void {
        [$status, $response] = $request('login', ['username' => strtoupper($name), 'password' => $temporaryPasswords[$name]]);
        verify($status === 200 && $response['state']['auth']['must_change_password'] === true, 'Generated credentials must start a restricted session.');
        [$status, $response] = $request('state');
        verify($status === 200 && $response['state']['auth']['must_change_password'] === true
            && $response['state']['auth']['role'] === null && $response['state']['devices'] === []
            && $response['state']['sites'] === [] && $response['state']['pcs'] === []
            && !isset($response['state']['settings']) && !isset($response['state']['users']) && !isset($response['state']['profile']),
            'Reloading must preserve first-login restrictions without exposing authenticated state.');
        foreach (['export', 'traffic_usage', 'ping_usage', 'discovery_log', 'account_photo', 'user_photo', 'device_history', 'photo', 'header_status'] as $action) {
            verify($request($action)[0] === 403, 'Restricted sessions must not bypass GET gates: ' . $action);
        }
        foreach (['save_theme', 'check', 'add_user', 'save_settings', 'save_device', 'upload_account_photo', 'complete_pc_check'] as $action) {
            verify($request($action, [])[0] === 403, 'Restricted sessions must not bypass POST gates: ' . $action);
        }
        verify($request('logout', [])[0] === 200, 'Restricted sessions must be able to log out.');
        verify($request('login', ['username' => $name, 'password' => $temporaryPasswords[$name]])[0] === 200, 'Restricted login must survive logout.');
        verify($request('change_password', ['current' => $temporaryPasswords[$name], 'password' => $password], 'invalid-csrf')[0] === 403, 'First-login changes must require CSRF.');
        foreach ([[bin2hex(random_bytes(16)), $password], [$temporaryPasswords[$name], $temporaryPasswords[$name]], [$temporaryPasswords[$name], 'short']] as [$current, $next]) {
            verify($request('change_password', ['current' => $current, 'password' => $next])[0] === 422, 'Invalid password changes must be rejected.');
            verify($request('state')[1]['state']['auth']['must_change_password'] === true, 'Failed changes must not unlock the account.');
        }
        [$status, $response] = $request('change_password', ['current' => $temporaryPasswords[$name], 'password' => $password]);
        verify($status === 200 && $response['state']['auth']['must_change_password'] === false
            && count($response['state']['devices']) > 0, 'Successful changes must immediately unlock normal role-appropriate state.');
        $request('logout', []);
        verify($request('login', ['username' => $name, 'password' => $temporaryPasswords[$name]])[0] === 401, 'Old temporary credentials must stop working.');
        verify($request('login', ['username' => $name, 'password' => $password])[0] === 200, 'The new password must survive a new session.');
    };
    $activate('NewAdmin');
    verify($request('traffic_usage')[0] === 200, 'A new admin must receive admin permissions only after changing the password.');
    $request('logout', []);
    [$status, $response] = $request('state');
    verify(!isset($response['state']['users']), 'Anonymous state must not expose user login history.');
    $masked = array_column($response['state']['devices'], null, 'id')[$id];
    verify($masked['ip'] === '*******' && $masked['web_url'] === '' && !str_contains($masked['name'], '127.0.0.1'), 'Anonymous addresses/URLs/embedded title addresses must remain private.');
    verify($request('login', ['username' => 'user', 'password' => bin2hex(random_bytes(16))])[0] === 401
        && $lastLogin('user') === null, 'Failed login attempts must not record a successful login.');
    $activate('user');
    verify($request('discovery_log')[0] === 401, 'Regular users must not read shared discovery snapshots.');
    verify((int) $lastLogin('user') > 0, 'A successful case-insensitive login must be persisted.');
    verify($request('save_device', ['id' => $id] + $input)[0] === 403 && $request('delete_device', ['id' => $id])[0] === 403, 'Read-only users must not edit/delete standalone devices.');
    verify($request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => true])[0] === 403, 'Read-only users must not change exemptions.');
    $request('logout', []);
    $activate('lead');
    verify($request('discovery_log')[0] === 404, 'Leads must pass the existing permission gate before server configuration is checked.');
    [$status, $response] = $request('state');
    $listedUsers = array_column($response['state']['users'], null, 'username');
    verify(is_int($listedUsers['lead']['last_login']) && is_int($listedUsers['user']['last_login']),
        'Settings user lists must include persisted last-login timestamps.');
    verify($request('traffic_usage')[0] === 401, 'Leads must not be able to read admin-only traffic usage.');
    verify($request('add_user', ['username' => 'BlockedAdmin', 'role' => 'admin'])[0] === 403, 'Leads must not generate credentials for admin accounts.');
    verify($request('set_firmware_exemption', ['model' => 'Audio box', 'exempt' => true])[0] === 200, 'Leads must be able to manage firmware exemptions.');
    verify($request('save_device', ['id' => $id, 'name' => 'Renamed'] + $input)[0] === 200, 'Leads must be able to manage standalone devices.');
    verify($request('delete_device', ['id' => $id])[0] === 200, 'Leads must be able to delete standalone devices.');
    [$status, $response] = $request('state');
    verify(count($response['state']['devices']) === 1 && $response['state']['devices'][0]['id'] === $locationId, 'Deleting standalone must preserve existing location devices.');
    $logDevice = [
        'name' => 'Shared discovery', 'ip' => '127.0.0.1', 'log_enabled' => true,
        'ssh_user' => 'discovery', 'ssh_port' => 22, 'ssh_key' => 'fixture_key', 'ssh_auth' => 'key',
        'log_path' => '', 'log_source' => 'journal', 'log_service' => 'ndi-discovery.service',
    ];
    $saveLogDevices = $loginDb->prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    $saveLogDevices->execute(['header_devices', json_encode([$logDevice])]);
    $logSettings = $logDevice;
    unset($logSettings['name'], $logSettings['ip']);
    $logStateName = 'discovery_log:' . hash('sha256', $logDevice['ip']);
    $logFingerprint = hash('sha256', json_encode([$logDevice['ip'], $logSettings, ''], JSON_THROW_ON_ERROR));
    $snapshot = [
        'log' => ['text' => 'Shared snapshot', 'truncated' => false],
        'fingerprint' => $logFingerprint, 'checked_at' => microtime(true),
    ];
    $loginDb->prepare('INSERT OR REPLACE INTO state (name, data) VALUES (?, ?)')->execute([$logStateName, json_encode($snapshot)]);
    $logAction = 'discovery_log&server=0&host=127.0.0.1';
    [$status, $response] = $request($logAction);
    verify($status === 200 && $response['log'] === $snapshot['log'] && $response['server']['ip'] === '127.0.0.1',
        'An authorized lead must be able to reuse the shared snapshot through the real API: ' . json_encode([$status, $response]));
    verify($request('discovery_log&server=0&host=192.0.2.1')[0] === 409,
        'Cached snapshots must not bypass pinned-host configuration checks.');
    $logDevice['log_enabled'] = false;
    $saveLogDevices->execute(['header_devices', json_encode([$logDevice])]);
    verify($request($logAction)[0] === 404, 'Disabling log viewing must block even a warm snapshot.');
    $logDevice['log_enabled'] = true;
    $saveLogDevices->execute(['header_devices', json_encode([$logDevice])]);
    $request('logout', []);
    verify($request($logAction)[0] === 401, 'Anonymous viewers must not access a populated snapshot.');
    $request('login', ['username' => 'user', 'password' => $password]);
    verify($request($logAction)[0] === 401, 'Regular users must not access a populated snapshot.');
    $request('logout', []);
    $request('login', ['username' => 'Admin', 'password' => $password]);
    // Keep this cache fresh after the password-verification work above.
    $snapshot['checked_at'] = microtime(true);
    $loginDb->prepare('UPDATE state SET data = ? WHERE name = ?')->execute([json_encode($snapshot), $logStateName]);
    verify($request($logAction)[0] === 200, 'Administrators must retain access to shared snapshots.');
    echo "Standalone Dante API checks passed.\n";
} finally {
    if (is_resource($process)) {
        proc_terminate($process);
        proc_close($process);
    }
    if (is_dir($fixture)) {
        removeFixture($fixture);
    }
}
