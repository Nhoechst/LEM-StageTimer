<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\Database;
use StatusDashboard\DiscoveryLog;
use StatusDashboard\Settings;

class SnapshotDiscoveryLog extends DiscoveryLog
{
    public function __construct(private string $directory)
    {
        parent::__construct($directory . '/ssh');
    }

    public function read(array $device): array
    {
        file_put_contents($this->directory . '/reads', "read\n", FILE_APPEND | LOCK_EX);
        usleep(400000);
        if (is_file($this->directory . '/fail')) {
            throw new RuntimeException('SSH log read failed.');
        }
        return ['text' => $device['log_service'] ?? 'ndi-discovery.service', 'truncated' => false];
    }
}

if (($argv[1] ?? '') === '--snapshot-worker') {
    $directory = $argv[2];
    $device = json_decode($argv[3], true, 512, JSON_THROW_ON_ERROR);
    $db = Database::open($directory . '/dashboard.db');
    echo "ready\n";
    fgets(STDIN);
    try {
        echo json_encode(['log' => (new SnapshotDiscoveryLog($directory))->readShared($db, $device)], JSON_THROW_ON_ERROR);
    } catch (RuntimeException $e) {
        echo json_encode(['error' => $e->getMessage()], JSON_THROW_ON_ERROR);
    }
    exit;
}

function verify(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function rejectSettings(array $device): void
{
    try {
        DiscoveryLog::remoteCommand($device);
    } catch (InvalidArgumentException) {
        return;
    }
    throw new RuntimeException('Invalid discovery log settings were accepted.');
}

$device = [
    'name' => 'Discovery', 'ip' => '192.0.2.1', 'log_enabled' => true,
    'ssh_user' => 'discovery', 'ssh_auth' => 'key', 'ssh_key' => 'discovery_key',
];
$settings = DiscoveryLog::settings($device);
verify($settings['log_source'] === 'journal' && $settings['log_service'] === 'ndi-discovery.service', 'New discovery log viewers must default to the NDI service journal.');
verify(DiscoveryLog::remoteCommand($device) === "journalctl --quiet --no-pager --boot=0 --lines=200 --output=cat --unit='ndi-discovery.service'", 'Journal reads must be bounded, current-boot, plain-message snapshots, not endless follow requests.');
foreach (['ndi-discovery.service', 'ndi-discovery@studio-1.service', 'custom_discovery.service'] as $unit) {
    verify(str_ends_with(DiscoveryLog::remoteCommand(['log_service' => $unit] + $device), '--unit=' . escapeshellarg($unit)), 'The selected service must be safely quoted.');
}
foreach (['--help', 'ndi.service;id', '$(id).service', 'ndi*.service', "ndi.service\nother.service", 'ndi service', '../ndi.service', 'ndi.socket', str_repeat('a', 256) . '.service'] as $unit) {
    rejectSettings(['log_service' => $unit] + $device);
}
rejectSettings(['log_source' => 'command'] + $device);
rejectSettings(['log_source' => 'journal', 'log_service' => ''] + $device);
rejectSettings(['log_source' => 'file', 'log_path' => ''] + $device);
rejectSettings(['ssh_user' => ''] + $device);
rejectSettings(['ssh_key' => ''] + $device);
rejectSettings(['log_path' => 'relative.log'] + $device);
DiscoveryLog::settings(['log_enabled' => false, 'log_service' => '']);

$legacy = ['log_path' => '/var/log/discovery.log'] + $device;
verify(DiscoveryLog::settings($legacy)['log_source'] === 'file', 'Previously configured file logs must not be silently switched to a journal.');
verify(DiscoveryLog::remoteCommand($legacy) === "tail -n 200 -- '/var/log/discovery.log'", 'Legacy file-tail commands must remain unchanged.');
$quotedPath = "/var/log/discovery's log; literal.log";
verify(DiscoveryLog::remoteCommand(['log_source' => 'file', 'log_path' => $quotedPath] + $device) === 'tail -n 200 -- ' . escapeshellarg($quotedPath), 'File paths must remain shell-quoted.');
verify(str_starts_with(DiscoveryLog::remoteCommand(['log_source' => 'journal'] + $legacy), 'journalctl '), 'Choosing a journal must override a retained file path.');

$config = [
    'app_title' => 'Status', 'timezone' => 'UTC', 'teams' => ['us' => 'United States'],
    'header_devices' => [$device], 'online_values' => ['online'], 'check_schedule' => ['12:00'],
    'ping' => ['tcp_ports' => [80]], 'rate_limits' => ['login' => [10, 60]],
    'max_import_bytes' => 1048576, 'max_photo_bytes' => 1048576,
];
$form = Settings::editable($config);
$overrides = Settings::validate($form, $config);
verify($overrides['header_devices'][0]['log_source'] === 'journal'
    && $overrides['header_devices'][0]['log_service'] === 'ndi-discovery.service', 'Service journal settings must pass through settings validation.');
$db = Database::open(':memory:');
Settings::save($db, $overrides);
$loaded = Settings::load($db);
verify($loaded['header_devices'][0]['log_service'] === 'ndi-discovery.service', 'Service names must survive a database round trip.');
$editable = Settings::editable($loaded);
verify($editable['header_devices'][0]['log_source'] === 'journal', 'Saved source must be returned to the settings form.');
$form['header_devices'] = [$legacy];
verify(Settings::validate($form)['header_devices'][0]['log_source'] === 'file', 'Legacy settings saves must keep file log support.');

$directory = sys_get_temp_dir() . '/dashboard-discovery-' . bin2hex(random_bytes(8));
mkdir($directory, 0700);
try {
    $snapshotDb = Database::open($directory . '/dashboard.db');
    $reader = new SnapshotDiscoveryLog($directory);
    $name = 'discovery_log:' . hash('sha256', $device['ip']);
    $expire = static function () use ($snapshotDb, $name): void {
        $snapshotDb->stateUpdate($name, static function (array &$snapshot): void {
            $snapshot['checked_at'] = 0;
        });
    };
    $readCount = static fn (): int => is_file($directory . '/reads')
        ? count(file($directory . '/reads', FILE_IGNORE_NEW_LINES)) : 0;
    $concurrent = static function (array $target) use ($directory): array {
        $workers = [];
        try {
            for ($i = 0; $i < 4; $i++) {
                $process = proc_open([PHP_BINARY, __FILE__, '--snapshot-worker', $directory, json_encode($target)],
                    [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
                verify(is_resource($process), 'Cannot start a concurrent discovery viewer.');
                stream_set_timeout($pipes[1], 15);
                $workers[] = [$process, $pipes];
                verify(fgets($pipes[1]) === "ready\n", 'Concurrent viewer failed to initialize.');
            }
            // All independent connections are ready before any viewer requests the snapshot.
            foreach ($workers as [, $pipes]) {
                fwrite($pipes[0], "start\n");
            }
            $responses = [];
            foreach ($workers as [, $pipes]) {
                $responses[] = json_decode(stream_get_contents($pipes[1]), true, 512, JSON_THROW_ON_ERROR);
            }
            return $responses;
        } finally {
            foreach ($workers as [$process, $pipes]) {
                foreach ($pipes as $pipe) {
                    fclose($pipe);
                }
                proc_terminate($process);
                proc_close($process);
            }
        }
    };
    $responses = $concurrent($device);
    verify($readCount() === 1 && count(array_unique(array_map('json_encode', $responses))) === 1
        && $responses[0]['log']['text'] === 'ndi-discovery.service',
        'Simultaneous cold viewers must share one successful SSH read, not return contention errors.');
    verify($reader->readShared($snapshotDb, $device) === $responses[0]['log'] && $readCount() === 1,
        'Warm snapshots must be reused across requests.');
    $expire();
    verify($concurrent($device)[0]['log'] === $responses[0]['log'] && $readCount() === 2,
        'Expired snapshots must trigger only one refresh for overlapping viewers.');
    $changed = ['log_service' => 'other.service'] + $device;
    verify($reader->readShared($snapshotDb, $changed)['text'] === 'other.service' && $readCount() === 3,
        'Changing the selected service must invalidate a fresh snapshot.');
    $changed = ['ssh_user' => 'other_user'] + $changed;
    $reader->readShared($snapshotDb, $changed);
    verify($readCount() === 4, 'Changing SSH credentials must invalidate a fresh snapshot.');
    $changed = ['ssh_port' => 2222] + $changed;
    $reader->readShared($snapshotDb, $changed);
    verify($readCount() === 5, 'Changing SSH ports must invalidate a fresh snapshot.');
    $changed = ['log_source' => 'file', 'log_path' => '/var/log/other.log'] + $changed;
    $reader->readShared($snapshotDb, $changed);
    verify($readCount() === 6, 'Switching to a file source must invalidate a fresh snapshot.');
    $changed = ['ssh_auth' => 'password', 'ssh_password_encrypted' => 'encrypted-fixture-a'] + $changed;
    $reader->readShared($snapshotDb, $changed);
    $changed['ssh_password_encrypted'] = 'encrypted-fixture-b';
    $reader->readShared($snapshotDb, $changed);
    verify($readCount() === 8, 'Changing authentication mode or encrypted passwords must invalidate fresh snapshots.');
    try {
        $reader->readShared($snapshotDb, ['log_enabled' => false] + $changed);
        throw new RuntimeException('Disabled viewers must not read cached logs.');
    } catch (InvalidArgumentException) {
    }
    $expire();
    touch($directory . '/fail');
    $failures = $concurrent($changed);
    verify($readCount() === 9 && count(array_unique(array_map('json_encode', $failures))) === 1
        && isset($failures[0]['error']) && !isset($failures[0]['log']),
        'Overlapping failed refreshes must share an error, never return old logs as live.');
    verify(!isset($snapshotDb->stateRead($name)['log']), 'A failed refresh must replace the previous successful snapshot.');
    try {
        $reader->readShared($snapshotDb, $changed);
        throw new RuntimeException('Failed snapshots must propagate the error.');
    } catch (RuntimeException $e) {
        verify($e->getMessage() === 'SSH log read failed.' && $readCount() === 9,
            'Failures must be briefly cached rather than repeatedly probing a failing SSH server.');
    }
    unlink($directory . '/fail');
    $expire();
    verify(isset($concurrent($changed)[0]['log']) && $readCount() === 10,
        'Viewers must recover together once the failure snapshot expires.');
    $snapshotDb->stateUpdate($name, static function (array &$snapshot): void {
        $snapshot['checked_at'] = microtime(true) + 60;
    });
    $reader->readShared($snapshotDb, $changed);
    verify($readCount() === 11, 'Clock changes must not keep future-dated snapshots indefinitely fresh.');
} finally {
    foreach (glob($directory . '/*') as $path) {
        unlink($path);
    }
    rmdir($directory);
}

echo "Discovery journal and file log regression checks passed.\n";
