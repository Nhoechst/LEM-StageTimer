<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\CheckGuard;
use StatusDashboard\Database;

$guard = new CheckGuard(Database::open(':memory:'), sys_get_temp_dir() . '/status-check-guard-' . getmypid(), 60);

if ($guard->beginManual('global-check-identifier', 1, 1000) !== 0) {
    throw new RuntimeException('The first global check must be allowed.');
}
$guard->finishManual(1010);
if ($guard->cooldownRemaining(1011) !== 59) {
    throw new RuntimeException('A global check must start the configured global cooldown.');
}
if ($guard->beginManual('individual-device-check', 1, 1011, 41) !== 0) {
    throw new RuntimeException('An individual device check must not be blocked by the global cooldown.');
}
$guard->finishManual(1020, 41);
if ($guard->beginManual('individual-device-check', 1, 1021, 41) !== 59) {
    throw new RuntimeException('The same device must observe its individual cooldown.');
}
if ($guard->beginManual('individual-device-check', 1, 1021, 42) !== 0) {
    throw new RuntimeException('A different device must not inherit another device’s cooldown.');
}
if ($guard->beginManual('global-check-identifier', 1, 1021) !== 49) {
    throw new RuntimeException('Individual checks must not reset the global cooldown.');
}
if ($guard->beginManual('next-global-check', 1, 1070) !== 0) {
    throw new RuntimeException('A global check must become available when its own cooldown expires.');
}
$guard->finishManual(1070);
if ($guard->beginManual('individual-device-check', 1, 1071, 41) !== 9) {
    throw new RuntimeException('Global checks must not erase active individual-device cooldowns.');
}

echo "Check guard cooldown regression checks passed.\n";
