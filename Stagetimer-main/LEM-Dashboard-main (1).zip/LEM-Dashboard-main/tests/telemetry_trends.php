<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\Database;
use StatusDashboard\Telemetry;

$db = Database::open(':memory:');
$db->pdo->exec("INSERT INTO sites (id, name) VALUES (1, 'Lab'), (2, 'Empty'), (3, 'Other')");
$db->pdo->exec("INSERT INTO devices (id, site_id, name) VALUES (1, 1, 'A'), (2, 1, 'B'), (3, 3, 'C')");
$telemetry = new Telemetry($db);
$today = gmmktime(0, 0, 0, 10, 18, 2026);
$now = $today + 43200;
$start = $today - 29 * 86400;
$insert = $db->pdo->prepare(
    'INSERT INTO device_samples (device_id, site_id, checked_at, status, latency_ms) VALUES (?, ?, ?, ?, ?)'
);
foreach ([
    [1, 1, $start - 1, 'online', 999],
    [1, 1, $start, 'online', 5],
    [1, 1, $today - 2 * 86400 + 100, 'online', 10],
    [1, 1, $today - 2 * 86400 + 200, 'offline', 999],
    [2, 1, $today - 2 * 86400 + 100, 'online', 30],
    [1, 1, $today - 86400 + 100, 'offline', null],
    [1, 1, $today + 100, 'online', 0],
    [1, 1, $today + 100, 'offline', null],
    [2, 1, $today + 100, 'online', null],
    [2, 1, $now + 1, 'online', 999],
    [3, 3, $today + 100, 'online', 80],
] as $sample) {
    $insert->execute($sample);
}

$trends = $telemetry->siteTrends($now);
if (count($trends) !== 3 || count($trends[1]) !== 30 || $trends[1][0]['day'] !== $start
    || $trends[1][29]['day'] !== $today) {
    throw new RuntimeException('Trends must contain exactly 30 chronological UTC days per location.');
}
if ($trends[1][0]['avg_latency_ms'] !== 5.0) {
    throw new RuntimeException('The first day is inclusive and older samples must be excluded.');
}
if ($trends[1][0]['online_pct'] !== 100 || $trends[1][27]['online_pct'] !== 50
    || $trends[1][28]['online_pct'] !== 0 || $trends[1][29]['online_pct'] !== 50) {
    throw new RuntimeException('Percent online must use the last check per device, not all check samples or unchecked devices.');
}
if ($trends[1][27]['online_devices'] !== 1 || $trends[1][27]['avg_latency_ms'] !== 20.0
    || abs($trends[1][27]['success_pct'] - 200 / 3) > 0.0001) {
    throw new RuntimeException('Daily statistics must use all checks, successful measurements, and each device’s last status.');
}
if ($trends[1][28]['online_devices'] !== 0 || $trends[1][28]['success_pct'] !== 0
    || $trends[1][28]['avg_latency_ms'] !== null) {
    throw new RuntimeException('All-offline days have zero success and no measured ping.');
}
if ($trends[1][29]['online_devices'] !== 1 || $trends[1][29]['avg_latency_ms'] !== 0.0
    || abs($trends[1][29]['success_pct'] - 200 / 3) > 0.0001) {
    throw new RuntimeException('Same-time checks use the last id; zero latency is valid and future samples are excluded.');
}
if ($trends[3][29]['avg_latency_ms'] !== 80.0) {
    throw new RuntimeException('Locations must not share data.');
}
foreach ([$trends[1][1], ...$trends[2]] as $point) {
    if ($point['online_devices'] !== null || $point['online_pct'] !== null || $point['avg_latency_ms'] !== null || $point['success_pct'] !== null) {
        throw new RuntimeException('Days without recorded checks must remain gaps, not zero.');
    }
}
$db->pdo->exec('DELETE FROM devices WHERE site_id = 1');
if ($telemetry->siteTrends($now)[1][29]['online_devices'] !== null) {
    throw new RuntimeException('Deleted device history must not appear in trends.');
}
$db->pdo->exec('DELETE FROM sites WHERE id = 3');
if (isset($telemetry->siteTrends($now)[3])) {
    throw new RuntimeException('Deleted locations must not appear in trends.');
}
echo "Telemetry trend regression checks passed.\n";
