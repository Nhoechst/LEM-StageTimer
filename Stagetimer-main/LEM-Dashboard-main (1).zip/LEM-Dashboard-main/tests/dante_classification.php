<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\EquipmentService;
use StatusDashboard\Inventory;
use StatusDashboard\OutageMailer;
use StatusDashboard\Pinger;
use StatusDashboard\Settings;

foreach (['Dante', 'dAnTe endpoint', 'NDI / Dante bridge', 'Dante-enabled audio'] as $type) {
    foreach (['10.1.1.1', '172.20.1.1', '192.168.1.1', '2001:db8::1', '', '*******'] as $ip) {
        if (!EquipmentService::isDante(['type' => $type, 'ip' => $ip])) {
            throw new RuntimeException('Dante types must be recognized on every site/address range.');
        }
    }
}
foreach (['Switch', 'Dantes', 'NotDante', '', null] as $type) {
    if (EquipmentService::isDante(['type' => $type, 'name' => 'Dante', 'model' => 'Dante', 'ip' => '10.1.1.1'])) {
        throw new RuntimeException('Names, models and addresses must not classify a non-Dante type.');
    }
}

$config = [
    'dante_keywords' => ['switch'],
    'dante_networks' => ['10.0.0.0/8'],
    'corporate_networks' => [],
    'external_networks' => ['192.0.0.0/8'],
];
$service = new EquipmentService($config);
$data = [
    'sites' => [['id' => 1, 'name' => 'A'], ['id' => 2, 'name' => 'B']],
    'devices' => [
        ['id' => 1, 'site_id' => 1, 'name' => 'Audio A', 'type' => 'Dante', 'ip' => '10.1.1.1', 'status' => 'online'],
        ['id' => 2, 'site_id' => 2, 'name' => 'Audio B', 'type' => 'Dante', 'ip' => '172.20.1.1', 'status' => 'online'],
        ['id' => 3, 'site_id' => 1, 'name' => 'Dante Switch', 'type' => 'Switch', 'ip' => '10.1.1.2'],
        ['id' => 4, 'site_id' => 2, 'name' => 'External', 'type' => 'Dante', 'ip' => '192.168.1.1'],
    ],
];
$rows = array_column($service->buildRows($data), null, 'id');
if (!$rows[1]['dante'] || !$rows[2]['dante'] || $rows[3]['dante'] || !$rows[4]['dante']) {
    throw new RuntimeException('Dashboard rows must ignore legacy Dante networks and keywords.');
}
if ($rows[4]['status'] !== EquipmentService::STATUS_EXTERNAL || $rows[1]['status'] === EquipmentService::STATUS_EXTERNAL) {
    throw new RuntimeException('External network status must remain independent of Dante membership.');
}
$editable = Settings::editable($config);
if (array_key_exists('dante_keywords', $editable) || array_key_exists('dante_networks', $editable)) {
    throw new RuntimeException('Obsolete Dante settings must not be offered for editing.');
}

$undefinedConfig = $config + ['stale_after_hours' => 1];
foreach ([[], ['0.0.0.0/0'], ['192.0.0.0/8']] as $external) {
    foreach ([[], ['10.0.0.0/8']] as $corporate) {
        $undefinedConfig['external_networks'] = $external;
        $undefinedConfig['corporate_networks'] = $corporate;
        foreach (['', 'online', 'offline', 'external'] as $stored) {
            $device = ['id' => 10, 'site_id' => 1, 'name' => 'Undefined', 'ip' => '0.0.0.0', 'status' => $stored, 'last_checked' => '2020-01-01T00:00:00Z'];
            $service = new EquipmentService($undefinedConfig);
            $row = $service->buildRows(['devices' => [$device]])[0];
            $pc = $service->buildPcRows(['pcs' => [$device]])[0];
            if (EquipmentService::isExternalAddress(' 0.0.0.0 ', $undefinedConfig)
                || EquipmentService::isExternalRecord($device, $undefinedConfig)
                || $row['status'] !== EquipmentService::STATUS_UNKNOWN
                || $pc['status'] !== EquipmentService::STATUS_UNKNOWN) {
                throw new RuntimeException('Undefined addresses must remain unknown, regardless of CIDRs or stored status.');
            }
        }
    }
}
$undefinedInventory = ['devices' => [['ip' => '0.0.0.0']]];
if (Inventory::isPingTargetAllowed($undefinedInventory, '0.0.0.0', ['0.0.0.0'])
    || !isset((new Pinger())->ping('0.0.0.0')['error'])) {
    throw new RuntimeException('Undefined addresses must never be pinged, even when present in inventory.');
}
$inputData = ['sites' => [['id' => 1, 'name' => 'Studio']], 'devices' => [], 'pcs' => []];
Inventory::saveDevice($inputData, ['site_id' => 1, 'name' => 'Needs an address', 'ip' => 'http://0.0.0.0:8080/']);
if ($inputData['devices'][0]['ip'] !== '0.0.0.0') {
    throw new RuntimeException('Undefined addresses must remain editable rather than being rejected or lost.');
}
$inputData['sites'][0]['team'] = 'de';
Inventory::saveDevice($inputData, ['site_id' => 1, 'name' => 'Dante without address', 'type' => 'Dante', 'ip' => '']);
$snapshot = (new OutageMailer($undefinedConfig))->snapshot($inputData, 'de', static fn ($team) => (string) $team);
if (count($snapshot['rows']) !== 1 || $snapshot['rows'][0]['name'] !== 'Needs an address') {
    throw new RuntimeException('Needs attention reports must include undefined equipment but exclude Dante.');
}

echo "Dante classification regression checks passed.\n";
