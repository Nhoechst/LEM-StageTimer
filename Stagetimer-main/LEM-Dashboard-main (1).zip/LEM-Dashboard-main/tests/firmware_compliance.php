<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\Database;
use StatusDashboard\EquipmentService;
use StatusDashboard\Settings;

function expectFirmware(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$minimum = new EquipmentService(['firmware_mode' => 'minimum']);
$exact = new EquipmentService(['firmware_mode' => 'exact']);
foreach ([
    ['BirdDog 4K HDMI 6.1.349', '6.1.349'],
    ['Firmware v9.6.2', '9.6.2'],
    ['Version 01.002.003', '1.2.3'],
    ['v1.2.0.0', '1.2'],
    ['v1_2_3', '1.2.3'],
    ['1.2.3+build-42', '1.2.3'],
    ['NDI 6 - firmware 1.2.3', '1.2.3'],
    ['1.2.3', 'v1.2.3'],
    ['1.2.3', '1.0; Product 1.2.3'],
    ['1.2.3-rc.01', '1.2.3-rc1'],
    ['release-name', 'RELEASE-NAME'],
    ['1', '1.0'],
] as [$current, $latest]) {
    foreach ([$minimum, $exact] as $service) {
        expectFirmware($service->compliance($current, $latest) === 'compliant', "Equivalent firmware must match: $current / $latest");
    }
}
foreach ([
    ['6.1.350', 'BirdDog 4K HDMI 6.1.349'],
    ['10.0', '9.9.99'],
    ['1.2.3', '1.2.3-rc1'],
    ['1.2.3-rc2', '1.2.3-rc1'],
] as [$current, $latest]) {
    expectFirmware($minimum->compliance($current, $latest) === 'compliant', "Minimum mode must accept newer firmware: $current");
    expectFirmware($exact->compliance($current, $latest) === 'non_compliant', 'Exact mode must continue to require the same normalized version.');
}
foreach ([
    ['BirdDog 4K HDMI 6.1.348', '6.1.349'],
    ['1.2.3-beta2', '1.2.3'],
    ['1.2.3-rc1', '1.2.3'],
    ['1.2.3-rc.1', '1.2.3'],
    ['1.9', '1.10'],
] as [$current, $latest]) {
    expectFirmware($minimum->compliance($current, $latest) === 'non_compliant', "Older firmware must not become compliant: $current");
}
foreach ([
    ['', '1.2.3'], ['1.2.3', null], ['1.2.3', ''], ['unknown', '1.2.3'],
    ['1.2.3 / 2.0.0', '2.0.0'], ['Product 4K', '1.2.3'], ['1.2.3', 'latest'],
    ['1.2.3', '1.3.0; unknown'],
    ['1.2.3-preview', '1.2.3'], ['1.2.3-1', '1.2.3'], ['1.2.3-4.5', '1.2.3'],
    ['1.2.3', '1.2.3-preview'],
] as [$current, $latest]) {
    expectFirmware($minimum->compliance($current, $latest) === 'unknown', "Ambiguous/missing firmware must not be guessed: $current");
}

$db = Database::open(':memory:');
Settings::save($db, ['app_title' => 'Unchanged', 'firmware_mode' => 'minimum']);
Settings::setFirmwareExemption($db, '  BirdDog   4K HDMI  ', true);
Settings::setFirmwareExemption($db, 'Other model', true);
Settings::setFirmwareExemption($db, 'birddog 4k hdmi', true);
$config = Settings::load($db);
expectFirmware(count($config['firmware_exemptions']) === 2 && $config['app_title'] === 'Unchanged', 'Exemptions must deduplicate and preserve other settings.');
$data = ['sites' => [], 'devices' => [
    ['id' => 1, 'site_id' => 1, 'name' => 'Blank firmware', 'model' => 'BirdDog  4K HDMI', 'firmware' => ''],
    ['id' => 2, 'site_id' => 2, 'name' => 'Old firmware', 'model' => 'BirdDog 4K HDMI', 'firmware' => '1.0'],
    ['id' => 3, 'site_id' => 1, 'name' => 'Different model', 'model' => 'BirdDog 4K HDMI Plus', 'firmware' => '1.0'],
], 'firmware' => [
    ['id' => 1, 'model' => 'BirdDog 4K HDMI', 'approved' => '6.1.349'],
    ['id' => 2, 'model' => 'BirdDog 4K HDMI Plus', 'approved' => '6.1.349'],
]];
$rows = array_column((new EquipmentService($config))->buildRows($data), null, 'id');
expectFirmware($rows[1]['firmware_exempt'] && $rows[1]['compliance'] === 'compliant'
    && $rows[2]['firmware_exempt'] && $rows[2]['compliance'] === 'compliant', 'Exemptions must apply to every matching model, including blank firmware and different locations.');
expectFirmware(!$rows[3]['firmware_exempt'] && $rows[3]['compliance'] === 'non_compliant', 'Similar model names must not be accidentally exempted.');
Settings::setFirmwareExemption($db, 'BIRDDOG 4K HDMI', false);
$rows = array_column((new EquipmentService(Settings::load($db)))->buildRows($data), null, 'id');
expectFirmware(!$rows[1]['firmware_exempt'] && $rows[1]['compliance'] === 'unknown'
    && $rows[2]['compliance'] === 'non_compliant', 'Removing an exemption must restore normal checks.');
$formConfig = ['app_title' => 'Status', 'teams' => ['us' => 'United States'], 'online_values' => ['online'],
    'check_schedule' => ['12:00'], 'ping' => ['tcp_ports' => [80]], 'rate_limits' => ['login' => [10, 60]],
    'max_import_bytes' => 1048576, 'max_photo_bytes' => 1048576] + Settings::load($db);
$validated = Settings::validate(Settings::editable($formConfig), $formConfig);
expectFirmware($validated['firmware_exemptions'] === ['Other model'], 'Saving unrelated settings must not erase exemptions.');
Settings::setFirmwareExemption($db, 'New model', true);
Settings::save($db, $validated, true);
expectFirmware(Settings::load($db)['firmware_exemptions'] === ['Other model', 'New model'], 'An old general settings snapshot must not erase newer exemption additions.');
Settings::setFirmwareExemption($db, 'Other model', false);
Settings::save($db, $validated, true);
expectFirmware(Settings::load($db)['firmware_exemptions'] === ['New model'], 'An old general settings snapshot must not restore removed exemptions.');
Settings::save($db, ['firmware_exemptions' => ['Restored model']]);
expectFirmware(Settings::load($db)['firmware_exemptions'] === ['Restored model'], 'Backup restoration must still replace exemption settings.');
foreach ([null, 'Model', [''], [str_repeat('x', 201)], ["Model\nOther"], [123], array_fill(0, 1001, 'Model')] as $invalid) {
    try {
        Settings::firmwareExemptions($invalid);
    } catch (InvalidArgumentException) {
        continue;
    }
    throw new RuntimeException('Invalid exemption input was accepted.');
}

echo "Firmware comparison and exemption regression checks passed.\n";
