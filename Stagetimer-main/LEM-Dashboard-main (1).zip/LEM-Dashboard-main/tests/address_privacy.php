<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/AddressPrivacy.php';

use StatusDashboard\AddressPrivacy;

$cases = [
    'IPv4 192.0.2.1.' => 'IPv4 *******.',
    'http://192.0.2.1:8080/path' => 'http://*******:8080/path',
    'switch_192.0.2.1' => 'switch_*******',
    'switch192.0.2.1backup' => 'switch*******backup',
    'IP:2001:db8::1' => 'IP:*******',
    '[2001:db8::1]:443' => '[*******]:443',
    '::ffff:192.0.2.1' => '*******',
    'fe80::1%eth0' => '*******',
    '2001:0db8:0000:0000:0000:0000:0000:0001.' => '*******.',
    '::1 and ::' => '******* and *******',
    'Firmware 1.2.3 / 2026-10-18T02:49:46Z' => 'Firmware 1.2.3 / 2026-10-18T02:49:46Z',
];

foreach ($cases as $input => $expected) {
    if (AddressPrivacy::redact($input) !== $expected) {
        throw new RuntimeException('Unexpected redaction for: ' . $input);
    }
}

$original = [
    'ip' => 'router.example.com',
    'subnet' => '192.0.2.0/24',
    'web_url' => 'https://router.example.com',
    'log_enabled' => true,
    'nested' => [(object) ['ip' => '2001:db8::1', 'status' => 'online']],
    'empty' => (object) [],
    'count' => 2,
];
$expected = [
    'ip' => '*******',
    'subnet' => '*******',
    'web_url' => '',
    'log_enabled' => false,
    'nested' => [(object) ['ip' => '*******', 'status' => 'online']],
    'empty' => (object) [],
    'count' => 2,
];
if (AddressPrivacy::redact($original) != $expected || $original['ip'] !== 'router.example.com'
    || $original['nested'][0]->ip !== '2001:db8::1') {
    throw new RuntimeException('Redaction must preserve structure and leave source data unchanged.');
}
if (AddressPrivacy::redact(['ip' => '', 'subnet' => null]) !== ['ip' => '', 'subnet' => null]) {
    throw new RuntimeException('Empty address fields must stay empty.');
}

echo "Address privacy regression checks passed.\n";
