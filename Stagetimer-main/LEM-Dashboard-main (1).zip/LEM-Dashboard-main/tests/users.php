<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\Database;
use StatusDashboard\Users;

function expectUser(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$file = tempnam(sys_get_temp_dir(), 'dashboard-users-');
try {
    $legacy = new PDO('sqlite:' . $file);
    $legacy->exec("CREATE TABLE users (username TEXT PRIMARY KEY COLLATE NOCASE, password_hash TEXT NOT NULL, created TEXT NOT NULL, role TEXT NOT NULL);
        CREATE TABLE user_profiles (username TEXT PRIMARY KEY COLLATE NOCASE, photo BLOB, photo_mime TEXT NOT NULL DEFAULT '', photo_version TEXT NOT NULL DEFAULT '', theme TEXT NOT NULL DEFAULT 'main');
        PRAGMA user_version = 6;");
    $password = bin2hex(random_bytes(16));
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $legacy->prepare('INSERT INTO users VALUES (?, ?, ?, ?)')->execute(['Admin', $hash, '2025-01-01', 'admin']);
    $legacy->exec("INSERT INTO user_profiles (username, photo_version, theme) VALUES ('Admin', 'existing-photo', 'vista')");
    $legacy = null;

    $db = Database::open($file);
    $users = new Users($db);
    $row = $users->all()[0];
    expectUser($row['last_login'] === null && $row['created'] === '2025-01-01' && $row['role'] === 'admin'
        && $row['photo_version'] === 'existing-photo' && $users->profile('Admin')['theme'] === 'vista',
        'Migration must preserve existing accounts/profiles without inventing past logins.');
    expectUser($users->verify('admin', $password) === 'Admin', 'Migration must preserve passwords and case-insensitive usernames.');
    expectUser(!$users->mustChangePassword('Admin'), 'Existing accounts must not be forced to change passwords after migration.');
    expectUser($users->all()[0]['last_login'] === null, 'Password verification alone must not count as a login.');
    $before = time();
    $users->recordLogin(' admin ');
    $recorded = $users->all()[0]['last_login'];
    expectUser(is_int($recorded) && $recorded >= $before && $recorded <= time(), 'Login time must be persisted as a Unix timestamp.');
    expectUser($users->verify('Admin', bin2hex(random_bytes(16))) === null, 'Wrong passwords must still fail.');
    $users->setPassword('Admin', $password);
    expectUser($users->all()[0]['last_login'] === $recorded, 'Password changes and failed verifications must not change login times.');
    expectUser(!array_key_exists('password_hash', $users->all()[0]), 'User lists must not expose password hashes.');
    $db->pdo->exec("UPDATE users SET last_login = 1 WHERE username = 'Admin'");
    $users->recordLogin('ADMIN');
    expectUser($users->all()[0]['last_login'] >= $before, 'Subsequent logins must update the stored timestamp.');

    $fresh = new Users(Database::open(':memory:'));
    $fresh->add('NewUser', $password);
    expectUser($fresh->all()[0]['last_login'] === null, 'Newly added users must not appear to have logged in.');
    $fresh->recordLogin('NewUser');
    expectUser(is_int($fresh->all()[0]['last_login']), 'Fresh databases must support login tracking.');
    expectUser(!$fresh->mustChangePassword('NewUser'), 'Existing setup/account creation behavior must remain unaffected.');
    $temporary = $fresh->addTemporary('Temporary', 'lead');
    $another = $fresh->addTemporary('Another');
    expectUser(strlen($temporary) === 24 && preg_match('/^[A-Za-z0-9_-]{24}$/', $temporary) === 1
        && $temporary !== $another, 'Temporary credentials must be strong, independently generated, and easy to copy.');
    expectUser($fresh->mustChangePassword('temporary') && $fresh->verify('TEMPORARY', $temporary) === 'Temporary',
        'Generated credentials must authenticate case-insensitively without clearing the change requirement.');
    $freshDb = Database::open(':memory:');
    $stored = $freshDb->pdo->query("SELECT * FROM users WHERE username = 'Temporary'")->fetch();
    expectUser($stored['password_hash'] !== $temporary && password_verify($temporary, $stored['password_hash'])
        && !str_contains(json_encode($fresh->all()), $temporary), 'Only the hash may be stored or listed.');
    foreach ([['incorrect', $password], [$temporary, $temporary], [$temporary, 'short']] as [$current, $next]) {
        try {
            $fresh->changePassword('Temporary', $current, $next);
            throw new RuntimeException('Invalid first-login password changes must fail.');
        } catch (InvalidArgumentException) {
            expectUser($fresh->mustChangePassword('Temporary'), 'Failed changes must retain the restriction.');
        }
    }
    // Rehashing a legacy-cost hash during login must not count as a password change.
    $freshDb->pdo->prepare("UPDATE users SET password_hash = ? WHERE username = 'Temporary'")
        ->execute([password_hash($temporary, PASSWORD_BCRYPT, ['cost' => 4])]);
    expectUser($fresh->verify('Temporary', $temporary) === 'Temporary' && $fresh->mustChangePassword('Temporary'),
        'Automatic hash upgrades must retain first-login restrictions.');
    $fresh->changePassword('Temporary', $temporary, $password);
    expectUser(!$fresh->mustChangePassword('Temporary') && $fresh->verify('Temporary', $password) === 'Temporary'
        && $fresh->verify('Temporary', $temporary) === null, 'Successful changes must clear the requirement and invalidate the temporary password.');
    echo "User last-login migration and persistence checks passed.\n";
} finally {
    foreach ([$file, $file . '-wal', $file . '-shm'] as $path) {
        if (is_file($path)) {
            unlink($path);
        }
    }
}
