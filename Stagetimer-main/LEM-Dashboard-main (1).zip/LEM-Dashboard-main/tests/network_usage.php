<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use StatusDashboard\Database;
use StatusDashboard\NetworkUsage;

$db = Database::open(':memory:');
$config = ['ping' => ['method' => 'icmp', 'count' => 2, 'tcp_ports' => [80, 443]]];
$now = 1_800_000_000;
NetworkUsage::record($db, [
    '192.0.2.1' => ['ip' => '192.0.2.1', 'online' => true, 'latency_ms' => 1.0],
    '2001:db8::1' => ['ip' => '2001:db8::1', 'online' => false, 'latency_ms' => null],
], $config, 'icmp', $now);
NetworkUsage::record($db, [
    '192.0.2.2' => ['ip' => '192.0.2.2', 'online' => false, 'latency_ms' => null],
], $config, 'icmp', $now - 25 * 3600);
$request = [
    'REQUEST_METHOD' => 'POST', 'REQUEST_URI' => '/api.php?action=check',
    'SERVER_PROTOCOL' => 'HTTP/1.1', 'HTTP_HOST' => 'status.example',
    'CONTENT_LENGTH' => '4',
];
NetworkUsage::recordHttp($db, $request, 100, ['Content-Type: application/json'], $now);

$usage = NetworkUsage::summary($db, $now);
$expectedRequest = strlen('POST') + 1 + strlen($request['REQUEST_URI']) + 1 + strlen('HTTP/1.1') + 2
    + strlen('HTTP-HOST') + 2 + strlen('status.example') + 2
    + strlen('CONTENT-LENGTH') + 2 + strlen('4') + 2 + 4;
$last = $usage['hours'][167];
if (count($usage['hours']) !== 168 || $last['ping_sent_bytes'] !== 376 || $last['ping_received_bytes'] !== 168
    || $last['requests'] !== 1 || $last['request_bytes'] !== $expectedRequest || $last['response_bytes'] <= 100) {
    throw new RuntimeException('Hourly buckets should include HTTP and estimated IPv4/IPv6 ping traffic.');
}
if ($usage['totals']['24h']['requests'] !== 1 || $usage['totals']['24h']['ping_hosts'] !== 2
    || $usage['totals']['24h']['in_bytes'] !== $expectedRequest + 168
    || $usage['totals']['24h']['out_bytes'] !== $last['response_bytes'] + 376) {
    throw new RuntimeException('24-hour totals should combine HTTP and probe traffic in both directions.');
}
if ($usage['totals']['7d']['requests'] !== 1 || $usage['totals']['7d']['ping_hosts'] !== 3) {
    throw new RuntimeException('The longer traffic window should include older hourly buckets.');
}

echo "Traffic usage regression checks passed.\n";
