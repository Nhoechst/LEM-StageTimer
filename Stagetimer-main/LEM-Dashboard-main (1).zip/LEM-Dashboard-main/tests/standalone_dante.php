<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'StatusDashboard\\';
    if (str_starts_with($class, $prefix)) {
        require dirname(__DIR__) . '/src/' . substr($class, strlen($prefix)) . '.php';
    }
});

use StatusDashboard\AddressPrivacy;
use StatusDashboard\Database;
use StatusDashboard\EquipmentService;
use StatusDashboard\Exporter;
use StatusDashboard\Importer;
use StatusDashboard\Inventory;
use StatusDashboard\OutageMailer;
use StatusDashboard\Store;
use StatusDashboard\Telemetry;

// Keep these unit checks independent of the deployed configuration/database.
function dashboard_team(mixed $value): string
{
    return in_array(strtolower((string) $value), ['de', 'germany'], true) ? 'de' : 'us';
}

function check(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function rejected(callable $operation): void
{
    try {
        $operation();
    } catch (InvalidArgumentException) {
        return;
    }
    throw new RuntimeException('Invalid inventory operation was accepted.');
}

$db = Database::open(':memory:');
$store = new Store($db);
$store->update(static function (array &$data): void {
    $site = Inventory::saveSite($data, ['name' => 'Studio', 'team' => 'us']);
    Inventory::saveDevice($data, ['site_id' => $site, 'name' => 'Location audio', 'type' => 'Dante', 'ip' => '192.168.1.10']);
});
$before = $store->load();
$input = ['ownership' => 'standalone', 'site_id' => 0, 'team' => 'de', 'name' => 'Isolated audio', 'type' => 'Dante', 'ip' => 'https://172.20.1.10:8443/admin'];
$id = $store->update(static fn (array &$data): int => Inventory::saveDevice($data, $input));
$data = $store->load();
$standalone = Inventory::findRecord($data, 'devices', $id);
check($data['sites'] === $before['sites'] && $data['devices'][0] === $before['devices'][0], 'Adding standalone devices must not create locations or move existing devices.');
check(Inventory::isStandalone($standalone) && $standalone['team'] === 'de' && $standalone['ip'] === '172.20.1.10'
    && $standalone['web_url'] === $input['ip'], 'Ownership, team and URL must survive the existing SQLite extra-column round trip.');
check(str_contains((string) $db->pdo->query("SELECT extra FROM devices WHERE id = {$id}")->fetchColumn(), '"ownership":"standalone"'), 'Standalone ownership must be explicit in storage.');

rejected(static fn () => Inventory::saveDevice($data, ['name' => 'No location', 'type' => 'Dante']));
rejected(static fn () => Inventory::saveDevice($data, ['type' => 'Switch'] + $input));
rejected(static fn () => Inventory::saveDevice($data, ['site_id' => 1] + $input));
rejected(static fn () => Inventory::saveDevice($data, ['id' => $id, 'ownership' => 'location', 'site_id' => 1] + $input));
rejected(static fn () => Inventory::saveDevice($data, ['id' => 2] + $input));
rejected(static fn () => Inventory::saveDevice($data, $input));
$otherTeamId = Inventory::saveDevice($data, ['team' => 'us'] + $input);
check($otherTeamId !== $id, 'Isolated country networks may reuse addresses.');

$config = ['corporate_networks' => ['10.0.0.0/8'], 'external_networks' => ['192.0.0.0/8']];
$service = new EquipmentService($config);
$rows = array_column($service->buildRows($data), null, 'id');
check($rows[2]['status'] === 'external' && $rows[2]['dante'], 'Location Dante retains existing external network semantics.');
check($rows[$id]['status'] === 'unknown' && $rows[$id]['dante'] && $rows[$id]['site'] === '', 'Isolated standalone addresses must not silently become external or acquire a fake location.');
check(!EquipmentService::isExternalRecord($standalone, $config), 'Standalone monitoring must bypass the corporate network assumption.');
foreach (['192.168.1.2', '169.254.1.2', '2001:db8::1', 'audio.example'] as $ip) {
    check(!EquipmentService::isExternalRecord(['ip' => $ip] + $standalone, $config), 'All valid standalone address families need deliberate monitoring semantics.');
}
check(EquipmentService::isExternalRecord(['status' => 'external'] + $standalone, $config), 'Explicit external status must still disable standalone monitoring.');
$summary = EquipmentService::summarise(array_values($rows), $data['sites']);
check($summary['total']['total'] === 3 && count($summary['sites']) === 1 && $summary['sites'][1]['total'] === 1, 'Standalone equipment counts globally, never as a fake location.');
$mail = (new OutageMailer($config))->snapshot($data, 'de', 'dashboard_team');
check($mail['total']['total'] === 1 && $mail['rows'] === [], 'Country totals must include standalone endpoints, but Dante must stay out of Needs attention reports.');
$redacted = AddressPrivacy::redact($rows[$id]);
check($redacted['ip'] === '*******' && $redacted['web_url'] === '' && $redacted['ownership'] === 'standalone', 'Anonymous standalone data must use the existing privacy filter.');

$importer = new Importer();
$backup = Exporter::backup($data);
$restored = Store::emptyData();
$result = $importer->restore($restored, $backup, date('c'));
check($result['errors'] === [] && count($restored['devices']) === 3 && count($restored['sites']) === 1, 'Mixed backup round trip must preserve standalone and location devices.');
$only = Store::emptyData();
$result = $importer->restore($only, ['devices' => [$standalone, ['name' => 'Invalid']]], date('c'));
check(count($only['devices']) === 1 && count($result['errors']) === 1, 'Standalone-only backup with another invalid record must retain valid endpoints.');
$legacy = $before;
$result = $importer->restore($legacy, Exporter::backup($before), date('c'));
check($result['errors'] === [] && !Inventory::isStandalone($legacy['devices'][0]), 'Old location-only backups must still restore.');

[$header, $table] = Exporter::table('devices', $data, array_values($rows));
$csv = fopen('php://memory', 'w+');
Exporter::writeCsv($csv, $header, $table);
rewind($csv);
$csvText = stream_get_contents($csv);
fclose($csv);
$csvData = Store::emptyData();
$result = $importer->import($csvData, $csvText, 'devices');
check($result['errors'] === [] && count($csvData['devices']) === 3 && count($csvData['sites']) === 1, 'CSV must round-trip both ownerships and team-scoped duplicate addresses.');
$result = $importer->import($csvData, $csvText, 'devices');
check($result['updated'] === 3 && count($csvData['devices']) === 3, 'CSV matching must remain scoped by location or standalone team.');
$scoped = $before;
$result = $importer->import($scoped, "Name,Type,IP Address,Ownership,Team\nImported,Dante,10.1.1.99,standalone,de\n", 'devices', 'replace', 1, null, true);
check($result['errors'] === [] && $scoped['devices'][0]['site_id'] === 1 && !Inventory::isStandalone($scoped['devices'][0]), 'Location imports must not escape their location.');

$telemetry = new Telemetry($db);
$version = $telemetry->deviceVersions()[$id];
check($telemetry->record($standalone, $version, ['online' => true, 'latency_ms' => 1.5], time()), 'Standalone checks must use existing device telemetry.');
check($telemetry->deviceHistory($id)['checks'] === 1, 'Standalone history must be available.');
check(!isset($telemetry->siteSummaries()[0]), 'Standalone telemetry must not create a location summary.');
$store->update(static function (array &$inventory) use ($id): void {
    $device = Inventory::findRecord($inventory, 'devices', $id);
    Inventory::applyStatus($device, 'online', date('c'), 1.5);
    Inventory::saveDevice($inventory, $device);
    unset($device['status']);
    Inventory::saveDevice($inventory, ['ip' => '172.20.1.11'] + $device);
});
$updated = Inventory::findRecord($store->load(), 'devices', $id);
check($updated['status'] === '' && $updated['last_checked'] === '' && $updated['latency_ms'] === null, 'Changing a standalone address must reset the current reachability result.');
$store->update(static fn (array &$inventory) => Inventory::deleteSite($inventory, 1));
check(count($store->load()['devices']) === 1, 'Deleting a location must preserve standalone devices.');
$store->update(static fn (array &$inventory) => Inventory::deleteDevice($inventory, $id));
check($telemetry->deviceHistory($id) === null && (int) $db->pdo->query('SELECT COUNT(*) FROM device_samples')->fetchColumn() === 0, 'Deleting standalone devices must remove telemetry.');
echo "Standalone Dante regression checks passed.\n";
