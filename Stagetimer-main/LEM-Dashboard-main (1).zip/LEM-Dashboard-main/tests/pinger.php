<?php

declare(strict_types=1);

namespace StatusDashboard {
    function proc_open($command, array $descriptors, &$pipes)
    {
        return \proc_open([PHP_BINARY, '-r', 'exit(1);'], $descriptors, $pipes);
    }

    // Simulate a device which silently drops TCP while exercising real UDP sockets.
    function stream_socket_client(string $address, &$errno, &$errstr, float $timeout, int $flags = STREAM_CLIENT_CONNECT)
    {
        if (str_starts_with($address, 'tcp://')) {
            $errno = 110;
            $errstr = 'Connection timed out';
            return false;
        }
        return \stream_socket_client($address, $errno, $errstr, $timeout, $flags);
    }
}

namespace {
    require dirname(__DIR__) . '/src/bootstrap.php';

    use StatusDashboard\Pinger;

    function expectPing(bool $condition, string $message): void
    {
        if (!$condition) {
            throw new RuntimeException($message);
        }
    }

    $oscString = static fn (string $value): string => str_pad($value . "\0", (int) (ceil((strlen($value) + 1) / 4) * 4), "\0");
    $reply = $oscString('/info') . $oscString(',ssss') . $oscString('V2.07')
        . $oscString('Studio') . $oscString('M32') . $oscString('4.09');
    $validate = new ReflectionMethod(Pinger::class, 'isOscInfo');
    expectPing($validate->invoke(null, $reply), 'A real four-string OSC info response must be accepted.');
    foreach (['', "/info\0\0\0", $reply . "\0", substr($reply, 0, -4), str_replace(',ssss', ',sssi', $reply),
        str_replace("/info\0\0\0", "/info\0x\0", $reply), $reply . "\0\0\0\0"] as $malformed) {
        expectPing(!$validate->invoke(null, $malformed), 'Malformed or unrelated packets must not imply reachability.');
    }

    $icmpWorks = new ReflectionProperty(Pinger::class, 'icmpWorks');
    $original = $icmpWorks->getValue();
    $icmpWorks->setValue(null, false);
    try {
        foreach (['valid', 'malformed', 'silent', 'valid-with-icmp'] as $mode) {
            $expectOnline = str_starts_with($mode, 'valid');
            $icmpWorks->setValue(null, $mode === 'valid-with-icmp');
            $server = <<<'PHP'
                $socket = stream_socket_server('udp://127.0.0.1:10023', $errno, $error, STREAM_SERVER_BIND);
                if ($socket === false) { fwrite(STDERR, $error); exit(1); }
                echo "ready\n";
                $peer = '';
                $query = stream_socket_recvfrom($socket, 4096, 0, $peer);
                if ($query !== "/info\0\0\0,\0\0\0") { exit(2); }
                if ($argv[1] === 'valid') {
                    stream_socket_sendto($socket, 'unrelated', 0, $peer);
                    stream_socket_sendto($socket, base64_decode($argv[2]), 0, $peer);
                } elseif ($argv[1] === 'malformed') {
                    stream_socket_sendto($socket, "/info\0\0\0", 0, $peer);
                }
                usleep(1500000);
                fclose($socket);
                PHP;
            $process = proc_open([PHP_BINARY, '-r', $server, $expectOnline ? 'valid' : $mode, base64_encode($reply)],
                [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
            expectPing(is_resource($process), 'Cannot start the UDP mixer fixture.');
            try {
                fclose($pipes[0]);
                stream_set_timeout($pipes[1], 3);
                expectPing(fgets($pipes[1]) === "ready\n", 'Cannot bind the local UDP mixer fixture.');
                $start = microtime(true);
                $result = (new Pinger(timeoutSeconds: 1, method: 'auto'))->ping('127.0.0.1');
                expectPing($result['online'] === $expectOnline, 'Only an OSC reply may mark a UDP-only mixer online.');
                expectPing(!$expectOnline || is_float($result['latency_ms']), 'OSC checks must report latency.');
                expectPing(microtime(true) - $start < 2, 'Silent/malformed UDP checks must be bounded.');
                expectPing(!(new Pinger(timeoutSeconds: 1, method: 'tcp'))->ping('127.0.0.1')['online'],
                    'Explicit TCP mode must not fall back to UDP.');
                expectPing(!(new Pinger(timeoutSeconds: 1, method: 'icmp'))->ping('127.0.0.1')['online'],
                    'Explicit ICMP mode must not fall back to UDP.');
            } finally {
                proc_terminate($process);
                fclose($pipes[1]);
                fclose($pipes[2]);
                proc_close($process);
            }
        }
        $invalid = (new Pinger())->pingMany(['0.0.0.0', 'bad/host']);
        foreach ($invalid as $result) {
            expectPing(!$result['online'] && isset($result['error']), 'Invalid addresses must still be rejected.');
        }
    } finally {
        $icmpWorks->setValue(null, $original);
    }
    echo "M32 OSC reachability regression checks passed.\n";
}
