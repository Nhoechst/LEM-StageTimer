# Logos

Images shown in the dashboard. Copied to `/www/logos/` with the rest of the project.

| File | Used for |
| --- | --- |
| `dante.svg`, `Dante_logo.svg` or `dante.png` | Dante Network panel on Device Status (inverted automatically in dark mode) |

The Dante logo is a trademark of Audinate. Use a dark (black) logo on a transparent
background: dark mode inverts it to white. Until a file is present the panel shows a
neutral audio icon.
