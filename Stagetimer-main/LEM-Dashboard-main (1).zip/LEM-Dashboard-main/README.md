# Equipment Status Dashboard

A self-hosted dashboard for monitoring equipment across locations and teams. Track
device and PC availability, firmware compliance, maintenance, and network health
from a browser.

The application has a PHP 8.1+ backend and a React frontend. The frontend is
committed as static files, so Node.js is only needed when developing the UI.
Inventory, settings, accounts, and telemetry are stored locally in SQLite; no
external database or runtime service is required.

## What it does

- Monitor equipment across locations, with online, offline, stale, and unchecked
  status.
- Run checks manually or on a schedule using ping or configured TCP ports.
- Track PC maintenance, including service dates, technicians, notes, and photos.
- Check firmware compliance against the latest version recorded for each model.
- View external-network and Dante devices.
- Review check history and trends, including latency, successful checks, outages,
  and annual summaries.
- Manage users and settings, with optional discovery-server logs and outage email
  alerts.
- Import and export inventory using CSV or Excel, and create or restore inventory
  backups.
- Use the dashboard in English or German, with team-specific views.

## Requirements

- nginx and PHP-FPM 8.1 or newer
- PHP extensions: `pdo_sqlite`, `json`, `mbstring`, and `session`
- Write access for the PHP-FPM user to the application's `data/` directory
- Optional: Node.js 18+ for frontend development

For ICMP checks, install the system `ping` command and allow PHP to run it. The
dashboard can also check configured TCP ports using PHP alone.

## Install

1. Install nginx and PHP-FPM with the required extensions. On Debian/Ubuntu:

   ```bash
   sudo apt install nginx php-fpm php-mbstring php-sqlite3
   ```

2. Copy the project files into the web root (for example `/www`). The deployable
   application includes `.user.ini`, `index.html`, `assets/`, `api.php`, `ping.php`,
   `src/`, `bin/`, and `logos/`.
3. Create `/www/data` and grant the PHP-FPM user write access:

   ```bash
   sudo mkdir -p /www/data
   sudo chown -R www-data:www-data /www/data
   sudo chmod 775 /www/data
   ```

   Use the account running PHP-FPM on your system; it may be `nginx` instead of
   `www-data`.

4. Configure nginx to serve the static frontend and execute only the `api.php` and
   `ping.php` entry points through PHP-FPM. Adjust the PHP-FPM socket to match your
   installed version.

   ```nginx
   server {
       listen 80;
       server_name _;
       root /www;
       index index.html;

       client_max_body_size 8m;
       location ~ ^/(config|data|src|bin|frontend)(/|$) { return 404; }
       location ~ /\. { deny all; }
       location ~* \.(?:md|json|lock|tmp|csv|ini|db|db-wal|db-shm|migrated)$ { return 404; }

       location / { try_files $uri $uri/ =404; }
       location = /ping { rewrite ^ /ping.php last; }
       location ~ ^/(api|ping)\.php$ {
           try_files $uri =404;
           include fastcgi_params;
           fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
           fastcgi_pass unix:/run/php/php8.3-fpm.sock;
       }
       location ~ \.php$ { return 404; }
   }
   ```

   Set `client_max_body_size` to at least 8 MB for imports and photos. Keep
   `data/`, source files, hidden files, and other non-public files inaccessible
   over HTTP. If you already have a server block for the application, add the
   equivalent protections there.

5. Validate and reload nginx, then open the server address in a browser. On first
   use, create the administrator account when prompted.
6. Schedule the automatic checks as the PHP-FPM user. For example, run
   `php /www/bin/check.php` every five minutes with cron. The script checks
   configured team schedules and sends due outage emails.

The dashboard is publicly viewable by default, while administration requires a
dashboard login. Deploy it on a trusted network or restrict access with nginx
network rules or HTTP authentication. Use HTTPS when credentials are entered over
a network.

## Configure and use

Most configuration is managed in the dashboard under **Settings** after logging
in. Set teams and time zones, discovery servers, network ranges, check schedules,
firmware mode, upload limits, and users there. The first account created is the
administrator.

Settings → Users shows each account's last successful login in the browser's
local time. Tracking includes the initial administrator setup; failed attempts,
password changes, and ordinary page visits do not update it. Existing accounts
show **Not recorded** until their next successful login.

To create an account, use **Settings → Users → Add user**, enter a user name,
and choose a role. A strong temporary password is generated and displayed once
in a selectable field. Copy it before dismissing the notice or leaving the page,
and share it securely over a separate trusted channel. The database stores only
its password hash; it cannot be retrieved later. Use HTTPS when creating accounts
or signing in.

New users must replace this temporary password with a different password of at
least eight characters on first login. Until then, the API blocks authenticated
features and returns only the state needed for the password-change screen.
Logging out or reloading does not bypass the requirement. Existing accounts and
the initial administrator setup are unaffected.

The dashboard is organized into **Device Status**, **PC Maintenance**, and
**Firmware Compliance** pages. Add locations on Device Status and manage a
location's devices from its detail page. Import or export lists from the relevant
page; the full JSON backup and restore controls are on Device Status.

Signed-in users can search inventory from the right side of the page navigation.
Search covers all countries, including IP addresses, device names, models, locations,
notes, firmware, and PC details. Select a device or location to open its location;
select a model to list every device with that model (ignoring case and extra spaces).
PC and standalone Dante results open their respective inventory pages with the
correct country selected. Press Enter or select **View all search results** to see
all matches; search URLs can be bookmarked.

Manual checks can be started from the dashboard. Automatic checks run through
`bin/check.php`; configure the team check times in Settings. The dashboard also
provides a compatible `GET /ping?ip=<address>` endpoint for listed inventory and
configured discovery servers.

Automatic checks try ICMP, then TCP, then a read-only OSC `/info` query on UDP
port **10023** for hosts still unreachable. MIDAS M32 (including M32R/M32C) and
Behringer X32 consoles use this UDP control protocol, so ICMP/TCP alone may miss
an otherwise reachable console. The fallback requires a valid OSC reply; merely
sending a UDP packet never marks a host online. Explicit ICMP-only and TCP-only
modes are unchanged. Allow UDP 10023 and return traffic between the dashboard
server and the console's **remote-control Ethernet** address (not an optional
Dante card's separate address).

Protocol reference: [X32/M32 OSC documentation and tools by Patrick-Gilles Maillot](https://github.com/pmaillot/X32-Behringer).

Settings for optional features:

- **Firmware:** comparisons extract unambiguous numeric versions from product labels
  (for example, `BirdDog 4K HDMI 6.1.349`), normalize version prefixes and trailing
  zero components, and preserve prerelease ordering. Minimum mode accepts newer
  versions; exact mode compares normalized versions. Ambiguous version strings
  remain unknown rather than being guessed. Under Settings → Firmware, administrators
  and leads can add or remove **model-based exemptions**. All devices of an exempt
  model are marked compliant, including those without firmware information; matching
  ignores case and repeated whitespace. Exemptions are stored in settings, not in
  inventory-only JSON backups. Removing one restores normal compliance checks.
- **Discovery logs:** configure SSH access in Settings → Discovery Servers. SSH
  client setup, host-key verification, and key/password storage must be prepared
  on the dashboard server. Select **Systemd service journal** as the log source
  and enter `ndi-discovery.service` (the default) to view that service's current-boot
  journal. The viewer refreshes the latest 200 messages every five seconds after
  each response, equivalent to following
  `journalctl -u ndi-discovery.service -b -f --output cat` without holding an SSH
  request open indefinitely. Multiple administrators and leads can watch the same
  server simultaneously: viewers share a five-second snapshot and wait for one
  in-progress SSH refresh instead of starting competing reads. Snapshots are stored
  in the private dashboard database and invalidated when connection or log-source
  settings change. Failed refreshes are briefly shared as errors, never displayed
  as live cached output. The remote SSH user needs journal read permissions
  (for example, membership in `systemd-journal`; reconnect after changing groups).
  The dashboard does not invoke `sudo`. **Log file** remains available for existing
  file-based logs; previously configured file paths keep that source.
- **Outage email:** configure the SMTP relay and recipients in Settings → Email.
  Email is disabled until its master switch is enabled.
- **Photos:** stored under `data/photos/`; include this directory when backing up
  equipment images. Inventory JSON backups preserve photo references, not images.

## Data and backups

On first use, the application creates `data/dashboard.db` automatically. It
contains inventory, settings, accounts, and telemetry. Raw device telemetry is
retained for one year, with annual summaries maintained separately.

Back up the SQLite database and `data/photos/`. For a consistent copy of a
running database, use SQLite's backup command, for example:

```bash
sqlite3 /www/data/dashboard.db ".backup /backup/dashboard.db"
```

The in-app JSON backup is intended for inventory transfer and restore; it does
not include settings, accounts, telemetry, or photo files.

## Development

The repository contains PHP application code in `src/`, the React source in
`frontend/src/`, and committed production assets in `assets/`.

Run the frontend locally with the PHP API:

```bash
# Terminal 1, from the repository root
php -S 127.0.0.1:8000

# Terminal 2
cd frontend
npm install
npm run dev
```

The Vite development server proxies API calls to the PHP server. Check and build
frontend changes with:

```bash
npm run lint
npm run build
```

The build updates the root `index.html` and `assets/` files. From the repository
root, run the existing tests with:

```bash
php tests/telemetry_trends.php
php tests/dante_classification.php
php tests/standalone_dante.php
php tests/standalone_dante_api.php
php tests/discovery_log.php
php tests/firmware_compliance.php
php tests/pinger.php
php tests/users.php
node --test frontend/tests/*.test.mjs
```
