<?php

declare(strict_types=1);

/**
 * JSON API for the React frontend.
 *
 *   GET  api.php?action=state                    -> everything the UI needs (+ CSRF token)
 *   GET  api.php?action=export&type=devices|sites|firmware|pcs|backup  -> file download
 *   GET  api.php?action=photo&id=<id>[&kind=pc]  -> a device's (or PC's) photo
 *   GET  api.php?action=account_photo           -> the signed-in user's profile photo
 *   POST api.php?action=<name>  (header X-CSRF-Token, JSON body or multipart for import)
 *        save_site, delete_site, save_device, delete_device,
 *        save_firmware, delete_firmware, import, check,
 *        upload_photo, delete_photo (kind=pc for PCs),
 *        upload_account_photo, delete_account_photo,
 *        save_pc, delete_pc, complete_pc_check (PC Maintenance's own PC list)
 *        check {target: "standalone", team: "<key>"} checks location-free Dante only
 *   GET  api.php?action=header_status            -> status of the top-bar devices
 *   GET  api.php?action=device_history&id=<id>  -> retained device checks and detected outages
 *   Admin backend: login, logout, setup (first account), and when signed in
 *        save_settings, add_user, delete_user, change_password,
 *        send_report (one country's outage email now), send_test_email
 *
 * Every successful POST returns {"ok": true, "message": "...", "details": [...], "result": ..., "state": {...}}
 * ("result" is {checked, online, offline} for "check").
 * Errors return {"ok": false, "error": "...", "details": [...]} with a 4xx/5xx status.
 *
 * Flood protection: per-client request limits (config `rate_limits`) and, for
 * "check", one check at a time plus global or per-device manual cooldowns
 * (`manual_check_cooldown_seconds`). Both answer HTTP 429 with Retry-After.
 */

require __DIR__ . '/src/bootstrap.php';

use StatusDashboard\AddressPrivacy;
use StatusDashboard\CheckBusy;
use StatusDashboard\CheckGuard;
use StatusDashboard\EquipmentService;
use StatusDashboard\Exporter;
use StatusDashboard\Importer;
use StatusDashboard\Inventory;
use StatusDashboard\Lang;
use StatusDashboard\NetworkUsage;
use StatusDashboard\Settings;

dashboard_track_traffic();
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

enforce_rate_limit('api');

/**
 * @param array<string, mixed> $body
 */
function api_respond(array $body, int $status = 200): never
{
    // Messages are written in English; translate them for German users.
    $lang = dashboard_lang();
    foreach (['message', 'error'] as $key) {
        if (isset($body[$key]) && is_string($body[$key])) {
            $body[$key] = Lang::translate($body[$key], $lang);
        }
    }
    if (isset($body['details']) && is_array($body['details'])) {
        $body['details'] = Lang::translateAll(array_values($body['details']), $lang);
    }
    if (current_user() === null) {
        $body = AddressPrivacy::redact($body);
    }
    session_write_close();
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    exit;
}

/**
 * @param list<string> $details
 */
function api_error(string $message, int $status = 400, array $details = []): never
{
    api_respond(['ok' => false, 'error' => $message, 'details' => $details], $status);
}

function api_too_many(string $message, int $retryAfter): never
{
    header('Retry-After: ' . max(1, $retryAfter));
    api_respond(['ok' => false, 'error' => $message, 'details' => [], 'retry_after' => max(1, $retryAfter)], 429);
}

/**
 * Check schedule and cooldown for the UI. The cooldown is in seconds from now,
 * so the browser's clock doesn't matter; schedule times are Unix timestamps.
 *
 * @return array<string, mixed>
 */
function api_checks(): array
{
    $guard = dashboard_check_guard();
    $schedule = dashboard_check_schedule();
    $last = $guard->lastScheduled();
    $teams = [];
    foreach (dashboard_team_keys() as $team) {
        $tz = dashboard_team_timezone($team);
        $teams[$team] = [
            'timezone'       => $tz,
            'next_scheduled' => CheckGuard::nextSlot($schedule, $tz),
            'last_scheduled' => $last[$team] ?? null,
        ];
    }
    return [
        'cooldown_seconds' => $guard->cooldownSeconds(),
        'available_in'     => $guard->cooldownRemaining(),
        'running'          => $guard->isRunning(),
        'schedule'         => $schedule,
        'teams'            => $teams,  // automatic checks per team, in the team's time zone
    ];
}

/**
 * @return array<string, mixed>
 */
function api_state(string $csrf, ?string $user): array
{
    $config = dashboard_config();
    if ($user !== null && dashboard_users()->mustChangePassword($user)) {
        return [
            'csrf' => $csrf,
            'auth' => ['user' => $user, 'role' => null, 'setup' => false, 'must_change_password' => true],
            'config' => ['title' => (string) ($config['app_title'] ?? 'Equipment Status'), 'teams' => []],
            'sites' => [], 'devices' => [], 'pcs' => [],
        ];
    }
    $data = dashboard_store()->load();
    $rows = (new EquipmentService($config))->buildRows($data);
    foreach ($rows as &$row) {
        if (Inventory::isStandalone($row)) {
            $row['team'] = dashboard_team($row['team']);
        }
    }
    unset($row);

    $sites = $data['sites'];
    foreach ($sites as &$s) {
        $s['team'] = dashboard_team($s['team'] ?? ''); // locations without a team belong to the first team
    }
    unset($s);
    usort($sites, static fn ($a, $b) => strnatcasecmp((string) $a['name'], (string) $b['name']));
    $pcs = (new EquipmentService($config))->buildPcRows($data);
    foreach ($pcs as &$pc) {
        $pc['team'] = dashboard_team($pc['team']); // PCs without a team belong to the first team
    }
    unset($pc);
    $firmware = $data['firmware'];
    usort($firmware, static fn ($a, $b) => strnatcasecmp((string) $a['model'], (string) $b['model']));

    return [
        'csrf'     => $csrf,
        'config'   => [
            'title'             => (string) ($config['app_title'] ?? 'Equipment Status'),
            'subtitle'          => (string) ($config['app_subtitle'] ?? ''),
            'stale_after_hours' => (int) ($config['stale_after_hours'] ?? 0),
            'maintenance_days'  => (int) ($config['maintenance_interval_days'] ?? 90),
            'data_file'         => basename((string) $config['database']),
            'max_import_bytes'  => (int) ($config['max_import_bytes'] ?? 5242880),
            'max_photo_bytes'   => (int) ($config['max_photo_bytes'] ?? 5242880),
            'ping_method'       => dashboard_pinger()->effectiveMethod(),
            'firmware_exemptions' => array_values((array) ($config['firmware_exemptions'] ?? [])),
            'teams'             => array_map(
                static fn ($key, $name): array => ['key' => (string) $key, 'name' => (string) $name],
                array_keys((array) ($config['teams'] ?? [])),
                array_values((array) ($config['teams'] ?? []))
            ),
        ],
        'sites'    => $sites,
        'devices'  => $rows,
        'telemetry' => (object) dashboard_telemetry()->siteSummaries(),
        'telemetry_trends' => (object) dashboard_telemetry()->siteTrends(),
        'telemetry_snapshots' => (object) dashboard_telemetry()->siteSnapshots(),
        'firmware' => $firmware,
        'pcs'      => $pcs,
        'aliases'  => Importer::ALIASES,
        'checks'   => api_checks(),
        'header'   => dashboard_header_status(false), // cached; the UI refreshes it with header_status
        'auth'     => ['user' => $user, 'role' => $user === null ? null : dashboard_users()->role($user), 'setup' => $user === null && dashboard_users()->isEmpty(), 'must_change_password' => false],
    ] + ($user === null ? [] : [
        // Admin backend (Settings page): only for signed-in users.
        'profile'  => dashboard_users()->profile($user),
    ]) + ($user !== null && in_array(dashboard_users()->role($user), ['admin', 'lead'], true) ? [
        'settings' => Settings::editable($config),
        'users'    => dashboard_users()->all(),
    ] : []) + ($user !== null && in_array(dashboard_users()->role($user), ['admin', 'lead'], true) ? [
        'email' => dashboard_email_status(), // Settings → Email: next / last outage email per country
    ] : []);
}

/**
 * Photos belong to a device or (kind=pc) to a PC on the PC Maintenance list.
 */
function api_photo_collection(mixed $kind): string
{
    return $kind === 'pc' ? 'pcs' : 'devices';
}

/**
 * @return array<string, mixed>
 */
function api_body(): array
{
    if (str_starts_with((string) ($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
        $decoded = json_decode((string) file_get_contents('php://input'), true);
        if (!is_array($decoded)) {
            api_error('Invalid JSON body.');
        }
        return $decoded;
    }
    return $_POST;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = (string) ($_GET['action'] ?? 'state');
$config = dashboard_config();
$store = dashboard_store();

try {
    $sessionUser = current_user();
    if ($sessionUser !== null && dashboard_users()->mustChangePassword($sessionUser)
        && !(($method === 'GET' && $action === 'state')
            || ($method === 'POST' && in_array($action, ['login', 'logout', 'change_password'], true)))) {
        api_error('You must change your temporary password before continuing.', 403);
    }
    if ($method === 'GET' && $action === 'state') {
        $csrf = csrf_token();
        $user = current_user();
        session_write_close();
        api_respond(['ok' => true, 'state' => api_state($csrf, $user)]);
    }

    if ($method === 'GET' && $action === 'header_status') {
        api_respond(['ok' => true, 'header' => dashboard_header_status(true)]);
    }

    if ($method === 'GET' && in_array($action, ['traffic_usage', 'ping_usage'], true)) {
        $user = current_user();
        $role = $user === null ? null : dashboard_users()->role($user);
        session_write_close();
        if ($role !== 'admin') {
            api_error('Please log in as an administrator to view traffic usage.', 401);
        }
        $usage = NetworkUsage::summary(dashboard_db());
        if ($action === 'ping_usage') {
            $usage = array_map(static fn (array $total): array => [
                'checks' => 0, 'hosts' => $total['ping_hosts'], 'online' => 0, 'offline' => 0,
                'sent_bytes' => $total['out_bytes'], 'received_bytes' => $total['in_bytes'],
            ], $usage['totals']);
        }
        api_respond(['ok' => true, 'usage' => $usage]);
    }

    if ($method === 'GET' && $action === 'device_history') {
        $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false || $id === null) {
            api_error('A valid device id is required.');
        }
        $history = dashboard_telemetry()->deviceHistory($id);
        if ($history === null) {
            api_error('Device not found.', 404);
        }
        api_respond(['ok' => true, 'telemetry' => $history]);
    }

    if ($method === 'GET' && $action === 'discovery_log') {
        $user = current_user();
        $role = $user === null ? null : dashboard_users()->role($user);
        session_write_close();
        if (!in_array($role, ['admin', 'lead'], true)) {
            api_error('Please log in to view discovery server logs.', 401);
        }
        $index = filter_var($_GET['server'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        $devices = array_values((array) ($config['header_devices'] ?? []));
        $device = $index !== false && $index !== null ? ($devices[$index] ?? null) : null;
        if (!is_array($device) || empty($device['log_enabled'])) {
            api_error('Discovery server log viewing is not configured.', 404);
        }
        if (!is_string($_GET['host'] ?? null) || $_GET['host'] !== (string) $device['ip']) {
            api_error('Discovery server configuration changed. Reopen the log window from the top bar.', 409);
        }
        try {
            $log = (new StatusDashboard\DiscoveryLog(dashboard_data_dir() . '/ssh'))->readShared(dashboard_db(), $device);
        } catch (RuntimeException $e) {
            api_error($e->getMessage(), 502);
        }
        api_respond(['ok' => true, 'log' => $log, 'server' => ['name' => $device['name'], 'ip' => $device['ip']]]);
    }

    if ($method === 'GET' && $action === 'export') {
        // Exports and backups contain the whole inventory: signed-in users only.
        $user = current_user();
        $role = $user === null ? null : dashboard_users()->role($user);
        session_write_close();
        if (!in_array($role, ['admin', 'lead'], true)) {
            api_error('Please log in to export data.', 401);
        }
        $type = (string) ($_GET['type'] ?? 'devices');
        if (!in_array($type, ['devices', 'sites', 'firmware', 'pcs', 'backup'], true)) {
            api_error('Unknown export type.');
        }
        $data = $store->load();
        $stamp = date('Ymd-His');
        if ($type === 'backup') {
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="equipment-backup-' . $stamp . '.json"');
            echo json_encode(Exporter::backup($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            exit;
        }
        $rows = $type === 'pcs' ? (new EquipmentService($config))->buildPcRows($data) : (new EquipmentService($config))->buildRows($data);
        $siteId = (int) ($_GET['site_id'] ?? 0);
        $suffix = '';
        if ($type === 'devices' && $siteId > 0) {
            $site = Inventory::findRecord($data, 'sites', $siteId);
            if ($site === null) {
                api_error('Unknown location.', 404);
            }
            $rows = array_values(array_filter($rows, static fn (array $r): bool => $r['site_id'] === $siteId));
            $suffix = '-' . trim((string) preg_replace('/[^A-Za-z0-9]+/', '-', (string) (($site['code'] ?? '') !== '' ? $site['code'] : $site['name'])), '-');
        }
        [$header, $table] = Exporter::table($type, $data, $rows);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="equipment-' . $type . $suffix . '-' . $stamp . '.csv"');
        $out = fopen('php://output', 'wb');
        Exporter::writeCsv($out, $header, $table);
        fclose($out);
        exit;
    }

    if ($method === 'GET' && $action === 'photo') {
        $device = Inventory::findRecord($store->load(), api_photo_collection($_GET['kind'] ?? ''), (int) ($_GET['id'] ?? 0));
        $file = $device !== null ? dashboard_photos()->file((string) ($device['photo'] ?? '')) : null;
        if ($file === null) {
            api_error('No photo for this device.', 404);
        }
        session_write_close();
        header('Content-Type: ' . $file[1]);
        header('Content-Length: ' . filesize($file[0]));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'");
        header('Cache-Control: private, max-age=86400'); // the URL changes when the photo changes
        readfile($file[0]);
        exit;
    }

    if ($method === 'GET' && $action === 'account_photo') {
        $user = current_user();
        if ($user === null) {
            api_error('Please log in to view your account photo.', 401);
        }
        $photo = dashboard_users()->profilePhoto($user);
        if ($photo === null) {
            api_error('No account photo is set.', 404);
        }
        session_write_close();
        header('Content-Type: ' . $photo['mime']);
        header('Content-Length: ' . strlen($photo['photo']));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'");
        echo $photo['photo'];
        exit;
    }

    if ($method === 'GET' && $action === 'user_photo') {
        $user = current_user();
        if ($user === null) {
            api_error('Please log in to view account photos.', 401);
        }
        if (!in_array(dashboard_users()->role($user), ['admin', 'lead'], true)) {
            api_error('Your account does not have permission to view other account photos.', 403);
        }
        $photo = dashboard_users()->profilePhoto((string) ($_GET['username'] ?? ''));
        if ($photo === null) {
            api_error('No account photo is set.', 404);
        }
        session_write_close();
        header('Content-Type: ' . $photo['mime']);
        header('Content-Length: ' . strlen($photo['photo']));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'");
        header('Cache-Control: private, max-age=86400');
        echo $photo['photo'];
        exit;
    }

    if ($method !== 'POST') {
        api_error('Method not allowed.', 405);
    }
    if ($action !== 'check') {
        enforce_rate_limit('write'); // checks have their own cooldown below
    }

    if (!csrf_valid($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
        api_error('Your session has expired or the upload was too large. Reload the page and try again.', 403);
    }
    $body = api_body();
    $user = current_user();

    // Sign in / out and first-run setup change the session, so they run before it is closed.
    if ($action === 'login' || $action === 'setup') {
        enforce_rate_limit('login');
        $name = (string) ($body['username'] ?? '');
        $password = (string) ($body['password'] ?? '');
        $users = dashboard_users();
        if ($action === 'setup') {
            if (!$users->add($name, $password, true, 'admin')) {
                api_error('An administrator account already exists. Please log in.', 409);
            }
            $user = \StatusDashboard\Users::validName($name);
            $message = 'Administrator account created. You are logged in.';
        } else {
            $user = $users->verify($name, $password);
            if ($user === null) {
                api_error('Wrong user name or password.', 401);
            }
            $message = "Logged in as {$user}.";
        }
        set_current_user($user);
        $users->recordLogin($user);
        $csrf = csrf_token();
        session_write_close();
        api_respond(['ok' => true, 'message' => $message, 'details' => [], 'result' => null, 'state' => api_state($csrf, $user)]);
    }
    if ($action === 'logout') {
        set_current_user(null);
        $csrf = csrf_token();
        session_write_close();
        api_respond(['ok' => true, 'message' => 'Logged out.', 'details' => [], 'result' => null, 'state' => api_state($csrf, null)]);
    }

    $csrf = csrf_token();
    // Release the session lock so long checks don't block other requests.
    session_write_close();

    $role = $user === null ? null : dashboard_users()->role($user);
    if ($user === null) {
        api_error('Please log in to make changes.', 401);
    }
    $userActions = ['change_password', 'upload_account_photo', 'delete_account_photo', 'complete_pc_check', 'save_theme'];
    if ($role === 'user' && !in_array($action, $userActions, true) && $action !== 'check') {
        api_error('Your account does not have permission to perform this action.', 403);
    }
    if ($role === 'lead' && $action === 'delete_user') {
        api_error('Leads cannot delete users.', 403);
    }
    $onlineValues = (array) ($config['online_values'] ?? ['online']);
    $id = (int) ($body['id'] ?? 0);
    $details = [];
    $result = null;

    switch ($action) {
        case 'save_site':
            if (array_key_exists('team', $body) || $id === 0) {
                $body['team'] = dashboard_team($body['team'] ?? '');
            }
            $result = ['id' => $store->update(static fn (array &$d) => Inventory::saveSite($d, $body))];
            $message = $id > 0 ? 'Location updated.' : 'Location added.';
            break;

        case 'delete_site':
            dashboard_photos()->prune($store->update(static function (array &$d) use ($id): array {
                Inventory::deleteSite($d, $id);
                return $d;
            }));
            $message = 'Location and its devices deleted.';
            break;

        case 'save_device':
            if (($body['ownership'] ?? '') === 'standalone' || array_key_exists('team', $body)) {
                $body['team'] = dashboard_team($body['team'] ?? '');
            }
            $result = ['id' => $store->update(static fn (array &$d) => Inventory::saveDevice($d, $body, $onlineValues))];
            $message = $id > 0 ? 'Device updated.' : 'Device added.';
            break;

        case 'delete_device':
            dashboard_photos()->prune($store->update(static function (array &$d) use ($id): array {
                Inventory::deleteDevice($d, $id);
                return $d;
            }));
            $message = 'Device deleted.';
            break;

        case 'upload_photo':
            $file = $_FILES['photo'] ?? null;
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
                $code = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                throw new InvalidArgumentException(match ($code) {
                    UPLOAD_ERR_NO_FILE => 'Please choose a photo to upload.',
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The photo is too large.',
                    default => 'The file could not be uploaded (error ' . $code . ').',
                });
            }
            $collection = api_photo_collection($body['kind'] ?? '');
            if (Inventory::findRecord($store->load(), $collection, $id) === null) {
                throw new InvalidArgumentException('Unknown device.');
            }
            $photos = dashboard_photos();
            $name = $photos->store($id, (string) $file['tmp_name']);
            try {
                $data = $store->update(static function (array &$d) use ($id, $name, $collection): array {
                    Inventory::setPhoto($d, $id, $name, $collection);
                    return $d;
                });
            } finally {
                $photos->prune($data ?? $store->load()); // removes the replaced photo
            }
            $message = 'Photo saved.';
            break;

        case 'delete_photo':
            $collection = api_photo_collection($body['kind'] ?? '');
            dashboard_photos()->prune($store->update(static function (array &$d) use ($id, $collection): array {
                Inventory::setPhoto($d, $id, '', $collection);
                return $d;
            }));
            $message = 'Photo removed.';
            break;

        case 'upload_account_photo':
            $file = $_FILES['photo'] ?? null;
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
                $code = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                throw new InvalidArgumentException(match ($code) {
                    UPLOAD_ERR_NO_FILE => 'Please choose a photo to upload.',
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The photo is too large.',
                    default => 'The file could not be uploaded (error ' . $code . ').',
                });
            }
            dashboard_users()->setProfilePhoto($user, (string) $file['tmp_name'], (int) ($config['max_photo_bytes'] ?? 5242880));
            $message = 'Profile photo saved.';
            break;

        case 'delete_account_photo':
            dashboard_users()->deleteProfilePhoto($user);
            $message = 'Profile photo removed.';
            break;

        case 'save_pc':
            if (array_key_exists('team', $body) || $id === 0) {
                $body['team'] = dashboard_team($body['team'] ?? '');
            }
            $result = ['id' => $store->update(static fn (array &$d) => Inventory::savePc($d, $body))];
            $message = $id > 0 ? 'PC updated.' : 'PC added.';
            break;

        case 'delete_pc':
            dashboard_photos()->prune($store->update(static function (array &$d) use ($id): array {
                Inventory::deletePc($d, $id);
                return $d;
            }));
            $message = 'PC deleted.';
            break;

        case 'complete_pc_check':
            $name = $store->update(static function (array &$d) use ($id, $body, $user): string {
                Inventory::completePcCheck($d, $id, (string) $user, (string) ($body['comments'] ?? ''), date('Y-m-d'));
                return (string) Inventory::findRecord($d, 'pcs', $id)['name'];
            });
            $message = "Check completed for {$name} by {$user}.";
            break;

        case 'save_settings':
            if ($role === 'lead') {
                $restricted = Settings::editable($config);
                $readOnlySettings = ['app_title', 'app_subtitle', 'timezone', 'teams'];
                foreach ($restricted as $key => $_) {
                    if (!in_array($key, $readOnlySettings, true) && array_key_exists($key, $body)) {
                        $restricted[$key] = $body[$key];
                    }
                }
                $body = $restricted;
            }
            Settings::save(dashboard_db(), Settings::validate($body, $config,
                new StatusDashboard\SshPassword(dashboard_data_dir() . '/ssh/password.key')), true);
            dashboard_config(true);
            $config = dashboard_config();
            $message = 'Settings saved.';
            break;

        case 'add_user':
            $newRole = (string) ($body['role'] ?? 'user');
            if ($role === 'lead' && $newRole === 'admin') {
                api_error('Leads cannot add Admin accounts.', 403);
            }
            $temporaryPassword = dashboard_users()->addTemporary((string) ($body['username'] ?? ''), $newRole);
            $result = ['username' => \StatusDashboard\Users::validName((string) ($body['username'] ?? '')), 'temporary_password' => $temporaryPassword];
            $message = 'User added.';
            break;

        case 'change_user_role':
            $name = (string) ($body['username'] ?? '');
            if (strcasecmp($name, (string) $user) === 0) {
                throw new InvalidArgumentException('You cannot change your own role.');
            }
            if ($role === 'lead' && (dashboard_users()->role($name) === 'admin' || ($body['role'] ?? '') === 'admin')) {
                api_error('Leads cannot assign or change Admin roles.', 403);
            }
            dashboard_users()->setRole($name, (string) ($body['role'] ?? ''));
            $message = 'User role updated.';
            break;

        case 'delete_user':
            $name = (string) ($body['username'] ?? '');
            if (strcasecmp($name, (string) $user) === 0) {
                throw new InvalidArgumentException('You can’t delete your own account.');
            }
            dashboard_users()->delete($name);
            $message = 'User deleted.';
            break;

        case 'change_password':
            dashboard_users()->changePassword((string) $user, (string) ($body['current'] ?? ''), (string) ($body['password'] ?? ''));
            $message = 'Password changed.';
            break;

        case 'save_theme':
            dashboard_users()->setTheme((string) $user, (string) ($body['theme'] ?? ''));
            $message = 'Theme saved.';
            break;

        case 'send_report':
            $team = (string) ($body['team'] ?? '');
            if (!in_array($team, dashboard_team_keys(), true)) {
                throw new InvalidArgumentException('Unknown country.');
            }
            $result = dashboard_send_report($team);
            if ($result['skipped']) {
                $message = 'Nothing needs attention, so no email was sent (Only send when devices need attention).';
            } elseif ($result['failed'] !== []) {
                api_error(sprintf('Outage email sent to %d of %d recipient(s).', $result['sent'], $result['sent'] + count($result['failed'])) . ' ' . $result['error'], 502, $result['failed']);
            } else {
                $message = sprintf('Outage email sent to %d recipient(s).', $result['sent']);
            }
            break;

        case 'send_test_email':
            try {
                dashboard_mailer()->sendTest(trim((string) ($body['to'] ?? '')), dashboard_lang());
            } catch (RuntimeException $e) {
                api_error($e->getMessage(), 502);
            }
            $message = 'Test email sent.';
            break;

        case 'set_firmware_exemption':
            if (!is_string($body['model'] ?? null) || !is_bool($body['exempt'] ?? null)) {
                throw new InvalidArgumentException('Specify a model and whether it is exempt.');
            }
            Settings::setFirmwareExemption(dashboard_db(), $body['model'], $body['exempt'], (array) ($config['firmware_exemptions'] ?? []));
            dashboard_config(true);
            $message = $body['exempt'] ? 'Firmware exemption added.' : 'Firmware exemption removed.';
            break;

        case 'save_firmware':
            $store->update(static fn (array &$d) => Inventory::saveFirmware($d, $body));
            $message = $id > 0 ? 'Latest firmware updated.' : 'Latest firmware added.';
            break;

        case 'delete_firmware':
            $store->update(static fn (array &$d) => Inventory::deleteFirmware($d, $id));
            $message = 'Latest firmware deleted.';
            break;

        case 'import':
            $file = $_FILES['file'] ?? null;
            if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $file['tmp_name'])) {
                $code = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                throw new InvalidArgumentException(match ($code) {
                    UPLOAD_ERR_NO_FILE => 'Please choose a file to import.',
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The file is too large (server limit: ' . ini_get('upload_max_filesize') . ').',
                    default => 'The file could not be uploaded (error ' . $code . ').',
                });
            }
            if ((int) $file['size'] > (int) ($config['max_import_bytes'] ?? 5242880)) {
                throw new InvalidArgumentException('The file is too large.');
            }
            $content = (string) file_get_contents((string) $file['tmp_name']);
            $type = (string) ($body['type'] ?? 'devices');
            $mode = ($body['mode'] ?? 'merge') === 'replace' ? 'replace' : 'merge';
            $importer = new Importer($onlineValues);
            $siteOnly = ($body['scope'] ?? '') === 'site';
            $team = dashboard_team($body['team'] ?? ''); // PCs without a team column go to the selected team
            $result = $store->update(static function (array &$d) use ($importer, $content, $type, $mode, $body, $siteOnly, $team): array {
                $result = $importer->import($d, $content, $type, $mode, (int) ($body['site_id'] ?? 0), null, $siteOnly, $team);
                if ($result['restored']) {
                    dashboard_telemetry()->clearForRestore();
                }
                return $result;
            });

            if ($result['restored']) {
                $message = sprintf('Backup restored: %d locations and %d devices/latest firmware versions.', $result['sites_created'], $result['created']);
            } else {
                $message = sprintf('Import finished: %d added, %d updated, %d skipped.', $result['created'], $result['updated'], $result['skipped']);
                if ($result['sites_created'] > 0) {
                    $message .= sprintf(' %d new location(s) created.', $result['sites_created']);
                }
            }
            $details = $result['errors'];
            if ($result['restored'] || $mode === 'replace') {
                dashboard_photos()->prune($store->load());
            }
            break;

        case 'check':
            $siteId = (int) ($body['site_id'] ?? 0);
            $deviceId = null;
            if (array_key_exists('device_id', $body)) {
                $deviceId = filter_var($body['device_id'], FILTER_VALIDATE_INT);
                if ($deviceId === false || $deviceId < 1) {
                    throw new InvalidArgumentException('Invalid device ID.');
                }
            }
            // Independent lists are checked in the selected team, never as a synthetic location.
            $target = in_array($body['target'] ?? '', ['pcs', 'standalone'], true) ? $body['target'] : 'devices';
            $checkTeam = $target !== 'devices' ? dashboard_team($body['team'] ?? '') : null;
            if ($deviceId !== null && ($siteId <= 0 || $target !== 'devices')) {
                throw new InvalidArgumentException('A device check requires a location.');
            }
            if ($target !== 'devices' && $siteId > 0) {
                throw new InvalidArgumentException('A location cannot be combined with this check target.');
            }
            $siteName = 'all locations';
            if ($siteId > 0) {
                $site = Inventory::findRecord($store->load(), 'sites', $siteId);
                if ($site === null) {
                    throw new InvalidArgumentException('Unknown location.');
                }
                $siteName = (string) $site['name'];
            }
            $deviceName = '';
            if ($deviceId !== null) {
                $device = Inventory::findRecord($store->load(), 'devices', $deviceId);
                if ($device === null || (int) ($device['site_id'] ?? 0) !== $siteId) {
                    throw new InvalidArgumentException('Device not found at this location.');
                }
                $deviceName = (string) $device['name'];
            }
            $guard = dashboard_check_guard();
            if ($guard->isRunning()) {
                api_too_many('A status check is already running. Try again when it has finished.', 10);
            }
            $wait = $guard->beginManual((string) ($body['run'] ?? ''), $siteId > 0 ? $siteId : null, null, $deviceId);
            if ($wait > 0) {
                api_too_many("Please wait {$wait} seconds before running another check.", $wait);
            }
            ignore_user_abort(true);
            set_time_limit(0);
            try {
                $summary = $checkTeam !== null
                    ? run_status_check(null, null, false, $checkTeam, $target)
                    : run_status_check($siteId > 0 ? $siteId : null, null, false, null, $deviceId !== null ? 'device' : 'devices', $deviceId);
            } catch (CheckBusy $e) {
                api_too_many($e->getMessage(), 10);
            } finally {
                $guard->finishManual(null, $deviceId);
            }
            $result = $summary;
            $message = $target === 'standalone'
                ? sprintf('Checked standalone Dante: %d device(s), %d online, %d offline.', $summary['checked'], $summary['online'], $summary['offline'])
                : ($checkTeam !== null
                ? sprintf('Checked %d PC(s): %d online, %d offline.', $summary['checked'], $summary['online'], $summary['offline'])
                : ($deviceId !== null
                    ? sprintf('Checked %s: %d online, %d offline.', $deviceName, $summary['online'], $summary['offline'])
                    : sprintf('Checked %s: %d device(s), %d online, %d offline.', $siteName, $summary['checked'], $summary['online'], $summary['offline'])));
            break;

        default:
            api_error('Unknown action.', 404);
    }

    api_respond(['ok' => true, 'message' => $message, 'details' => $details, 'result' => $result, 'state' => api_state($csrf, $user)]);
} catch (InvalidArgumentException $e) {
    api_error($e->getMessage(), 422);
} catch (Throwable $e) {
    error_log('Equipment dashboard: ' . $e->getMessage());
    api_error('Something went wrong: ' . $e->getMessage(), 500);
}
