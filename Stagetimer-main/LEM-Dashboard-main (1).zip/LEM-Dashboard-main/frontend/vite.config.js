import { cpSync, rmSync } from 'node:fs'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// After building into frontend/dist, copy index.html + assets/ into the project
// root so the project folder can be copied to /www as-is (no Node on the server).
const publishToRoot = {
  name: 'publish-to-project-root',
  apply: 'build',
  closeBundle() {
    const dist = new URL('./dist/', import.meta.url)
    const root = new URL('../', import.meta.url)
    rmSync(new URL('assets', root), { recursive: true, force: true })
    cpSync(new URL('assets', dist), new URL('assets', root), { recursive: true })
    cpSync(new URL('index.html', dist), new URL('index.html', root))
  },
}

export default defineConfig({
  plugins: [react(), publishToRoot],
  base: './',
  publicDir: false,
  server: {
    // npm run dev: forward API calls to PHP, e.g. `php -S 127.0.0.1:8000` in the project root.
    proxy: {
      '/api.php': 'http://127.0.0.1:8000',
      '/ping': 'http://127.0.0.1:8000',
    },
  },
})
