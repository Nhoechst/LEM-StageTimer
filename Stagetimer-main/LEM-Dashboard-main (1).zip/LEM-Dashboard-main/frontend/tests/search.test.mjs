import assert from 'node:assert/strict'
import { after, test } from 'node:test'
import React from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { createServer } from 'vite'
import { inventoryIndex, searchInventory, searchTarget } from '../src/search.js'
import { parseHash } from '../src/routing.js'

const state = {
  auth: { user: 'viewer', role: 'user' },
  sites: [
    { id: 1, name: 'Control Room', code: 'CR1', subnet: '10.0.0.0/24', team: 'us', address: 'First Avenue', notes: 'Basement' },
    { id: 2, name: 'Berlin Studio', code: 'DE1', team: 'de' },
  ],
  devices: [
    { id: 1, name: 'Encoder <one>', ip: '10.0.0.1', site_id: 1, model: 'BirdDog 4K', type: 'NDI', firmware: '1.2', notes: 'Rack 7', status: 'online', compliance: 'compliant' },
    { id: 2, name: 'Camera two', ip: '2001:db8::2', site_id: 2, team: '', model: ' BIRDDOG   4K ', status: 'offline', compliance: 'unknown' },
    { id: 3, name: 'Different encoder', ip: '10.0.0.10', site_id: 1, model: 'BirdDog 4K Plus' },
    { id: 4, name: 'Standalone audio', ip: '10.1.0.3', ownership: 'standalone', site_id: 0, model: 'Audio & USB/#?%', team: 'de' },
  ],
  pcs: [{ id: 1, name: 'Editing PC', ip: '10.1.0.4', location: 'Suite B', os: 'Windows 11', type: 'Desktop', comments: 'Graphics replacement', team: 'de', checked_by: 'Alice' }],
}
const index = inventoryIndex(state)

test('search ranks exact IPs first and links devices/locations to their owning location', () => {
  assert.equal(searchInventory(index, '10.0.0.1')[0].key, 'device-1')
  assert.equal(searchInventory(index, '10.0.0.1')[0].target, 'location/1')
  assert.equal(searchInventory(index, '2001:DB8::2')[0].target, 'location/2')
  assert.equal(searchInventory(index, 'CR1').find(result => result.kind === 'Location').target, 'location/1')
  assert.equal(searchInventory(index, 'Control Room').find(result => result.kind === 'Location').target, 'location/1')
  assert.equal(searchInventory(index, 'first avenue')[0].kind, 'Location')
  assert.equal(searchInventory(index, 'basement')[0].kind, 'Location')
})

test('model results group normalized model names and include all locations without substring variants', () => {
  const model = searchInventory(index, 'birddog 4k').find(result => result.kind === 'Model' && result.count === 2)
  assert.ok(model)
  assert.equal(searchInventory(index, 'birddog 4k')[0].kind, 'Model')
  assert.equal(model.target, 'search?model=BirdDog+4K')
  const devices = searchInventory(index, '', 'birddog   4k')
  assert.deepEqual(devices.map(result => result.key), ['device-1', 'device-2'])
  assert.ok(devices.some(result => result.target === 'location/2'))
  assert.ok(searchInventory(index, 'birddog de').some(result => result.key === 'device-2'))
  assert.match(devices[1].detail, / · de$/)
})

test('search handles partial names, combined terms, notes, firmware, PC metadata and standalone inventory', () => {
  assert.equal(searchInventory(index, 'encoder rack 7')[0].key, 'device-1')
  assert.equal(searchInventory(index, 'ndi 1.2')[0].key, 'device-1')
  assert.equal(searchInventory(index, 'windows suite')[0].target, 'maintenance?team=de')
  assert.equal(searchInventory(index, 'alice')[0].key, 'pc-1')
  assert.equal(searchInventory(index, 'graphics')[0].key, 'pc-1')
  assert.equal(searchInventory(index, '10.1.0.3')[0].target, 'dante?team=de')
  assert.deepEqual(searchInventory(index, '   '), [])
  assert.deepEqual(searchInventory(index, 'does not exist'), [])
})

test('search never indexes anonymous inventory or unrelated sensitive state fields', () => {
  assert.deepEqual(inventoryIndex({ ...state, auth: { user: null } }), [])
  assert.deepEqual(inventoryIndex(null), [])
  const withSecrets = inventoryIndex({ ...state, settings: { password: 'private-secret' }, users: [{ name: 'private-user' }] })
  assert.deepEqual(searchInventory(withSecrets, 'private-secret'), [])
  assert.deepEqual(searchInventory(withSecrets, 'private-user'), [])
})

globalThis.document = { documentElement: { lang: 'en' } }
const server = await createServer({ root: new URL('../', import.meta.url).pathname, server: { middlewareMode: true } })
after(() => server.close())
const { default: GlobalSearch, SearchPage } = await server.ssrLoadModule('/src/components/GlobalSearch.jsx')
const { applyLanguageChoice } = await server.ssrLoadModule('/src/i18n.js')
const render = (component, props) => renderToStaticMarkup(React.createElement(component, props))
applyLanguageChoice('en')

test('search routes round-trip reserved characters, IPv6 and Unicode; existing routes stay valid', () => {
  for (const value of ['10.0.0.1', '2001:db8::2', 'Audio & USB/#?%', 'Gerät München']) {
    assert.deepEqual(parseHash(`#${searchTarget(value)}`), { page: 'search', query: value, model: null })
    assert.deepEqual(parseHash(`#${searchTarget(value, true)}`), { page: 'search', query: '', model: value })
  }
  assert.deepEqual(parseHash('#search'), { page: 'search', query: '', model: null })
  assert.deepEqual(parseHash('#maintenance?team=de'), { page: 'maintenance', team: 'de' })
  assert.deepEqual(parseHash('#dante?team=us'), { page: 'dante', team: 'us' })
  for (const route of ['#site/2', '#location/2', '#/locations/2']) assert.deepEqual(parseHash(route), { page: 'site', siteId: 2 })
  assert.deepEqual(parseHash('#firmware'), { page: 'compliance' })
})

test('search renders accessible input and escaped model results with location links', () => {
  const input = render(GlobalSearch, { index })
  assert.match(input, /role="search" aria-label="Search inventory"/)
  assert.match(input, /type="search"/)
  assert.match(input, /placeholder="Search IP, model, location…"/)
  const html = render(SearchPage, { index, query: '', model: 'BirdDog 4K' })
  assert.match(html, /Devices with model: BirdDog 4K/)
  assert.match(html, /2 result\(s\) across all countries/)
  assert.match(html, /href="#location\/1"/)
  assert.match(html, /href="#location\/2"/)
  assert.match(html, /Encoder &lt;one&gt;/)
  assert.doesNotMatch(html, /<one>|Different encoder/)
  assert.match(render(SearchPage, { index, query: 'nonexistent', model: null }), /No matching inventory found\./)
})

test('large result sets remain bounded with a show-more control and translated search labels', () => {
  const many = Array.from({ length: 55 }, (_, id) => ({ ...index[0], key: `many-${id}` }))
  const html = render(SearchPage, { index: many, query: 'encoder', model: null })
  assert.equal((html.match(/class="inventory-search-result"/g) ?? []).length, 50)
  assert.match(html, /Show more results/)
  applyLanguageChoice('de')
  try {
    assert.match(render(GlobalSearch, { index }), /Inventar durchsuchen/)
    assert.match(render(SearchPage, { index, query: '', model: 'BirdDog 4K' }), /Geräte mit Modell/)
  } finally {
    applyLanguageChoice('en')
  }
})
