import assert from 'node:assert/strict'
import { after, test } from 'node:test'
import React from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { createServer } from 'vite'

globalThis.document = { documentElement: { lang: 'en' } }
const server = await createServer({ root: new URL('../', import.meta.url).pathname, server: { middlewareMode: true } })
after(() => server.close())
const { default: Dashboard } = await server.ssrLoadModule('/src/components/Dashboard.jsx')
const { default: DanteManager } = await server.ssrLoadModule('/src/components/DanteManager.jsx')
const { default: Maintenance } = await server.ssrLoadModule('/src/components/Maintenance.jsx')
const { default: Settings } = await server.ssrLoadModule('/src/components/Settings.jsx')
const { PasswordChangeForm } = await server.ssrLoadModule('/src/components/Account.jsx')
const { RecordDialog } = await server.ssrLoadModule('/src/components/Dialogs.jsx')
const { applyLanguageChoice } = await server.ssrLoadModule('/src/i18n.js')
applyLanguageChoice('en')
const standalone = { id: 3, site_id: 0, site: '', ownership: 'standalone', team: 'de', name: 'Standalone audio', ip: '*******', status: 'online', type: 'Dante', dante: true, notes: 'Audio rack' }
const location = { id: 2, site_id: 1, site: 'Studio', ownership: 'location', name: 'Location audio', ip: '*******', status: 'online', type: 'Dante', dante: true, notes: 'Stage box' }
const render = (component, props) => renderToStaticMarkup(React.createElement(component, props))

test('settings users show localized last login and unknown historical values', async () => {
  const { fmtTime } = await server.ssrLoadModule('/src/format.js')
  const timestamp = 1792526400
  const state = {
    auth: { user: 'Admin', role: 'admin' },
    settings: {
      teams: [], header_devices: [], online_values: [], corporate_networks: [], external_networks: [],
      check_schedule: [], ping: { tcp_ports: [80] }, email: { times: [] },
      rate_limits: { api: [0, 0], write: [0, 0], ping: [0, 0], login: [0, 0] },
    },
    users: [
      { username: 'Admin', role: 'admin', created: '2025-01-01', last_login: timestamp },
      { username: 'NewUser', role: 'user', last_login: null },
    ],
  }
  for (const [language, heading, unknown] of [['en', 'Last logged in', 'Not recorded'], ['de', 'Zuletzt angemeldet', 'Nicht erfasst']]) {
    applyLanguageChoice(language)
    const html = render(Settings, { state, section: 'users' })
    assert.ok(html.includes(heading))
    assert.ok(html.includes(unknown))
    assert.ok(html.includes(fmtTime(timestamp)))
    assert.doesNotMatch(html, /Invalid Date|NaN/)
    assert.ok(html.includes(language === 'en' ? 'A strong temporary password is generated automatically.' : 'Ein starkes temporäres Passwort wird automatisch erstellt.'))
    assert.doesNotMatch(html, /type="password"/)
  }
  applyLanguageChoice('en')
})

test('mandatory password change reuses password validation fields without account controls', () => {
  const html = render(PasswordChangeForm, { required: true, onSave() {} })
  assert.match(html, /You must change your temporary password before continuing\./)
  assert.match(html, /Temporary password/)
  assert.equal((html.match(/type="password"/g) ?? []).length, 3)
  assert.equal((html.match(/autoComplete="new-password"/gi) ?? []).length, 2)
  assert.match(html, /minLength="8"/)
  assert.doesNotMatch(html, /Cancel|Upload photo|Appearance/)
  const ordinary = render(PasswordChangeForm, { onSave() {} })
  assert.match(ordinary, /Current password/)
  assert.doesNotMatch(ordinary, /temporary password before continuing/)
  applyLanguageChoice('de')
  const german = render(PasswordChangeForm, { required: true, onSave() {} })
  assert.match(german, /Temporäres Passwort/)
  assert.match(german, /Du musst dein temporäres Passwort ändern/)
  applyLanguageChoice('en')
})

test('dashboard mingles both Dante ownerships without editable titles or fake location links', () => {
  const props = {
    user: 'viewer',
    state: { devices: [standalone, location], sites: [{ id: 1, name: 'Studio' }], config: {} }, siteSummaries: [],
    total: { total: 2, online: 2, offline: 0, external: 0, no_status: 0 }, checking: { deviceIds: new Set() },
  }
  const html = render(Dashboard, { ...props, admin: true })
  assert.match(html, /<span class="device-title-chip">Standalone audio<\/span>/)
  assert.match(html, /<span class="device-title-chip">Location audio<\/span>/)
  assert.match(html, /<td>Audio rack<\/td>/)
  assert.match(html, /<td>Stage box<\/td>/)
  assert.doesNotMatch(html, /<td>Standalone<\/td>|network-location"/)
  assert.match(html, /Add Dante device/)
  assert.match(html, /aria-label="Add Dante device"[^>]*><svg[^>]*>.*?<\/svg><\/button><span class="count-pill tone-dante">2 devices<\/span>/)
  assert.doesNotMatch(html, /Manage standalone Dante|Check standalone/)
  assert.doesNotMatch(html, /http:\/\/\*|Edit device/)
  const readOnly = render(Dashboard, { ...props, admin: false })
  assert.doesNotMatch(readOnly, /Add Dante device|Manage standalone Dante/)
  assert.match(readOnly, /class="count-pill tone-dante">2 devices<\/span>/)
  const signedOut = render(Dashboard, { ...props, user: null })
  assert.doesNotMatch(signedOut, /class="network-row"|Needs attention|Standalone audio|Location audio/)
  assert.match(signedOut, /Location Summary/)
  assert.match(signedOut, /class="panel summary-panel additional-stats"><button type="button" class="additional-stats-login"/)
  assert.match(signedOut, /Login for Additional Stats/)
})

test('Dante endpoints never appear in Needs attention, regardless of status or ownership', () => {
  for (const status of ['offline', 'stale', 'unknown']) {
    const html = render(Dashboard, {
      user: 'viewer', state: { devices: [{ ...standalone, status }, { ...location, status }], sites: [] },
      siteSummaries: [], total: { total: 2, online: 0, offline: 0, external: 0, no_status: 2 },
      checking: { deviceIds: new Set() },
    })
    const attention = html.slice(html.indexOf('Needs attention'))
    assert.doesNotMatch(attention, /Standalone audio|Location audio/)
    assert.match(attention, /All checked devices are online/)
    assert.match(html, /Audio rack|Stage box/)
  }
})

test('undefined IP addresses are not offered as check targets', async () => {
  const { isCheckable } = await server.ssrLoadModule('/src/format.js')
  for (const ip of ['', ' ', null, undefined, '0.0.0.0', ' 0.0.0.0 ']) {
    assert.equal(isCheckable({ ip, status: 'unknown' }), false)
  }
  assert.equal(isCheckable({ ip: '10.1.1.1', status: 'unknown' }), true)
  assert.equal(isCheckable({ ip: 'router.example', status: 'offline' }), true)
  assert.equal(isCheckable({ ip: '192.0.2.1', status: 'external' }), false)
})

const iconButton = (html, label) => {
  const button = html.match(new RegExp(`<button[^>]*aria-label="${label}"[^>]*>.*?</button>`))?.[0]
  assert.ok(button, `Missing button: ${label}`)
  assert.match(button, /class="button [^"]*icon-only/)
  assert.match(button, /<svg[^>]*aria-hidden="true"/)
  assert.equal(button.replace(/<[^>]*>/g, ''), '')
  return button
}

test('dashboard actions are icon-only with accessible labels and check states', () => {
  const props = {
    admin: true, user: 'viewer', state: { devices: [location], sites: [], config: {} }, siteSummaries: [],
    total: { total: 1, online: 1, offline: 0, external: 0, no_status: 0 }, checking: { siteIds: new Set(), deviceIds: new Set() },
  }
  const html = render(Dashboard, props)
  assert.doesNotMatch(iconButton(html, 'Check all locations'), /disabled/)
  assert.match(iconButton(html, 'Add Location'), /M12 5v14M5 12h14/)
  assert.match(iconButton(html, 'Add Dante device'), /M12 5v14M5 12h14/)
  assert.match(iconButton(render(Dashboard, { ...props, cooldown: 5 }), 'Check again in 5s'), /disabled/)
  assert.match(iconButton(render(Dashboard, { ...props, checkingAll: true, busy: true }), 'Checking…'), /disabled/)
  assert.match(iconButton(render(Dashboard, { ...props, state: { ...props.state, devices: [standalone] } }), 'Check all locations'), /disabled/)
  const signedInReadOnly = render(Dashboard, { ...props, admin: false })
  assert.doesNotMatch(signedInReadOnly, /aria-label="Add Location"/)
  assert.match(signedInReadOnly, /aria-label="Check all locations"/)
  const signedOut = render(Dashboard, { ...props, user: null })
  assert.doesNotMatch(signedOut, /aria-label="Check all locations"|class="summary-check"/)
})

test('PC actions are icon-only and preserve disabled states and admin visibility', () => {
  const pc = { id: 1, name: 'Workstation', type: 'Desktop', ip: '10.0.0.1', status: 'online', checked: '' }
  const props = { admin: true, user: 'viewer', state: { config: { maintenance_days: 30 }, pcs: [pc], aliases: { pcs: {} } }, checking: { deviceIds: new Set() } }
  const html = render(Maintenance, props)
  assert.doesNotMatch(iconButton(html, 'Check PCs'), /disabled/)
  assert.match(iconButton(html, 'Add PC'), /M12 5v14M5 12h14/)
  assert.match(iconButton(render(Maintenance, { ...props, cooldown: 8 }), 'Check again in 8s'), /disabled/)
  assert.match(iconButton(render(Maintenance, { ...props, busy: true, checking: { deviceIds: new Set([1]) } }), 'Checking…'), /disabled/)
  const empty = render(Maintenance, { ...props, state: { ...props.state, pcs: [] } })
  assert.match(iconButton(empty, 'Check PCs'), /disabled/)
  assert.match(iconButton(empty, 'Check PCs'), /title="No PCs with an IP address to check\."/)
  const signedInReadOnly = render(Maintenance, { ...props, admin: false })
  assert.doesNotMatch(signedInReadOnly, /aria-label="Add PC"/)
  assert.match(signedInReadOnly, /aria-label="Check PCs"/)
  assert.doesNotMatch(render(Maintenance, { ...props, user: null }), /aria-label="Check PCs"/)
})

test('PC import/export lives in Settings, not on the PC Maintenance page', () => {
  const state = {
    auth: { user: 'admin', role: 'admin' },
    config: { max_import_bytes: 1048576 },
    aliases: { pcs: {} },
  }
  const settingsHtml = render(Settings, {
    state, section: 'pc-import-export', go() {}, onImport() {}, team: 'us',
  })
  assert.match(settingsHtml, /Import PCs/)
  assert.match(settingsHtml, /All PCs \(CSV\)/)

  const pc = { id: 1, name: 'Workstation', type: 'Desktop', ip: '10.0.0.1', status: 'online', checked: '' }
  const pcPageHtml = render(Maintenance, {
    admin: true, user: 'admin', team: 'us',
    state: { ...state, config: { ...state.config, maintenance_days: 30 }, pcs: [pc] },
    checking: { deviceIds: new Set() }, onCheckPcs() {}, onAdd() {}, onEdit() {}, onDelete() {}, onLogin() {},
  })
  assert.doesNotMatch(pcPageHtml, /Import &amp; Export|Import PCs|All PCs \(CSV\)/)
})

test('Backup and Firmware settings do not show settings Reset or Save controls', () => {
  const state = {
    auth: { user: 'admin', role: 'admin' },
    config: { data_file: 'data.json', max_import_bytes: 1048576 },
    aliases: { firmware: {} },
    firmware: [],
    devices: [],
  }
  for (const section of ['backup', 'firmware']) {
    const html = render(Settings, {
      state, section, go() {}, onSave() {}, onAdd() {}, onEdit() {}, onDelete() {}, onImport() {},
    })
    assert.doesNotMatch(html, />Reset<\/button>|>Save settings<\/button>/)
  }
})

test('traffic monitoring is in its own submenu and shown only to admins', () => {
  const settings = {
    app_title: 'Status', app_subtitle: '', timezone: 'UTC', teams: [{ key: 'us', name: 'United States', timezone: 'UTC' }],
    header_devices: [], online_values: [], corporate_networks: [], external_networks: [],
    maintenance_interval_days: 90, firmware_mode: 'minimum', check_schedule: [], check_window_minutes: 59,
    manual_check_cooldown_seconds: 60, ping: { method: 'auto', timeout_seconds: 2, count: 1, parallel: 1, tcp_ports: [80] },
    rate_limits: { api: [0, 0], write: [0, 0], ping: [0, 0], login: [0, 0] },
    max_import_mb: 5, max_photo_mb: 5, ping_api: true, email: { times: [] },
  }
  const renderSettingsForRole = (role) => render(Settings, {
    state: { auth: { user: role, role }, settings, email: {}, users: [], config: {}, aliases: { firmware: {} }, firmware: [], devices: [] },
    section: 'traffic', go() {}, onSave() {}, onAdd() {}, onEdit() {}, onDelete() {}, onImport() {},
  })
  assert.match(renderSettingsForRole('admin'), /Traffic/)
  assert.match(renderSettingsForRole('admin'), /Loading traffic usage/)
  assert.doesNotMatch(renderSettingsForRole('lead'), /Traffic/)
})

test('general and country time zones use selectable option lists', async () => {
  const { TimeZoneSelect } = await server.ssrLoadModule('/src/components/Settings.jsx')
  const general = render(TimeZoneSelect, { value: 'UTC', onChange() {} })
  assert.match(general, /<select required="">/)
  assert.match(general, /<option value="UTC" selected="">UTC<\/option>/)
  assert.match(general, /<option value="America\/New_York">America\/New_York<\/option>/)

  const country = render(TimeZoneSelect, { value: '', allowGeneral: true, onChange() {}, 'aria-label': 'Time zone' })
  assert.match(country, /<select aria-label="Time zone">/)
  assert.match(country, /<option value="" selected="">Use general time zone<\/option>/)
  assert.match(country, /<option value="Europe\/Berlin">Europe\/Berlin<\/option>/)
})

test('discovery settings support current-boot service journals and preserve existing file sources', () => {
  const settings = {
    app_title: 'Status', app_subtitle: '', timezone: 'UTC', teams: [{ key: 'us', name: 'United States' }],
    online_values: ['online'], corporate_networks: [], external_networks: [], check_schedule: ['12:00'],
    ping: { tcp_ports: [80] }, email: { times: [] },
    rate_limits: { api: [0, 0], write: [0, 0], ping: [0, 0], login: [10, 60] },
  }
  const server = { name: 'Discovery', ip: '192.0.2.1', log_enabled: true, ssh_user: 'discovery', ssh_auth: 'key', ssh_key: 'discovery_key' }
  const renderDiscovery = (device) => render(Settings, {
    state: { auth: { user: 'admin', role: 'admin' }, settings: { ...settings, header_devices: [device] } },
    section: 'header',
  })
  const journal = renderDiscovery(server)
  assert.match(journal, /<option value="journal" selected="">Systemd service journal<\/option>/)
  assert.match(journal, /value="ndi-discovery\.service"/)
  assert.match(journal, /Current boot, latest 200 messages/)
  assert.doesNotMatch(journal, /placeholder="\/var\/log\/discovery.log"/)
  const file = renderDiscovery({ ...server, log_path: '/var/log/existing.log' })
  assert.match(file, /<option value="file" selected="">Log file<\/option>/)
  assert.match(file, /value="\/var\/log\/existing.log"/)
  assert.doesNotMatch(file, /placeholder="ndi-discovery.service"/)
  const custom = renderDiscovery({ ...server, log_source: 'journal', log_service: 'custom.service', log_path: '/var/log/old.log' })
  assert.match(custom, /value="custom.service"/)
  assert.doesNotMatch(custom, /value="\/var\/log\/old.log"/)
  applyLanguageChoice('de')
  try {
    assert.match(renderDiscovery(server), /Systemd-Dienstjournal/)
    assert.match(renderDiscovery(server), /Leserechte/)
  } finally {
    applyLanguageChoice('en')
  }
})

test('dedicated manager only offers permitted standalone edit/delete paths', () => {
  const html = render(DanteManager, { devices: [standalone, location], admin: true })
  assert.match(html, /Standalone audio/)
  assert.doesNotMatch(html, /Location audio/)
  assert.match(html, />Edit<\/button>/)
  assert.match(html, />Delete<\/button>/)
  assert.match(html, /\*{7}/)
  assert.match(html, /class="button primary with-icon"[^>]*><svg[^>]*>.*?M12 5v14M5 12h14.*?<\/svg> Add Dante device<\/button>/)
  const readOnly = render(DanteManager, { devices: [standalone, location], admin: false })
  assert.doesNotMatch(readOnly, />Edit<\/button>|>Delete<\/button>|Add Dante device/)
})

test('standalone add form works with no locations and defaults to selected country', () => {
  const html = render(RecordDialog, {
    editing: { kind: 'dante', record: null, defaults: { team: 'de' } }, sites: [],
    teams: [{ key: 'us', name: 'United States' }, { key: 'de', name: 'Germany' }],
  })
  assert.match(html, /Add Dante device/)
  assert.doesNotMatch(html, /name="site_id"|name="type"/)
  assert.match(html, /name="name"/)
  assert.match(html, /name="ip"/)
  assert.match(html, /<option value="de" selected=""/)
  assert.match(html, /independently of location network ranges/)
  assert.match(html, /type="submit"/)
})
