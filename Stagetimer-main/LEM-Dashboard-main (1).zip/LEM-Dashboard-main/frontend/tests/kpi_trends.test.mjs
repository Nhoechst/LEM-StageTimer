import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { after, test } from 'node:test'
import React from 'react'
import { renderToStaticMarkup } from 'react-dom/server'
import { createServer } from 'vite'

globalThis.document = { documentElement: { lang: 'en' } }
const server = await createServer({ root: new URL('../', import.meta.url).pathname, server: { middlewareMode: true } })
after(() => server.close())
const { default: Kpi, Trend } = await server.ssrLoadModule('/src/components/Kpi.jsx')
const { default: SitePage } = await server.ssrLoadModule('/src/components/SitePage.jsx')
const { applyLanguageChoice } = await server.ssrLoadModule('/src/i18n.js')
applyLanguageChoice('en')

const props = {
  icon: 'ethernet', tone: 'green', value: 1, label: 'Online',
  trendMetric: 'online_devices', trendLabel: 'Recorded online devices',
}
const points = [0, 1, null, 2].map((value, index) => ({
  day: 1792022400 + index * 86400,
  online_devices: value,
  online_pct: value === null ? null : value * 50,
  avg_latency_ms: value,
  success_pct: value === null ? null : value * 50,
}))
const render = (component, values) => renderToStaticMarkup(React.createElement(component, values))
test('dashboard network lists show locations for external devices and notes for Dante', async () => {
  const { default: Dashboard } = await server.ssrLoadModule('/src/components/Dashboard.jsx')
  const devices = [
    { id: 1, site_id: 1, site: 'Site A', name: 'Long external device name', ip: '*******', type: 'Switch', notes: 'Long notes', status: 'external' },
    { id: 2, site_id: 2, site: 'Site B', name: 'Long Dante endpoint name', ip: '2001:db8::1', type: 'Dante', model: 'Audio interface', notes: 'Audio rack <B>', status: 'online', dante: true },
  ]
  const html = render(Dashboard, {
    user: 'viewer',
    state: { devices, config: {} }, siteSummaries: [],
    total: { total: 2, online: 1, offline: 0, external: 1, no_status: 0 },
    checking: { deviceIds: new Set() },
  })
  assert.equal((html.match(/class="network-device-list"/g) ?? []).length, 2)
  assert.equal((html.match(/<th scope="col">Title<\/th><th scope="col">Location<\/th><th scope="col">IP address<\/th>/g) ?? []).length, 1)
  assert.match(html, /<th scope="col">Title<\/th><th scope="col">Notes<\/th><th scope="col">IP address<\/th>/)
  assert.equal((html.match(/class="device-title-chip network-location"/g) ?? []).length, 1)
  assert.match(html, />Site A<\/button>/)
  assert.match(html, /<td>Audio rack &lt;B&gt;<\/td>/)
  assert.match(html, /<span class="device-title-chip">Long external device name<\/span>/)
  assert.match(html, /<span class="device-title-chip">Long Dante endpoint name<\/span>/)
  assert.doesNotMatch(html, /title="Edit device"/)
  assert.doesNotMatch(html, /Long notes|Audio interface|equipment-dante-logo|external-meta|external-dot/)
  assert.match(html, /<h2 class="panel-title" aria-label="Dante Network"><img class="dante-logo" src="logos\/Dante_logo\.svg" alt="DANTE"\/><\/h2>/)
  assert.equal((html.match(/class="dante-logo"/g) ?? []).length, 1)
  assert.match(html, /<span class="mono">\*{7}<\/span>/)
  const empty = render(Dashboard, {
    user: 'viewer',
    state: { devices: [], config: {} }, siteSummaries: [],
    total: { total: 0, online: 0, offline: 0, external: 0, no_status: 0 },
    checking: { deviceIds: new Set() },
  })
  assert.match(empty, /Type contains “Dante”/)
  assert.match(empty, /regardless of IP address/)
})
test('device titles use chips while preserving photos and telemetry actions', async () => {
  const { DeviceName } = await server.ssrLoadModule('/src/components/Photo.jsx')
  const device = { name: 'Studio <encoder>' }
  const plain = render(DeviceName, { device })
  assert.equal(plain, '<span class="device-title-chip">Studio &lt;encoder&gt;</span>')
  const photo = render(DeviceName, { device: { ...device, photo: 'encoder.jpg' } })
  assert.match(photo, /class="photo-target"/)
  assert.match(photo, /class="device-title-chip"/)
  assert.match(photo, /class="photo-icon"/)
  assert.doesNotMatch(plain, /<button/)
  const child = React.createElement('button', { type: 'button' }, 'Telemetry')
  assert.equal(render(DeviceName, { device, children: child }), '<button type="button">Telemetry</button>')
  const popup = readFileSync(new URL('../src/components/DeviceTelemetryPopup.jsx', import.meta.url), 'utf8')
  assert.match(popup, /className="device-title-chip" popoverTarget=\{id\} aria-haspopup="dialog"/)
  const list = readFileSync(new URL('../src/components/NetworkDeviceList.jsx', import.meta.url), 'utf8')
  assert.doesNotMatch(list, /onEdit|Edit device/)
  assert.match(list, /go\(`location\/\$\{device.site_id\}`\)/)
})
test('title and model chips preserve word widths during table sizing', () => {
  const css = readFileSync(new URL('../src/styles/extras.css', import.meta.url), 'utf8')
  for (const selector of ['device-title-chip', 'text-chip']) {
    const rule = css.match(new RegExp(`^\\.${selector} \\{([^}]+)\\}`, 'm'))?.[1]
    assert.ok(rule, `Missing ${selector} style`)
    assert.match(rule, /overflow-wrap:\s*break-word/)
    assert.match(rule, /white-space:\s*normal/)
    assert.match(rule, /max-width:\s*100%/)
  }
})
test('location device table provides translated labels and a scoped responsive layout', () => {
  const source = readFileSync(new URL('../src/components/SitePage.jsx', import.meta.url), 'utf8')
  const css = readFileSync(new URL('../src/styles/extras.css', import.meta.url), 'utf8')
  assert.match(source, /data-label=\{t\(label\)\}/)
  const labels = [...source.matchAll(/<DeviceCell label="([^"]+)"/g)].map((match) => match[1])
  assert.deepEqual(labels, ['Status', 'Title', 'IP address', 'Type', 'Model', 'Current firmware', 'Latency', 'Last checked', 'Last online', 'Actions'])
  assert.match(source, /className="inventory-table location-device-table" role="table"/)
  assert.match(css, /\.inventory-table \{ min-width: 0; table-layout: fixed; \}/)
  assert.match(css, /@media \(max-width: 1100px\) \{/)
  assert.match(css, /\.inventory-table td \{ display: grid;/)
  assert.match(css, /\.inventory-table td::before \{ content: attr\(data-label\);/)
  assert.doesNotMatch(css, /\.inventory-table thead[^{}]*\{[^}]*display: none/)
  const summary = { site: { id: 1, name: 'Lab' }, counts: { total: 0, online: 0, offline: 0, external: 0, no_status: 0 } }
  const values = { summary, state: { devices: [] }, checking: { siteIds: new Set(), deviceIds: new Set() } }
  assert.match(render(SitePage, values), /class="inventory-table location-device-table" role="table" aria-label="IP Addresses"/)
  applyLanguageChoice('de')
  try {
    assert.match(render(SitePage, values), /aria-label="IP-Adressen"/)
  } finally {
    applyLanguageChoice('en')
  }
})
test('inventory lists use the full page width and keep location actions on one line', () => {
  const css = readFileSync(new URL('../src/styles/extras.css', import.meta.url), 'utf8')
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8')
  assert.match(app, /route\.page === 'site' \|\| route\.page === 'maintenance' \? ' inventory-shell'/)
  assert.match(css, /body \.shell\.inventory-shell \{ max-width: none; \}/)
  assert.match(css, /\.location-device-table td\.actions \.device-cell-value \{ flex-wrap: nowrap; \}/)
  assert.match(css, /\.inventory-table td\.actions \{[^}]*grid-template-columns: minmax\(0, 1fr\)/)
})
test('sub-navigation is outside the route-dependent width container', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8')
  const css = readFileSync(new URL('../src/styles/extras.css', import.meta.url), 'utf8')
  const navigation = app.slice(app.indexOf('<div className="shell navigation-shell">'), app.indexOf('<div className={`shell${'))
  assert.match(navigation, /<nav className="pill-tabs"/)
  assert.match(navigation, /PAGES\.map/)
  assert.doesNotMatch(navigation, /inventory-shell/)
  assert.match(css, /\.navigation-shell \{ padding-bottom: 0; \}/)
  assert.match(css, /html \{ scrollbar-gutter: stable; \}/)
})
test('PC maintenance labels every detail and retains permissions and maintenance actions', async () => {
  const { default: Maintenance } = await server.ssrLoadModule('/src/components/Maintenance.jsx')
  const pc = { id: 1, name: 'Workstation', type: 'Desktop', ip: '192.0.2.1', status: 'online', checked: '', comments: 'Keep all comments', os: 'Windows 11', location: 'Studio', checked_by: 'Technician' }
  const props = { state: { config: { maintenance_days: 30 }, pcs: [pc] }, checking: { deviceIds: new Set() } }
  const html = render(Maintenance, { ...props, admin: true, user: 'admin' })
  assert.match(html, /class="inventory-table pc-maintenance-table" role="table"/)
  const labels = [...html.matchAll(/data-label="([^"]+)"/g)].map(match => match[1])
  assert.deepEqual(labels, ['PC name', 'Type', 'IP address', 'Online', 'Operating system', 'Location', 'Last checked', 'Checked by', 'Comments', 'Status', 'Actions'])
  assert.match(html, /Keep all comments/)
  assert.match(html, /Complete check/)
  assert.match(html, /class="pc-edit-actions"/)
  assert.match(html, /aria-label="Edit: Workstation"/)
  assert.match(html, /aria-label="Delete: Workstation"/)
  const publicHtml = render(Maintenance, props)
  assert.match(publicHtml, /Log in to complete check/)
  assert.doesNotMatch(publicHtml, /pc-edit-actions|aria-label="Edit:|aria-label="Delete:/)
  applyLanguageChoice('de')
  try {
    assert.match(render(Maintenance, props), /data-label="Betriebssystem"/)
  } finally {
    applyLanguageChoice('en')
  }
})
test('IP chips retain device destinations and protect masked addresses', async () => {
  const { default: IpAddress } = await server.ssrLoadModule('/src/components/IpAddress.jsx')
  const html = render(IpAddress, { device: { ip: '192.0.2.1' }, className: 'mono muted' })
  assert.match(html, /class="ip-chip mono muted"/)
  assert.match(html, /href="http:\/\/192\.0\.2\.1"/)
  assert.match(html, /target="_blank" rel="noopener noreferrer"/)
  assert.match(html, /title="Open device interface"/)
  assert.match(html, /aria-label="192\.0\.2\.1: Open device interface \(opens in a new tab\)"/)
  assert.match(html, /<svg[^>]*aria-hidden="true"/)
  assert.match(render(IpAddress, { device: { ip: '2001:db8::1' } }), /href="http:\/\/\[2001:db8::1\]"/)
  assert.match(render(IpAddress, { device: { ip: '[2001:db8::1]' } }), /href="http:\/\/\[2001:db8::1\]"/)
  assert.match(render(IpAddress, { device: { ip: '192.0.2.1', web_url: 'https://device.example:8443/admin' } }), /href="https:\/\/device\.example:8443\/admin"/)
  assert.match(render(IpAddress, { device: { ip: '192.0.2.1', web_url: 'javascript:alert(1)' } }), /href="http:\/\/192\.0\.2\.1"/)
  const masked = render(IpAddress, { device: { ip: '*******', web_url: 'https://private.example' } })
  assert.equal(masked, '<span class="mono">*******</span>')
  assert.equal(render(IpAddress, { device: { ip: '0.0.0.0', web_url: 'http://0.0.0.0' } }), '<span class="mono">0.0.0.0</span>')
  for (const ip of ['', undefined, null, '   ']) {
    assert.equal(render(IpAddress, { device: { ip } }), '—')
  }
  applyLanguageChoice('de')
  try {
    assert.match(render(IpAddress, { device: { ip: '192.0.2.1' } }), /title="Geräteoberfläche öffnen"/)
  } finally {
    applyLanguageChoice('en')
  }
})
test('non-compliant firmware badges expose latest firmware on hover and to screen readers', async () => {
  const { FirmwareBadge } = await server.ssrLoadModule('/src/components/ui.jsx')
  const values = { compliance: 'non_compliant', firmware: '5.1.19', latestFirmware: ' 5.2.0 ' }
  const html = render(FirmwareBadge, values)
  assert.match(html, /title="Latest firmware: 5\.2\.0"/)
  assert.match(html, /aria-label="5\.1\.19: Non-compliant · Latest firmware: 5\.2\.0"/)
  assert.match(html, />5\.1\.19<\/span>$/)
  for (const latestFirmware of [undefined, null, '', '   ']) {
    assert.match(render(FirmwareBadge, { ...values, latestFirmware }), /title="Non-compliant"/)
  }
  for (const compliance of ['compliant', 'unknown']) {
    assert.doesNotMatch(render(FirmwareBadge, { ...values, compliance }), /Latest firmware/)
  }
  assert.doesNotMatch(render(FirmwareBadge, { ...values, latestFirmware: '"><script>alert(1)</script>' }), /<script>/i)
  applyLanguageChoice('de')
  try {
    assert.match(render(FirmwareBadge, values), /title="Neueste Firmware: 5\.2\.0"/)
    assert.match(render(FirmwareBadge, values), /Neueste Firmware: 5\.2\.0/)
  } finally {
    applyLanguageChoice('en')
  }
  for (const file of ['SitePage', 'Dashboard', 'Firmware']) {
    const source = readFileSync(new URL(`../src/components/${file}.jsx`, import.meta.url), 'utf8')
    assert.match(source, /latestFirmware=\{d\.required_firmware\}/)
  }
})
test('firmware badges show the version with compliance color and accessible status', async () => {
  const { FirmwareBadge } = await server.ssrLoadModule('/src/components/ui.jsx')
  for (const [compliance, color, label] of [
    ['compliant', 'checked', 'Compliant'],
    ['non_compliant', 'status-1', 'Non-compliant'],
    ['unknown', 'status-3', 'No latest info'],
  ]) {
    const html = render(FirmwareBadge, { compliance, firmware: '5.1.19' })
    assert.match(html, new RegExp(`class="badge mono ${color}"`))
    assert.ok(html.includes(`title="${label}"`))
    assert.ok(html.includes(`aria-label="5.1.19: ${label}"`))
    assert.match(html, />5\.1\.19<\/span>$/)
  }
  for (const firmware of [undefined, null, '', '   ']) {
    assert.match(render(FirmwareBadge, { compliance: 'unknown', firmware }), />—<\/span>$/)
  }
  assert.match(render(FirmwareBadge, { firmware: '1.0', compliance: 'unexpected' }), /badge mono status-3/)
  assert.doesNotMatch(render(FirmwareBadge, { firmware: '<script>alert(1)</script>' }), /<script>/i)
})
test('firmware exemptions are labeled, escaped, and editable only by managers', async () => {
  const { FirmwareBadge } = await server.ssrLoadModule('/src/components/ui.jsx')
  const { FirmwareManagement } = await server.ssrLoadModule('/src/components/Firmware.jsx')
  const model = 'Audio <interface>'
  const state = { devices: [{ model }], firmware: [], config: { firmware_exemptions: [model] }, aliases: { firmware: {} } }
  const manager = render(FirmwareManagement, { state, admin: true })
  assert.match(manager, /Firmware exemptions/)
  assert.match(manager, /Add exemption/)
  assert.match(manager, /aria-label="Remove exemption: Audio &lt;interface&gt;"/)
  assert.match(manager, /even without firmware information/)
  assert.doesNotMatch(manager, /<interface>/)
  const viewer = render(FirmwareManagement, { state, admin: false })
  assert.match(viewer, /Audio &lt;interface&gt;/)
  assert.doesNotMatch(viewer, /Add exemption|Remove exemption|<form/)
  const badge = render(FirmwareBadge, { compliance: 'compliant', firmware: '', exempt: true })
  assert.match(badge, /badge mono checked/)
  assert.match(badge, /title="Exempt" aria-label="—: Exempt"/)
  assert.match(badge, /— · Exempt/)
  applyLanguageChoice('de')
  try {
    assert.match(render(FirmwareManagement, { state, admin: true }), /Firmware-Ausnahmen/)
    assert.match(render(FirmwareBadge, { compliance: 'compliant', exempt: true }), /Ausgenommen/)
  } finally {
    applyLanguageChoice('en')
  }
})
const renderTrend = (trend = points) => render(Trend, {
  points: trend, metric: props.trendMetric, label: props.trendLabel,
})

test('graphs expose a label, preserve zero values and break paths at missing days', () => {
  const html = renderTrend()
  assert.match(html, /role="img" aria-label="Recorded online devices"/)
  assert.match(html, /d="M4,52 L81\.33333333333333,30 M236,8 "/)
  assert.equal((html.match(/<circle /g) || []).length, 3)
  assert.doesNotMatch(html, /NaN|Infinity/)
})

test('empty history is not fabricated and single points remain visible', () => {
  for (const trend of [[], [{ day: 1, online_devices: null }]]) {
    const html = renderTrend(trend)
    assert.match(html, /No trend data yet/)
    assert.doesNotMatch(html, /class="kpi-trend"/)
  }
  const html = renderTrend([{ day: 1, online_devices: 0 }])
  assert.match(html, /<circle /)
  assert.doesNotMatch(html, /NaN|Infinity/)
})

test('ordinary KPI cards do not gain graphs or empty-state messages', () => {
  const html = render(Kpi, { icon: 'monitor', tone: 'slate', value: 3, label: 'Total Devices' })
  assert.doesNotMatch(html, /kpi-trend|No trend data/)
})

test('KPI popups opt into native light dismissal without changing other dialogs', async () => {
  const { Modal } = await server.ssrLoadModule('/src/components/ui.jsx')
  assert.match(render(Kpi, props), /<dialog[^>]*closedby="any"/)
  assert.match(render(Modal, { open: false, closeOnOutside: true }), /closedby="any"/)
  assert.doesNotMatch(render(Modal, { open: false }), /closedby=/)
})

test('location page exposes four clickable cards without inline graphs or changed values', () => {
  const summary = {
    site: { id: 1, name: 'Lab' },
    counts: { total: 3, online: 1, offline: 2, external: 0, no_status: 0 },
  }
  const state = {
    devices: [],
    telemetry: { 1: { checks: 4, online: 3, avg_latency_ms: 2 } },
    telemetry_trends: { 1: points },
  }
  const html = render(SitePage, { summary, state, checking: { siteIds: new Set(), deviceIds: new Set() }, cooldown: 0 })
  assert.equal((html.match(/aria-haspopup="dialog"/g) || []).length, 4)
  assert.equal((html.match(/<button class="kpi-card kpi-card-clickable"/g) || []).length, 4)
  assert.equal((html.match(/closedby="any"/g) || []).length, 4)
  assert.match(html, /aria-label="View performance graph: % Online"/)
  assert.doesNotMatch(html, /class="kpi-trend"|No trend data yet/)
  assert.match(html, /75\.0%/)
  assert.match(html, /Average ping \(365 days\)/)
  assert.doesNotMatch(html, /aria-label="Edit location"|aria-label="Delete location"/)
  const adminHtml = render(SitePage, { admin: true, summary: { ...summary, counts: { ...summary.counts, total: 0 } }, state: { ...state, config: {}, aliases: { devices: {} } }, checking: { siteIds: new Set(), deviceIds: new Set() }, cooldown: 0 })
  assert.match(adminHtml, /title="Edit location" aria-label="Edit location"[^>]*><svg/)
  assert.match(adminHtml, /title="Delete location" aria-label="Delete location"[^>]*><svg/)
})

test('location online percentages exclude external devices', async () => {
  const { default: Dashboard } = await server.ssrLoadModule('/src/components/Dashboard.jsx')
  const dashboard = render(Dashboard, {
    state: { devices: [], config: {} },
    siteSummaries: [{ site: { id: 1, name: 'Lab' }, counts: { total: 3, online: 1, offline: 1, external: 1, no_status: 0 } }],
    total: { total: 3, online: 1, offline: 1, external: 1, no_status: 0 },
    checking: { siteIds: new Set(), deviceIds: new Set() },
  })
  assert.match(dashboard, /<strong>50\.0%<\/strong><span class="kpi-label">% Online<\/span>/)
  assert.match(dashboard, /<span class="summary-pct">50\.0%/)
  assert.match(dashboard, /<dt>Total<\/dt><dd>3<\/dd>/)

  const sitePage = render(SitePage, {
    summary: { site: { id: 1, name: 'Lab' }, counts: { total: 3, online: 1, offline: 1, external: 1, no_status: 0 } },
    state: { devices: [], telemetry: {}, telemetry_trends: {} },
    checking: { siteIds: new Set(), deviceIds: new Set() },
    cooldown: 0,
  })
  assert.match(sitePage, /<strong>50\.0%<\/strong><span class="kpi-label">% Online<\/span>/)
})

test('location summary cards stay visible but are not navigable when signed out', async () => {
  const { default: SiteCard } = await server.ssrLoadModule('/src/components/SiteCard.jsx')
  const props = {
    site: { id: 1, name: 'Lab' },
    percent: '50.0',
    stats: [['Total', 2]],
    bar: { total: 2, online: 1, offline: 1 },
    onOpen() {},
  }
  const publicCard = render(SiteCard, props)
  assert.match(publicCard, /<h3>Lab<\/h3>/)
  assert.match(publicCard, /<span class="summary-pct">50\.0% <\/span>/)
  assert.doesNotMatch(publicCard, /role="link"|tabindex="0"|View location details|class="summary-card clickable"/)

  const signedInCard = render(SiteCard, { ...props, canOpen: true })
  assert.match(signedInCard, /class="summary-card clickable" role="link" tabindex="0"/)
  assert.match(signedInCard, /View location details/)
})

test('percent online graph uses a fixed percentage scale and formatted values', () => {
  const html = render(Trend, { points, metric: 'online_pct', label: '% Online', maximum: 100, format: (value) => `${value.toFixed(1)}%` })
  assert.match(html, /d="M4,52 L81\.33333333333333,30 M236,8 "/)
  assert.match(html, /100\.0%/)
  assert.equal((html.match(/<circle /g) || []).length, 3)
})

test('trend captions are translated', () => {
  applyLanguageChoice('de')
  try {
    assert.match(renderTrend(), /Tagesverlauf/)
    assert.match(render(Kpi, { ...props, trend: points }), /Leistungsdiagramm anzeigen: Online/)
  } finally {
    applyLanguageChoice('en')
  }
})

test('inventory items use labeled icon actions visible only to managers', async () => {
  const { default: Firmware } = await server.ssrLoadModule('/src/components/Firmware.jsx')
  const { FirmwareManagement } = await server.ssrLoadModule('/src/components/Firmware.jsx')
  const device = { id: 1, site_id: 1, site: 'Lab', name: 'Switch', status: 'online', model: 'Model', compliance: 'non_compliant' }
  const state = {
    devices: [device],
    pcs: [{ id: 2, name: 'Workstation', type: 'Desktop', checked: '', status: 'online' }],
    firmware: [{ id: 3, model: 'Model' }],
    config: { maintenance_days: 90 },
    aliases: { devices: {}, pcs: {}, firmware: {} },
  }
  const siteSource = readFileSync(new URL('../src/components/SitePage.jsx', import.meta.url), 'utf8')
  assert.match(siteSource, /onEdit\('device', d\)}><Icon name="pencil"/)
  assert.match(siteSource, /onDelete\(\{ kind: 'device', id: d.id, name: d.name \}\)}><Icon name="trash"/)
  for (const [component, values, name] of [
    [FirmwareManagement, { state }, 'Model'],
  ]) {
    const html = render(component, { ...values, admin: true })
    for (const action of ['Edit', 'Delete']) {
      assert.match(html, new RegExp(`aria-label="${action}: ${name}"[^>]*><svg`))
    }
    assert.doesNotMatch(render(component, { ...values, admin: false }), /item-action/)
  }
  const compliance = { state, total: { total: 1, fw_compliant: 0, fw_non_compliant: 1 } }
  assert.match(render(Firmware, { ...compliance, admin: true, go() {} }), /aria-label="Edit: Switch"[^>]*><svg/)
  assert.doesNotMatch(render(Firmware, { ...compliance, admin: false, go() {} }), /item-action/)
})

test('icon-only dark/light controls are in desktop and mobile headers, not page navigation', async () => {
  const { default: App } = await server.ssrLoadModule('/src/App.jsx')
  const { defaultTeamForLanguage } = await server.ssrLoadModule('/src/team.js')
  const teams = [{ key: 'us' }, { key: 'de' }]
  assert.equal(defaultTeamForLanguage(teams, 'de'), 'de')
  assert.equal(defaultTeamForLanguage(teams, 'en'), 'us')
  assert.equal(defaultTeamForLanguage([{ key: 'custom' }], 'de'), 'custom')
  globalThis.window = { location: { hash: '#dashboard' }, matchMedia: () => ({ matches: false }) }
  try {
    for (const dark of [false, true]) {
      document.body = { classList: { contains: () => dark } }
      const html = render(App, {})
      const nav = html.match(/<nav\b[^>]*>[\s\S]*?<\/nav>/)?.[0]
      assert.equal(nav, undefined)
      assert.doesNotMatch(html, />Device Status<\/button>|>PC Maintenance<\/button>|>Firmware Compliance<\/button>/)
      const header = html.match(/<header\b[^>]*>[\s\S]*?<\/header>/)?.[0]
      const buttons = header.match(/<button[^>]*class="theme-btn"[^>]*>[\s\S]*?<\/button>/g)
      assert.equal(buttons.length, 2)
      for (const button of buttons) {
        assert.match(button, new RegExp(`aria-label="Switch to ${dark ? 'light' : 'dark'} mode"`))
        assert.match(button, /<svg/)
        assert.doesNotMatch(button, /<span>/)
      }
    }
  } finally {
    delete globalThis.window
    delete document.body
  }
})

test('account controls show Login signed out and a username disclosure signed in', async () => {
  const { AccountMenu } = await server.ssrLoadModule('/src/components/Auth.jsx')
  const guest = render(AccountMenu, { user: null })
  assert.match(guest, /<span>Log in<\/span>/)
  assert.doesNotMatch(guest, /<details|Log out|Settings/)
  const signedIn = render(AccountMenu, { user: 'Operator' })
  assert.match(signedIn, /<div class="account-menu"><button type="button"/)
  assert.match(signedIn, /aria-expanded="false" aria-controls="([^"]+)"/)
  assert.match(signedIn, /class="account-dropdown" hidden=""/)
  const controlledId = signedIn.match(/aria-controls="([^"]+)"/)[1]
  assert.ok(signedIn.includes(`id="${controlledId}" class="account-dropdown"`))
  assert.match(signedIn, /<span>Operator<\/span>/)
  assert.match(signedIn, /Settings/)
  assert.match(signedIn, /Log out/)
  assert.doesNotMatch(signedIn, /<details|<summary/)
  const css = readFileSync(new URL('../src/styles/extras.css', import.meta.url), 'utf8')
  assert.match(css, /\.account-dropdown\[hidden\]\s*\{\s*display:\s*none;\s*\}/)
})

test('account menu survives touch blur but closes when keyboard focus leaves', async () => {
  const { closeAccountOnBlur } = await server.ssrLoadModule('/src/accountMenu.js')
  const settings = {}
  const logout = {}
  const outside = {}
  let open = true
  const currentTarget = {
    contains: (target) => target === settings || target === logout,
  }
  const close = () => { open = false }
  for (const relatedTarget of [null, settings, logout]) {
    closeAccountOnBlur({ currentTarget, relatedTarget }, close)
    assert.equal(open, true, 'Tapping an action must not hide it before the click is dispatched')
  }
  closeAccountOnBlur({ currentTarget, relatedTarget: outside }, close)
  assert.equal(open, false, 'Tabbing outside must still dismiss the menu')
})

test('equipment types show only NDI and Dante markers and preserve other types', async () => {
  const { default: EquipmentType } = await server.ssrLoadModule('/src/components/EquipmentType.jsx')
  for (const type of ['NDI', 'ndi decoder', 'NDI-HX encoder', 'NDI|HX']) {
    const html = render(EquipmentType, { type })
    assert.match(html, /equipment-ndi-badge/)
    assert.equal(html, '<span class="equipment-type"><span class="equipment-ndi-badge">NDI</span></span>')
    assert.doesNotMatch(html, /equipment-dante-logo/)
  }
  const dante = render(EquipmentType, { type: 'dAnTe endpoint' })
  assert.match(dante, /equipment-dante-logo/)
  assert.match(dante, /src="logos\/Dante_logo.svg"/)
  assert.match(dante, /alt="DANTE"/)
  assert.doesNotMatch(dante, /dAnTe endpoint/)
  const both = render(EquipmentType, { type: 'NDI / Dante bridge' })
  assert.match(both, /equipment-ndi-badge/)
  assert.match(both, /equipment-dante-logo/)
  assert.doesNotMatch(both, /NDI \/ Dante bridge/)
  for (const type of ['Switch', 'Candidate', 'Dantes']) {
    assert.equal(render(EquipmentType, { type }), `<span class="text-chip">${type}</span>`)
  }
  for (const type of ['', '   ', undefined, null]) {
    assert.equal(render(EquipmentType, { type }), '')
  }
  assert.doesNotMatch(dante, /text-chip/)
  assert.doesNotMatch(both, /text-chip/)
  assert.doesNotMatch(render(EquipmentType, { type: 'NDI <script>alert(1)</script>' }), /<script>/i)
})

test('text type and model chips preserve text without becoming interactive', async () => {
  const { default: TextChip } = await server.ssrLoadModule('/src/components/TextChip.jsx')
  assert.equal(render(TextChip, { value: 'Studio Encoder 4K' }), '<span class="text-chip">Studio Encoder 4K</span>')
  assert.equal(render(TextChip, { value: '<script>model</script>' }), '<span class="text-chip">&lt;script&gt;model&lt;/script&gt;</span>')
  for (const value of ['', '   ', undefined, null]) {
    assert.equal(render(TextChip, { value }), '')
  }
  for (const file of ['SitePage', 'Firmware']) {
    const source = readFileSync(new URL(`../src/components/${file}.jsx`, import.meta.url), 'utf8')
    assert.match(source, /<TextChip value=\{d\.model\}/)
  }
})
