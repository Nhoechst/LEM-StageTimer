// English / German UI text. Texts are written in English in the components and
// looked up here; missing German entries fall back to English.
import { DE } from './i18n.de.js'

export const LANGUAGES = { en: 'English', de: 'Deutsch' }
const STORAGE_KEY = 'lang'

/** Language of the browser/PC: German if German comes first, otherwise English. */
export function detectLanguage() {
  const list = navigator.languages?.length ? navigator.languages : [navigator.language || 'en']
  for (const l of list) {
    const code = String(l).slice(0, 2).toLowerCase()
    if (code in LANGUAGES) return code
  }
  return 'en'
}

/** 'auto' (follow the browser) or a fixed language chosen at the bottom of the page. */
export function storedChoice() {
  try {
    const v = localStorage.getItem(STORAGE_KEY)
    return v in LANGUAGES ? v : 'auto'
  } catch {
    return 'auto'
  }
}

let current = 'en'

export function applyLanguageChoice(choice) {
  try {
    if (choice in LANGUAGES) localStorage.setItem(STORAGE_KEY, choice)
    else localStorage.removeItem(STORAGE_KEY)
  } catch {
    // private mode etc.: the choice just isn't remembered
  }
  current = choice in LANGUAGES ? choice : detectLanguage()
  document.documentElement.lang = current
  return current
}

current = storedChoice() in LANGUAGES ? storedChoice() : detectLanguage()
document.documentElement.lang = current

export const getLang = () => current
export const locale = () => (current === 'de' ? 'de-DE' : 'en-US')

/** Translate; {name} placeholders are replaced from vars. */
export function t(text, vars) {
  let out = current === 'de' ? (DE[text] ?? text) : text
  if (vars) out = out.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String(vars[k]) : m))
  return out
}

/** Team name in the current language (names in the config are English). */
export const teamName = (team) => t(team.name)
