// Small client for api.php (PHP-FPM backend). Keeps the session CSRF token.
import { getLang, t } from './i18n.js'

let csrf = ''

export class ApiError extends Error {
  constructor(message, details = [], status = 0, retryAfter = 0) {
    super(message)
    this.details = details
    this.status = status
    this.retryAfter = retryAfter
  }
}

async function parse(response) {
  let body = null
  try {
    body = await response.json()
  } catch {
    if (response.status === 413) throw new ApiError(t('The file is too large for the web server.'))
    if (response.status === 429) {
      const retryAfter = Number(response.headers.get('Retry-After') || 0)
      throw new ApiError(t('Too many requests. Try again in {n} seconds.', { n: retryAfter || '…' }), [], 429, retryAfter)
    }
    throw new ApiError(t('The server returned an error (HTTP {status}).', { status: response.status }), [], response.status)
  }
  if (!response.ok || !body.ok) {
    const retryAfter = Number(body.retry_after || response.headers.get('Retry-After') || 0)
    throw new ApiError(body.error || `HTTP ${response.status}`, body.details || [], response.status, retryAfter)
  }
  if (body.state) csrf = body.state.csrf
  return body
}

export async function loadState() {
  const response = await fetch('api.php?action=state', {
    credentials: 'same-origin',
    headers: { Accept: 'application/json', 'X-Lang': getLang() },
  })
  return (await parse(response)).state
}

/**
 * POST an action. body is a plain object (sent as JSON) or FormData (file upload).
 * Returns {message, details, state}.
 */
export async function post(action, body = {}, retry = true) {
  const isForm = body instanceof FormData
  const response = await fetch(`api.php?action=${encodeURIComponent(action)}`, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      Accept: 'application/json',
      'X-Lang': getLang(),
      'X-CSRF-Token': csrf,
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
    },
    body: isForm ? body : JSON.stringify(body),
  })
  if (response.status === 403 && retry) {
    // Session expired (e.g. PHP restarted): get a fresh token and try once more.
    await loadState()
    return post(action, body, false)
  }
  return parse(response)
}

export const exportUrl = (type, siteId) =>
  `api.php?action=export&type=${encodeURIComponent(type)}${siteId ? `&site_id=${encodeURIComponent(siteId)}` : ''}`

/** Status of the devices shown in the top bar (pinged by the server at most once a minute). */
export async function loadHeader() {
  const response = await fetch('api.php?action=header_status', {
    credentials: 'same-origin',
    headers: { Accept: 'application/json', 'X-Lang': getLang() },
  })
  return (await parse(response)).header
}

export async function loadDeviceHistory(id, signal) {
  const query = new URLSearchParams({ action: 'device_history', id: String(id) })
  const response = await fetch(`api.php?${query}`, {
    credentials: 'same-origin',
    cache: 'no-store',
    signal,
    headers: { Accept: 'application/json', 'X-Lang': getLang() },
  })
  return (await parse(response)).telemetry
}

export async function loadTrafficUsage(signal) {
  const response = await fetch('api.php?action=traffic_usage', {
    credentials: 'same-origin',
    cache: 'no-store',
    signal,
    headers: { Accept: 'application/json', 'X-Lang': getLang() },
  })
  return (await parse(response)).usage
}

export async function loadDiscoveryLog(index, host, signal) {
  const query = new URLSearchParams({ action: 'discovery_log', server: String(index), host })
  const response = await fetch(`api.php?${query}`, {
    credentials: 'same-origin',
    cache: 'no-store',
    signal,
    headers: { Accept: 'application/json', 'X-Lang': getLang() },
  })
  return parse(response)
}
