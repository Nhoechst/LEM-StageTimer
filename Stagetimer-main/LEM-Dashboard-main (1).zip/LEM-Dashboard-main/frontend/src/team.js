export function defaultTeamForLanguage(teams, language) {
  const preferred = language === 'de' ? 'de' : 'us'
  return teams.find((team) => team.key === preferred)?.key ?? teams[0]?.key
}
