export function closeAccountOnBlur(event, close) {
  // Touch browsers may blur the trigger without focusing the tapped button.
  // Outside pointer presses and Escape are handled separately.
  if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget)) {
    close()
  }
}
