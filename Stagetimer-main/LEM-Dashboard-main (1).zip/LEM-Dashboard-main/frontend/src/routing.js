export function parseHash(hash = window.location.hash) {
  const [path, query = ''] = hash.replace(/^#\/?/, '').split('?')
  const [page, arg] = path.split('/')
  if (page === 'search') {
    const params = new URLSearchParams(query)
    return { page, query: params.get('q') || '', model: params.get('model') }
  }
  if (page === 'discovery-log') {
    const params = new URLSearchParams(query)
    const returnTo = params.get('returnTo') || '#dashboard'
    return {
      page,
      index: /^\d+$/.test(arg ?? '') ? Number(arg) : -1,
      host: params.get('host') || '',
      returnTo: returnTo.startsWith('#') && !/^#\/?discovery-log(?:\/|$|\?)/.test(returnTo) ? returnTo : '#dashboard',
    }
  }
  // #site/<id> and #locations/<id> kept so old bookmarks still open the location page
  if ((page === 'location' || page === 'site' || page === 'locations') && Number(arg) > 0) return { page: 'site', siteId: Number(arg) }
  if (page === 'settings') return { page, section: arg || 'general' }
  if (page === 'account') return { page: 'settings', section: 'user' }
  if (page === 'maintenance' || page === 'dante') return { page, team: new URLSearchParams(query).get('team') }
  if (page === 'compliance') return { page }
  if (page === 'firmware' || page === 'baselines') return { page: 'compliance' }
  return { page: 'dashboard' }
}
