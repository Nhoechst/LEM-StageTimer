export const searchKey = (value) => String(value ?? '').trim().replace(/\s+/g, ' ').toLowerCase()

export function searchTarget(query, model = false) {
  return `search?${new URLSearchParams({ [model ? 'model' : 'q']: query })}`
}

export function inventoryIndex(state) {
  if (!state?.auth?.user) return []
  const sites = new Map((state.sites ?? []).map(site => [site.id, site]))
  const results = []
  const models = new Map()
  for (const device of state.devices ?? []) {
    const site = sites.get(device.site_id)
    const standalone = device.ownership === 'standalone'
    const team = standalone ? device.team : site?.team
    const target = standalone ? `dante?${new URLSearchParams({ team: device.team ?? '' })}` : site ? `location/${site.id}` : ''
    const location = standalone ? 'Standalone Dante' : site?.name ?? device.site ?? ''
    const detail = [device.ip, device.model, location, team].filter(Boolean).join(' · ')
    results.push({
      key: `device-${device.id}`, kind: 'Device', name: device.name, detail, target, device,
      fields: [device.name, device.ip, device.model, device.type, device.firmware, device.notes, device.status, location, site?.code, team],
    })
    const modelKey = searchKey(device.model)
    if (modelKey) {
      const model = models.get(modelKey) ?? { name: device.model.trim(), count: 0 }
      model.count++
      models.set(modelKey, model)
    }
  }
  for (const site of sites.values()) {
    results.push({
      key: `site-${site.id}`, kind: 'Location', name: site.name,
      detail: [site.code, site.subnet, site.team].filter(Boolean).join(' · '),
      target: `location/${site.id}`, fields: [site.name, site.code, site.subnet, site.address, site.notes, site.team],
    })
  }
  for (const [key, model] of models) {
    results.push({ key: `model-${key}`, kind: 'Model', name: model.name, count: model.count, detail: '', target: searchTarget(model.name, true), fields: [model.name] })
  }
  for (const pc of state.pcs ?? []) {
    results.push({
      key: `pc-${pc.id}`, kind: 'PC', name: pc.name,
      detail: [pc.ip, pc.location, pc.os, pc.team].filter(Boolean).join(' · '),
      target: `maintenance?${new URLSearchParams({ team: pc.team ?? '' })}`,
      fields: [pc.name, pc.ip, pc.location, pc.os, pc.type, pc.comments, pc.checked_by, pc.status, pc.team],
    })
  }
  return results
}

export function searchInventory(index, query, model = null) {
  if (model !== null) return index.filter(result => result.kind === 'Device' && searchKey(result.device.model) === searchKey(model))
  const key = searchKey(query)
  if (!key) return []
  const terms = key.split(' ')
  const ranked = []
  for (const result of index) {
    const fields = result.fields.map(searchKey)
    if (!terms.every(term => fields.some(field => field.includes(term)))) continue
    const score = searchKey(result.name) === key ? 0 : fields.includes(key) ? 1 : fields.some(field => field.startsWith(key)) ? 2 : 3
    ranked.push({ result, score })
  }
  return ranked.sort((a, b) => a.score - b.score || a.result.name.localeCompare(b.result.name, undefined, { numeric: true }) || a.result.key.localeCompare(b.result.key)).map(item => item.result)
}
