// Equipment photos: URL of a device's photo and resizing before upload.

// PCs on the PC Maintenance list have kind 'pc'.
export const photoUrl = (device) => `api.php?action=photo&id=${device.id}${device.kind === 'pc' ? '&kind=pc' : ''}&v=${encodeURIComponent(device.photo)}`

/**
 * Shrink a picked image to at most 1600 px and re-encode it as JPEG (smaller
 * uploads, and drops the camera's metadata such as GPS). Falls back to the
 * original file if the browser can't decode it.
 */
export async function preparePhoto(file, maxSide = 1600) {
  const url = URL.createObjectURL(file)
  try {
    const img = new Image()
    img.src = url
    await img.decode()
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight))
    const canvas = document.createElement('canvas')
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale))
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale))
    const ctx = canvas.getContext('2d')
    ctx.fillStyle = '#fff'
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.85))
    return blob ?? file
  } catch {
    return file
  } finally {
    URL.revokeObjectURL(url)
  }
}
