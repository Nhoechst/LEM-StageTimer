import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { loadHeader, loadState, post } from './api.js'
import { isCheckable, summarise } from './format.js'
import { LANGUAGES, applyLanguageChoice, detectLanguage, getLang, storedChoice, t, teamName } from './i18n.js'
import { defaultTeamForLanguage } from './team.js'
import { AccountMenu, HeaderStatus, LoginDialog } from './components/Auth.jsx'
import { PasswordChangeForm } from './components/Account.jsx'
import Dashboard from './components/Dashboard.jsx'
import Firmware from './components/Firmware.jsx'
import Icon from './components/icons.jsx'
import { DeleteDialog, RecordDialog } from './components/Dialogs.jsx'
import Maintenance from './components/Maintenance.jsx'
import Settings from './components/Settings.jsx'
import SitePage from './components/SitePage.jsx'
import DiscoveryLog from './components/DiscoveryLog.jsx'
import DanteManager from './components/DanteManager.jsx'
import GlobalSearch, { SearchPage } from './components/GlobalSearch.jsx'
import { inventoryIndex } from './search.js'
import { parseHash } from './routing.js'

const NO_CHECK = { siteIds: new Set(), deviceIds: new Set() }
const PAGES = [['dashboard', 'Device Status'], ['maintenance', 'PC Maintenance'], ['compliance', 'Firmware Compliance']]
const AUTH_REQUIRED_PAGES = new Set(['site', 'dante', 'maintenance', 'compliance', 'search'])

function storedTeam() {
  try {
    return localStorage.getItem('team') || ''
  } catch {
    return ''
  }
}

export default function App() {
  const [state, setState] = useState(null)
  const [dark, setDark] = useState(() => document.body.classList.contains('dark'))
  const [visualTheme, setVisualTheme] = useState('main')
  const [loadError, setLoadError] = useState('')
  const [route, setRoute] = useState(parseHash)
  const [flashes, setFlashes] = useState([])
  const [editing, setEditing] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const [checking, setChecking] = useState(NO_CHECK)
  const [progress, setProgress] = useState(null)
  // Manual checks have a server-side cooldown; the buttons count it down.
  const [cooldownUntil, setCooldownUntil] = useState(0)
  const [deviceCooldowns, setDeviceCooldowns] = useState({})
  const [now, setNow] = useState(() => Date.now())
  // Language: detected from the browser, or chosen at the bottom of the page.
  const [langChoice, setLangChoice] = useState(storedChoice)
  // Team (United States / Germany): which locations are shown.
  const [teamChoice, setTeamChoice] = useState(storedTeam)
  // Top bar status of crucial equipment (e.g. Discovery Server), refreshed every minute.
  const [header, setHeader] = useState(null)
  const [loggingIn, setLoggingIn] = useState(false)
  const [loginRevision, setLoginRevision] = useState(0)
  const checkRunning = useRef(false)
  const flashId = useRef(0)

  // Every new state from the server also carries the remaining check cooldown.
  const applyState = useCallback((next) => {
    setState(next)
    const theme = next?.auth.user ? next.profile?.theme ?? 'main' : 'main'
    for (const name of ['tui', 'teams', 'cmd', 'tricaster', 'win98', 'vista']) {
      document.body.classList.toggle(name, theme === name)
    }
    setVisualTheme(theme)
    if (next?.header) setHeader(next.header)
    if (next?.checks) {
      setNow(Date.now())
      setCooldownUntil(Date.now() + next.checks.available_in * 1000)
    }
  }, [])

  const flash = useCallback((type, message, details = []) => {
    const id = ++flashId.current
    setFlashes((f) => [...f.slice(-4), { id, type, message, details }])
    if (type === 'success' && details.length === 0) {
      setTimeout(() => setFlashes((f) => f.filter((x) => x.id !== id)), 8000)
    }
  }, [])

  const refresh = useCallback(async () => {
    try {
      applyState(await loadState())
      setLoadError('')
    } catch (err) {
      setLoadError(err.message)
    }
  }, [applyState])

  useEffect(() => {
    const nextDeviceCooldown = Object.values(deviceCooldowns).filter((until) => until > now).reduce((next, until) => Math.min(next, until), Infinity)
    const nextCooldown = Math.min(cooldownUntil > now ? cooldownUntil : Infinity, nextDeviceCooldown)
    if (!Number.isFinite(nextCooldown)) return undefined
    const timer = setTimeout(() => setNow(Date.now()), 1000)
    return () => clearTimeout(timer)
  }, [cooldownUntil, deviceCooldowns, now])

  useEffect(() => {
    loadState().then(applyState, (err) => setLoadError(err.message))
    const onHash = () => {
      setRoute(parseHash())
      window.scrollTo(0, 0)
    }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [applyState])

  useEffect(() => {
    const update = () => {
      if (document.visibilityState === 'visible') loadHeader().then(setHeader, () => {})
    }
    update()
    const timer = setInterval(update, 60000)
    document.addEventListener('visibilitychange', update)
    return () => {
      clearInterval(timer)
      document.removeEventListener('visibilitychange', update)
    }
  }, [])

  useEffect(() => {
    if (state && AUTH_REQUIRED_PAGES.has(route.page) && !state.auth.user) {
      window.location.replace('#dashboard')
    }
  }, [state, route.page])

  useEffect(() => {
    if (state) document.title = t(state.config.title)
  }, [state, langChoice])

  const go = (target) => {
    window.location.assign(`#${target}`)
  }

  const toggleTheme = () => {
    const next = document.body.classList.toggle('dark')
    localStorage.setItem('theme', next ? 'dark' : 'light')
    setDark(next)
  }
  const chooseVisualTheme = async (next) => {
    if (!state?.auth.user) return
    try {
      await mutate('save_theme', { theme: next })
    } catch (error) {
      flash('error', error.message)
    }
  }

  const teams = state?.config.teams ?? []
  // A location page always shows its own team; otherwise the saved choice,
  // or Germany for German browsers / the first team for everyone else.
  const routeSite = route.page === 'site' ? state?.sites.find((s) => s.id === route.siteId) : null
  const defaultTeam = defaultTeamForLanguage(teams, getLang())
  const routeTeam = teams.find(tm => tm.key === route.team)?.key
  const team = routeSite?.team ?? routeTeam ?? (teams.some((tm) => tm.key === teamChoice) ? teamChoice : defaultTeam)
  const selectTeam = (key) => {
    try {
      localStorage.setItem('team', key)
    } catch {
      // not remembered
    }
    setTeamChoice(key)
    if (route.page === 'site' && routeSite?.team !== key) go('dashboard')
    if (routeTeam) go(`${route.page}?${new URLSearchParams({ team: key })}`)
  }

  /** The state limited to the selected team's locations and their devices (and the team's PCs). */
  const view = useMemo(() => {
    if (!state || teams.length < 2) return state
    const sites = state.sites.filter((s) => s.team === team)
    const ids = new Set(sites.map((s) => s.id))
    return { ...state, sites, devices: state.devices.filter((d) => d.ownership === 'standalone' ? d.team === team : ids.has(d.site_id)), pcs: state.pcs.filter((p) => p.team === team) }
  }, [state, team, teams.length])

  const siteSummaries = useMemo(() => {
    if (!view) return []
    return view.sites.map((site) => ({ site, counts: summarise(view.devices.filter((d) => d.site_id === site.id)) }))
  }, [view])
  const total = useMemo(() => summarise(view ? view.devices : []), [view])
  const searchIndex = useMemo(() => inventoryIndex(state), [state])

  const chooseLanguage = (choice) => {
    applyLanguageChoice(choice)
    setLangChoice(choice)
  }

  /** Save/delete: throws on error so the dialog can show it. */
  const mutate = async (action, body) => {
    let res
    try {
      res = await post(action, body)
    } catch (err) {
      if (err.status === 401) refresh() // logged out meanwhile (session expired): hide the admin buttons
      throw err
    }
    applyState(res.state)
    if (action === 'login' || action === 'setup') setLoginRevision((n) => n + 1)
    if (action === 'save_settings') loadHeader().then(setHeader, () => {}) // top bar devices may have changed
    flash(res.details.length ? 'warning' : 'success', res.message, res.details)
    return res
  }

  const logout = async () => {
    try {
      await mutate('logout')
      if (route.page === 'settings') go('dashboard')
    } catch (err) {
      flash('error', err.message)
    }
  }

  const onImport = async (formData, clientError) => {
    if (!formData) {
      flash('error', clientError)
      return false
    }
    try {
      await mutate('import', formData)
      return true
    } catch (err) {
      flash('error', err.message, err.details)
      return false
    }
  }

  /**
   * Live status check: one site at a time so each site's rows show
   * "Checking…" and then update in place with Online/Offline + latency.
   */
  const runCheck = async (sites, deviceId = null) => {
    if (checkRunning.current || !state || (deviceId === null && cooldown > 0)
      || (deviceId !== null && (deviceCooldowns[deviceId] ?? 0) > Date.now())) return
    const checkable = isCheckable
    const queue = sites.filter((s) => state.devices.some((d) => d.site_id === s.id && checkable(d)))
    if (queue.length === 0) {
      flash('warning', t('No devices with an IP address to check.'))
      return
    }
    checkRunning.current = true
    const deviceCooldownSeconds = state.checks?.cooldown_seconds ?? 60
    if (deviceId !== null) {
      const startedAt = Date.now()
      setDeviceCooldowns((current) => ({ ...current, [deviceId]: startedAt + deviceCooldownSeconds * 1000 }))
      setNow(startedAt)
    }
    // One id for the whole click, so the server counts "Check all" as one check.
    const run = Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('')
    const totals = { checked: 0, online: 0, offline: 0 }
    let failed = 0
    for (const [i, site] of queue.entries()) {
      setProgress({ site: site.name, index: i + 1, count: queue.length })
      setChecking({
        siteIds: new Set([site.id]),
        deviceIds: new Set(state.devices.filter((d) => d.site_id === site.id && checkable(d) && (deviceId === null || d.id === deviceId)).map((d) => d.id)),
      })
      try {
        const res = await post('check', { site_id: site.id, ...(deviceId === null ? {} : { device_id: deviceId }), run })
        applyState(res.state)
        if (deviceId !== null) {
          const completedAt = Date.now()
          setDeviceCooldowns((current) => ({
            ...current,
            [deviceId]: completedAt + (res.state?.checks?.cooldown_seconds ?? deviceCooldownSeconds) * 1000,
          }))
          setNow(completedAt)
        }
        totals.checked += res.result.checked
        totals.online += res.result.online
        totals.offline += res.result.offline
      } catch (err) {
        failed++
        flash('error', `${site.name}: ${err.message}`)
        if (err.status === 429) {
          // Cooldown / check already running: stop and show the countdown.
          failed = queue.length - i
          if (err.retryAfter && deviceId !== null) {
            setDeviceCooldowns((current) => ({ ...current, [deviceId]: Date.now() + err.retryAfter * 1000 }))
          } else if (err.retryAfter) {
            setCooldownUntil(Date.now() + err.retryAfter * 1000)
          }
          setNow(Date.now())
          break
        }
      }
    }
    setChecking(NO_CHECK)
    setProgress(null)
    checkRunning.current = false
    setNow(Date.now())
    if (failed === queue.length) return
    const where = queue.length === 1 ? queue[0].name : t('{n} location(s)', { n: queue.length - failed })
    flash(failed ? 'warning' : 'success', t('Checked {where}: {checked} device(s), {online} online, {offline} offline.', { where, ...totals }))
  }

  /** Check the selected team's separate PC inventory. */
  const checkSeparate = async (target) => {
    if (checkRunning.current || !view || cooldown > 0) return
    const records = target === 'pcs' ? view.pcs : view.devices.filter((d) => d.ownership === 'standalone')
    const ids = records.filter(isCheckable).map((p) => p.id)
    if (ids.length === 0) {
      flash('warning', t('No devices with an IP address to check.'))
      return
    }
    checkRunning.current = true
    setProgress({ site: t(target === 'pcs' ? 'PCs' : 'Standalone Dante'), index: 1, count: 1 })
    setChecking({ siteIds: new Set(), deviceIds: new Set(ids) })
    try {
      await mutate('check', { target, team })
    } catch (err) {
      flash('error', err.message)
      if (err.status === 429 && err.retryAfter) setCooldownUntil(Date.now() + err.retryAfter * 1000)
    } finally {
      setChecking(NO_CHECK)
      setProgress(null)
      checkRunning.current = false
      setNow(Date.now())
    }
  }

  // Inventory editing and maintenance completion require a signed-in account.
  const needsLogin = () => {
    if (state?.auth.user) return false
    setLoggingIn(true)
    return true
  }
  const onAdd = (kind, defaults = {}, options = {}) =>
    !needsLogin() && setEditing({ kind, record: null, defaults: kind === 'site' || kind === 'dante' ? { team, ...defaults } : defaults, ...options })
  const onEdit = (kind, record) => {
    if (needsLogin()) return
    if (kind === 'dante') {
      const { id, name, ip, web_url, model, firmware, maintained, notes, photo, team: deviceTeam } = record
      setEditing({ kind, record: { id, name, ip, web_url, model, firmware, maintained, notes, photo, team: deviceTeam } })
    } else if (kind === 'device') {
      const { id, site_id, name, ip, type, model, firmware, maintained, notes, stored_status, photo, site } = record
      setEditing({ kind, record: { id, site_id, name, ip, type, model, firmware, maintained, notes, status: stored_status, photo, site } })
    } else if (kind === 'pc') {
      const { id, name, ip, type, os, location, team: pcTeam, checked, checked_by, comments, photo } = record
      setEditing({ kind, record: { id, kind: 'pc', name, ip, type, os, location, team: pcTeam, checked, checked_by, comments, photo } })
    } else {
      setEditing({ kind, record })
    }
  }

  const onDelete = (record, after) => setDeleting({ ...record, after })
  const busy = progress !== null
  const cooldown = busy ? 0 : Math.max(0, Math.ceil((cooldownUntil - now) / 1000))
  const user = state?.auth.user ?? null
  const activeTab = AUTH_REQUIRED_PAGES.has(route.page) && !user || route.page === 'site' || route.page === 'dante' || route.page === 'search' ? 'dashboard' : route.page
  const role = state?.auth.role ?? null
  const canManage = role === 'admin' || role === 'lead'
  const accountControls = state && (
    <AccountMenu user={user} onLogin={() => {
      go('settings')
      setLoggingIn(true)
    }} onSettings={() => go('settings')} onLogout={logout} />
  )
  const themeControl = (
    <button type="button" className="theme-btn" aria-label={dark ? t('Switch to light mode') : t('Switch to dark mode')} title={dark ? t('Light mode') : t('Dark mode')} onClick={toggleTheme}>
      <Icon name={dark ? 'sun' : 'moon'} />
    </button>
  )

  if (state?.auth.must_change_password) {
    return (
      <main className="shell">
        <div className="panel account-panel">
          <h2>{t('Change password')}</h2>
          <p>{t('Logged in as {name}', { name: user })}</p>
          <PasswordChangeForm key={user} required onSave={mutate} />
          <button type="button" className="button secondary" onClick={logout}>{t('Log out')}</button>
        </div>
      </main>
    )
  }

  if (route.page === 'discovery-log') {
    return (
      <main className="shell">
        <a className="button secondary discovery-back" href={route.returnTo}>← {t('Back to previous page')}</a>
        {loadError && (
          <div className="panel">
            <strong>{t('Could not load data from the server.')}</strong>
            <div className="error">{loadError}</div>
            <button type="button" className="button secondary" onClick={refresh}>{t('Retry')}</button>
          </div>
        )}
        {!state && !loadError && <div className="panel"><p className="empty">{t('Loading…')}</p></div>}
        {state && (
          <DiscoveryLog key={`${route.index}-${route.host}`} index={route.index} host={route.host} device={(header ?? state.header)?.[route.index]} user={user} loginRevision={loginRevision} onLogin={() => setLoggingIn(true)} />
        )}
        <LoginDialog open={loggingIn} setup={!!state?.auth.setup} onClose={() => setLoggingIn(false)} onSubmit={mutate} />
      </main>
    )
  }

  return (
    <>
      <header className="appbar">
        <div className="appbar-title">
          <strong>{t(state?.config.title ?? 'Equipment Status')}</strong>
          {state?.config.subtitle && <span>{t(state.config.subtitle)}</span>}
        </div>
        <div className="mobile-header-actions">
          {accountControls}
          {themeControl}
        </div>
        <div className="appbar-center">
          {/* Country selector in the middle of the header; it doesn't apply to the admin Settings. */}
          {teams.length > 1 && route.page !== 'settings' && route.page !== 'discovery-log' && (
            <div className="team-toggle" role="group" aria-label={t('Country')}>
              {teams.map((tm) => {
                const label = teamName(tm)
                return (
                  <button key={tm.key} type="button" className={tm.key === team ? 'active' : ''} aria-label={label} aria-pressed={tm.key === team} onClick={() => selectTeam(tm.key)}>
                    <span className="team-code">{tm.key.toUpperCase()}</span>
                    {label.trim().toLowerCase() !== tm.key.trim().toLowerCase() && <> {label}</>}
                  </button>
                )
              })}
            </div>
          )}
        </div>
        <div className="appbar-actions">
          <HeaderStatus devices={header ?? state?.header} />
          <div className="desktop-account">
            {accountControls}
            {themeControl}
          </div>
        </div>
      </header>
    <div className="shell navigation-shell">
      <div className="toolbar">
        {user && (
          <nav className="pill-tabs" aria-label={t('Pages')}>
            {PAGES.map(([key, label]) => (
              <button key={key} type="button" className={activeTab === key ? 'active' : ''} aria-current={route.page === key ? 'page' : undefined} onClick={() => go(key)}>{t(label)}</button>
            ))}
          </nav>
        )}
        {user && <GlobalSearch key={user} index={searchIndex} />}
      </div>
    </div>
    <div className={`shell${route.page === 'site' || route.page === 'maintenance' ? ' inventory-shell' : ''}`}>

      {loadError && (
        <div className="panel external-panel">
          <strong>{t('Could not load data from the server.')}</strong>
          <div className="error">{loadError}</div>
          <button type="button" className="button secondary" onClick={refresh}>{t('Retry')}</button>
        </div>
      )}

      {progress && (
        <div className="notice flash check-progress" role="status">
          <span>{t('Checking')} <b>{progress.site}</b>{progress.count > 1 ? ` (${t('{i} of {n}', { i: progress.index, n: progress.count })})` : ''}…</span>
          <div className="progress"><i style={{ width: `${((progress.index - 1) / progress.count) * 100}%` }} /></div>
        </div>
      )}

      {flashes.map((f) => (
        <div key={f.id} className={`notice flash flash-${f.type}`} role="status">
          <button type="button" className="flash-close" aria-label={t('Dismiss')} onClick={() => setFlashes((x) => x.filter((y) => y.id !== f.id))}>×</button>
          <span className={f.type === 'error' ? 'error' : ''}>{f.message}</span>
          {f.details.length > 0 && <ul className="small">{f.details.map((d, i) => <li key={i}>{d}</li>)}</ul>}
        </div>
      ))}

      {!state && !loadError && <div className="panel"><p className="empty">{t('Loading…')}</p></div>}

      {state && (route.page === 'dashboard' || (AUTH_REQUIRED_PAGES.has(route.page) && !user)) && (
        <Dashboard admin={canManage} user={user} state={view} team={team} siteSummaries={siteSummaries} total={total} checking={checking} checkingAll={busy && progress.count > 1} busy={busy} cooldown={cooldown} onCheck={runCheck} go={go} onAdd={onAdd} onLogin={() => setLoggingIn(true)} />
      )}
      {state && route.page === 'dante' && user && (
        <DanteManager devices={view.devices} admin={canManage} onAdd={onAdd} onEdit={onEdit} onDelete={onDelete} go={go} />
      )}
      {state && route.page === 'site' && user && (
        <SitePage
          key={route.siteId}
          summary={siteSummaries.find((s) => s.site.id === route.siteId)}
          admin={canManage} user={user} state={view} checking={checking} busy={busy} cooldown={cooldown} deviceCooldowns={deviceCooldowns} now={now} onCheck={runCheck} go={go}
          onAdd={onAdd} onEdit={onEdit} onDelete={onDelete} onImport={onImport}
        />
      )}
      {state && route.page === 'maintenance' && user && (
        <Maintenance admin={canManage} user={user} state={view} team={team} checking={checking} busy={busy} cooldown={cooldown} onCheckPcs={() => checkSeparate('pcs')} onAdd={onAdd} onEdit={onEdit} onDelete={onDelete} onImport={onImport} onLogin={() => setLoggingIn(true)} />
      )}
      {state && route.page === 'compliance' && user && (
        <Firmware admin={canManage} state={view} total={total} onEdit={onEdit} go={go} />
      )}
      {state && route.page === 'search' && user && (
        <SearchPage key={`${route.query}-${route.model}`} index={searchIndex} query={route.query} model={route.model} />
      )}
      {state && route.page === 'settings' && (
        <Settings state={state} section={route.section} go={go} onSave={mutate} onLogin={() => setLoggingIn(true)} visualTheme={visualTheme} onThemeChange={chooseVisualTheme} onAdd={onAdd} onEdit={onEdit} onDelete={onDelete} onImport={onImport} team={team} />
      )}
      <LoginDialog open={loggingIn} setup={!!state?.auth.setup} onClose={() => setLoggingIn(false)} onSubmit={mutate} />
      <RecordDialog editing={editing} sites={view?.sites ?? []} teams={teams} user={user} onClose={() => setEditing(null)} onSave={mutate} />
      <DeleteDialog deleting={deleting} onClose={() => setDeleting(null)} onDelete={mutate} />

      <div className="lang-bar">
        <label>
          <span aria-hidden="true">🌐</span> {t('Language')}{' '}
          <select value={langChoice} onChange={(e) => chooseLanguage(e.target.value)}>
            <option value="auto">{t('Automatic ({name})', { name: LANGUAGES[detectLanguage()] })}</option>
            {Object.entries(LANGUAGES).map(([code, name]) => <option key={code} value={code}>{name}</option>)}
          </select>
        </label>
      </div>

      <datalist id="device-types">
        {[...new Set((state?.devices ?? []).map((d) => d.type).filter(Boolean))].map((v) => <option key={v} value={v} />)}
      </datalist>
      <datalist id="pc-types">
        {[...new Set(['Desktop', 'Laptop', ...(state?.pcs ?? []).map((p) => p.type)].filter(Boolean))].map((v) => <option key={v} value={v} />)}
      </datalist>
      <datalist id="pc-os">
        {[...new Set(['Windows 11', 'Windows 10', ...(state?.pcs ?? []).map((p) => p.os)].filter(Boolean))].map((v) => <option key={v} value={v} />)}
      </datalist>
      <datalist id="pc-locations">
        {[...new Set((view?.pcs ?? []).map((p) => p.location).filter(Boolean))].map((v) => <option key={v} value={v} />)}
      </datalist>
      <datalist id="device-models">
        {[...new Set([...(state?.devices ?? []).map((d) => d.model), ...(state?.firmware ?? []).map((f) => f.model)].filter(Boolean))].map((v) => <option key={v} value={v} />)}
      </datalist>
    </div>
    </>
  )
}
