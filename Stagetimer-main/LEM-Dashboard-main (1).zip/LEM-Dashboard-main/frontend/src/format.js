import { locale } from './i18n.js'

export const STATUS_LABELS = { online: 'Online', offline: 'Offline', external: 'External Network', stale: 'Stale', unknown: 'Unknown' }
export const STATUS_INDEX = { online: 0, offline: 1, stale: 2, unknown: 3, external: 4 }
export const FW_LABELS = { compliant: 'Compliant', non_compliant: 'Non-compliant', unknown: 'No latest info' }
export const FW_BADGE = { compliant: 'checked', non_compliant: 'status-1', unknown: 'status-3' }

export const isCheckable = (device) => Boolean(device.ip?.trim()) && device.ip.trim() !== '0.0.0.0' && device.status !== 'external'

// timeZone (IANA name) shows the time in that zone instead of the browser's.
export function fmtTime(ts, timeZone) {
  if (ts === null || ts === undefined) return '—'
  if (timeZone) {
    try {
      const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
        timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
      }).formatToParts(new Date(ts * 1000)).map((x) => [x.type, x.value]))
      return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`
    } catch {
      // unknown time zone: fall back to the browser's
    }
  }
  const d = new Date(ts * 1000)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

export const fmtLatency = (ms) => (ms === null || ms === undefined ? '' : `${ms} ms`)
export const averagePing = (value) => value == null ? '—' : fmtLatency(Math.round(value * 100) / 100)

export const pct = (part, whole) => (whole > 0 ? Math.round((part / whole) * 100) : 0)

/** Percentage with one decimal, e.g. 81.3 */
export const pct1 = (part, whole) => (whole > 0 ? (part / whole) * 100 : 0).toLocaleString(locale(), { minimumFractionDigits: 1, maximumFractionDigits: 1 })

export function ipValue(text) {
  const parts = String(text).trim().split('.')
  if (parts.length !== 4) return Number.MAX_SAFE_INTEGER
  return parts.reduce((acc, p) => acc * 256 + (parseInt(p, 10) || 0), 0)
}

/** Count devices per status / firmware compliance. */
export function summarise(devices) {
  const s = { total: 0, online: 0, offline: 0, external: 0, stale: 0, unknown: 0, no_status: 0, fw_compliant: 0, fw_non_compliant: 0, fw_unknown: 0 }
  for (const d of devices) {
    s.total++
    s[d.status]++
    if (d.status === 'stale' || d.status === 'unknown') s.no_status++
    s[`fw_${d.compliance}`]++
  }
  return s
}

const DAY = 86400000
const today = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d }

/**
 * Maintenance state of a PC: 'current', 'due_soon' (within 14 days), 'overdue' or 'never'.
 * Returns {state, due: Date|null, days: number|null (until due; negative = overdue)}.
 */
export function maintenance(d, intervalDays) {
  if (!d.maintained) return { state: 'never', due: null, days: null }
  const [y, m, day] = d.maintained.split('-').map(Number)
  const due = new Date(y, m - 1, day + intervalDays)
  const days = Math.round((due - today()) / DAY)
  return { state: days < 0 ? 'overdue' : days <= 14 ? 'due_soon' : 'current', due, days }
}

export const fmtDate = (date) => {
  if (!date) return '—'
  const p = (n) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}`
}
