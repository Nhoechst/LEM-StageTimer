import { useEffect, useRef, useState } from 'react'
import { t, teamName } from '../i18n.js'
import { photoUrl, preparePhoto } from '../photo.js'
import { Modal } from './ui.jsx'

// Labels and placeholders are translated when the form is rendered.
// A new location belongs to the country selected in the header.
const siteFields = () => [
  { name: 'name', label: 'Name', required: true },
  { name: 'code', label: 'Code', placeholder: 'e.g. CR1' },
  { name: 'subnet', label: 'Subnet / IP range', placeholder: 'e.g. 10.10.0.0/16' },
]

const FIRMWARE_FIELDS = [
  { name: 'manufacturer', label: 'Manufacturer', placeholder: 'e.g. Cisco' },
  { name: 'model', label: 'Device model', required: true, list: 'device-models' },
  { name: 'approved', label: 'Latest firmware', required: true, placeholder: 'e.g. 17.9.4' },
  { name: 'notes', label: 'Notes', type: 'textarea' },
]

function deviceFields(sites) {
  return [
    { name: 'site_id', label: 'Location', type: 'select', required: true, options: sites.map((s) => [String(s.id), s.name]) },
    { name: 'name', label: 'Name', required: true },
    { name: 'ip', label: 'IP address / host name', placeholder: 'e.g. 10.10.0.1 or https://10.10.0.1:8443/' },
    { name: 'type', label: 'Type', list: 'device-types', placeholder: 'Switch, Codec, Display…' },
    { name: 'model', label: 'Model', list: 'device-models' },
    { name: 'firmware', label: 'Current firmware' },
    { name: 'notes', label: 'Notes', type: 'textarea' },
  ]
}

// PC Maintenance's own PCs (not linked to Device Status locations).
const pcFields = (sites, teams) => [
  { name: 'name', label: 'PC name', required: true },
  { name: 'type', label: 'Type', list: 'pc-types', placeholder: 'Desktop, Laptop…' },
  { name: 'ip', label: 'IP address / host name', placeholder: 'e.g. 10.10.0.50 or https://10.10.0.50/' },
  { name: 'os', label: 'Operating system', list: 'pc-os', placeholder: 'e.g. Windows 11 23H2' },
  { name: 'location', label: 'Location', list: 'pc-locations', placeholder: 'e.g. Control Room 1' },
  ...(teams.length > 1 ? [{ name: 'team', label: 'Team', type: 'select', required: true, options: teams.map((tm) => [tm.key, teamName(tm)]) }] : []),
  { name: 'checked', label: 'Last checked', type: 'date' },
  { name: 'checked_by', label: 'Checked by' },
  { name: 'comments', label: 'Comments', type: 'textarea' },
]

const PC_CHECK_FIELDS = [
  { name: 'comments', label: 'Comments', type: 'textarea' },
]

const KINDS = {
  site: { title: 'location', action: 'save_site', fields: siteFields },
  device: { title: 'device', action: 'save_device', fields: deviceFields, photos: true },
  dante: { title: 'Dante device', action: 'save_device', fields: (sites, teams) => [
    ...deviceFields(sites).filter((f) => f.name !== 'site_id' && f.name !== 'type'),
    ...(teams.length > 1 ? [{ name: 'team', label: 'Team', type: 'select', required: true, options: teams.map((tm) => [tm.key, teamName(tm)]) }] : []),
  ], photos: true },
  firmware: { title: 'latest firmware', action: 'save_firmware', fields: () => FIRMWARE_FIELDS },
  pc: { title: 'PC', action: 'save_pc', fields: pcFields, photos: true, photoKind: 'pc' },
  // "Complete check": records today's date, who checked the PC and comments.
  pc_check: { heading: 'Complete check', action: 'complete_pc_check', fields: () => PC_CHECK_FIELDS },
}

function Field({ field, value, onChange }) {
  const common = {
    name: field.name,
    value: value ?? '',
    required: field.required,
    onChange: (e) => onChange(field.name, e.target.value),
  }
  let input
  if (field.locked) {
    const label = field.options.find(([v]) => v === String(value))?.[1] ?? ''
    input = <input value={label} readOnly aria-readonly="true" className="readonly" />
  } else if (field.type === 'select') {
    input = (
      <select {...common}>
        {field.options.map(([v, label]) => <option key={v} value={v}>{label}</option>)}
      </select>
    )
  } else if (field.type === 'textarea') {
    input = <textarea {...common} rows={2} maxLength={500} />
  } else if (field.type === 'date') {
    input = <input {...common} type="date" />
  } else {
    input = <input {...common} maxLength={500} placeholder={field.placeholder && t(field.placeholder)} list={field.list} />
  }
  return <label>{t(field.label)} {input}</label>
}

/** Photo of a device: take/choose one (phones offer the camera), replace or remove it. */
function PhotoField({ record, photo, onChange, onError }) {
  const [preview, setPreview] = useState(null) // picked photo (Blob), drawn on a canvas
  const [preparing, setPreparing] = useState(false)
  const canvas = useRef(null)
  useEffect(() => {
    if (!preview || !canvas.current) return undefined
    let cancelled = false
    createImageBitmap(preview).then((bitmap) => {
      const el = canvas.current
      if (cancelled || !el) return
      el.width = bitmap.width
      el.height = bitmap.height
      el.getContext('2d').drawImage(bitmap, 0, 0)
    }).catch(() => {})
    return () => { cancelled = true }
  }, [preview])

  const pick = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!file.type.startsWith('image/')) {
      onError(t('The photo must be a JPEG, PNG, GIF or WebP image.'))
      return
    }
    setPreparing(true)
    const blob = await preparePhoto(file)
    setPreparing(false)
    setPreview(blob)
    onChange({ file: blob, remove: false })
  }
  const saved = record.photo && !photo.remove && !preview ? photoUrl(record) : ''
  const current = !!preview || !!saved

  return (
    <div className="photo-field">
      <span className="photo-field-label">{t('Photo')}</span>
      {preview ? <canvas ref={canvas} className="photo-preview" role="img" aria-label={t('Photo of {name}', { name: record.name || t('device') })} />
        : saved ? <img src={saved} alt={t('Photo of {name}', { name: record.name || t('device') })} /> : <p className="muted small">{t('No photo yet. Add one so the equipment is easy to find.')}</p>}
      <div className="head-actions">
        <label className="button secondary tiny photo-pick">
          {preparing ? t('Preparing…') : current ? t('Replace photo') : t('Add photo')}
          <input type="file" accept="image/*" onChange={pick} disabled={preparing} />
        </label>
        {current && (
          <button type="button" className="button tiny danger" onClick={() => { setPreview(null); onChange({ file: null, remove: true }) }}>{t('Remove photo')}</button>
        )}
      </div>
    </div>
  )
}

/**
 * Add / edit dialog for sites, devices and latest firmware versions.
 * editing = {kind, record|null, defaults?}
 */
export function RecordDialog({ editing, sites, teams = [], user, onClose, onSave }) {
  const kind = editing ? KINDS[editing.kind] : null
  return (
    <Modal open={!!editing} onClose={onClose}>
      {kind && <RecordForm key={`${editing.kind}-${editing.record?.id ?? 'new'}`} kind={kind} editing={editing} sites={sites} teams={teams} user={user} onClose={onClose} onSave={onSave} />}
    </Modal>
  )
}

function RecordForm({ kind, editing, sites, teams, user, onClose, onSave }) {
  const fields = kind.fields(sites, teams).map((f) => (editing.lockSite && f.name === 'site_id' ? { ...f, locked: true } : f))
  const [values, setValues] = useState(() => {
    const initial = { id: 0 }
    for (const f of fields) initial[f.name] = f.type === 'select' && f.required ? (f.options[0]?.[0] ?? '') : ''
    Object.assign(initial, editing.defaults || {}, editing.record || {})
    if (editing.kind === 'dante') Object.assign(initial, { ownership: 'standalone', site_id: 0, type: 'Dante' })
    if (initial.web_url) initial.ip = initial.web_url
    if (initial.site_id !== undefined) initial.site_id = String(initial.site_id)
    return initial
  })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [photo, setPhoto] = useState({ file: null, remove: false }) // devices only

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      const res = await onSave(kind.action, values)
      if (kind.photos && (photo.file || (photo.remove && values.photo))) {
        const id = values.id || res?.result?.id
        setValues((s) => ({ ...s, id })) // saving again updates instead of adding a second device
        if (photo.file) {
          const form = new FormData()
          form.append('id', String(id))
          if (kind.photoKind) form.append('kind', kind.photoKind)
          form.append('photo', photo.file, 'photo.jpg')
          await onSave('upload_photo', form)
        } else {
          await onSave('delete_photo', { id, kind: kind.photoKind })
        }
      }
      onClose()
      editing.next?.(values.id || res?.result?.id) // e.g. "Add PC" continues after adding its location
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>
        {kind.heading ? t(kind.heading) : t(`${editing.record ? 'Edit' : 'Add'} ${kind.title}`)}
        {kind.heading && values.name && <span className="dialog-sub"> {values.name}</span>}
        {editing.lockSite && <span className="dialog-sub"> {t('to {name}', { name: sites.find((s) => String(s.id) === String(values.site_id))?.name })}</span>}
      </h2>
      {kind.action === 'complete_pc_check' && <p className="notice">{t('Confirm that {name} has completed maintenance. This sign-off will be recorded under {user}.', { name: values.name, user })}</p>}
      {editing.kind === 'dante' && <p className="notice">{t('Standalone Dante devices need no location. Their addresses are checked from this server, independently of location network ranges.')}</p>}
      {fields.map((f) => (
        <Field key={f.name} field={f} value={values[f.name]} onChange={(name, v) => setValues((s) => ({ ...s, [name]: v }))} />
      ))}
      {kind.photos && <PhotoField record={values} photo={photo} onChange={setPhoto} onError={setError} />}
      <div className="error" role="alert">{error}</div>
      <div className="dialog-actions">
        <button type="button" className="button secondary" onClick={onClose}>{t('Cancel')}</button>
        <button type="submit" className="button primary" disabled={busy}>{busy ? t('Saving…') : kind.action === 'complete_pc_check' ? t('Confirm check') : t('Save')}</button>
      </div>
    </form>
  )
}

/** deleting = {kind, id, name, extra?} */
export function DeleteDialog({ deleting, onClose, onDelete }) {
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const close = () => {
    setError('')
    onClose()
  }
  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    try {
      await onDelete(`delete_${deleting.kind}`, { id: deleting.id })
      deleting.after?.()
      close()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }
  return (
    <Modal open={!!deleting} onClose={close}>
      {deleting && (
        <form onSubmit={submit}>
          <h2>{t('Delete {name}?', { name: deleting.name })}</h2>
          <p className="notice">{deleting.extra ? `${deleting.extra} ` : ''}{t('This cannot be undone.')}</p>
          <div className="error" role="alert">{error}</div>
          <div className="dialog-actions">
            <button type="button" className="button secondary" onClick={close}>{t('Cancel')}</button>
            <button type="submit" className="button danger" disabled={busy}>{busy ? t('Deleting…') : t('Delete')}</button>
          </div>
        </form>
      )}
    </Modal>
  )
}
