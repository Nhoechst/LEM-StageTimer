import { useEffect, useState } from 'react'
import { loadDeviceHistory } from '../api.js'
import { averagePing, fmtTime, pct1 } from '../format.js'
import { t } from '../i18n.js'
import AnnualSnapshots from './AnnualSnapshots.jsx'

function PingGraph({ samples }) {
  const width = 900
  const height = 240
  const left = 70
  const right = width - 20
  const top = 20
  const bottom = height - 40
  const start = samples[0].checked_at
  const end = samples[samples.length - 1].checked_at
  const maximum = Math.max(1, ...samples.map((s) => s.latency_ms ?? 0))
  const x = (s) => end === start ? (left + right) / 2 : left + (s.checked_at - start) / (end - start) * (right - left)
  const y = (s) => bottom - s.latency_ms / maximum * (bottom - top)
  const measured = (s) => s.status === 'online' && s.latency_ms != null
  let path = ''
  let connected = false
  for (const sample of samples) {
    if (measured(sample)) {
      path += `${connected ? 'L' : 'M'}${x(sample)},${y(sample)} `
      connected = true
    } else {
      connected = false
    }
  }

  return (
    <div className="telemetry-graph">
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={t('Ping latency over time; red markers indicate failed checks.')}>
        <line x1={left} y1={top} x2={left} y2={bottom} stroke="currentColor" />
        <line x1={left} y1={bottom} x2={right} y2={bottom} stroke="currentColor" />
        <text x={left - 8} y={top + 5} textAnchor="end">{averagePing(maximum)}</text>
        <text x={left - 8} y={bottom} textAnchor="end">0 ms</text>
        <text x={left} y={height - 12}>{fmtTime(start)}</text>
        {end !== start && <text x={right} y={height - 12} textAnchor="end">{fmtTime(end)}</text>}
        <path d={path} fill="none" stroke="#3b82f6" strokeWidth="2" />
        {samples.map((s) => (
          <circle key={s.id} cx={x(s)} cy={measured(s) ? y(s) : bottom + 8} r="3"
            fill={s.status === 'offline' ? '#ef4444' : '#3b82f6'}>
            <title>{fmtTime(s.checked_at)} · {t(s.status === 'online' ? 'Online' : 'Offline')} · {s.status === 'online' ? averagePing(s.latency_ms) : '—'}</title>
          </circle>
        ))}
      </svg>
    </div>
  )
}

export default function DeviceTelemetry({ device, revision }) {
  const [response, setResponse] = useState(null)
  const [attempt, setAttempt] = useState(0)
  const requestKey = `${device.id}:${device.last_checked}:${revision}:${attempt}`

  useEffect(() => {
    const controller = new AbortController()
    loadDeviceHistory(device.id, controller.signal)
      .then((data) => { if (!controller.signal.aborted) setResponse({ key: requestKey, data }) })
      .catch((err) => { if (!controller.signal.aborted) setResponse({ key: requestKey, error: err.message }) })
    return () => controller.abort()
  }, [device.id, requestKey])

  if (response?.key !== requestKey) return <p role="status">{t('Loading telemetry…')}</p>
  if (response.error) return <div role="alert">{response.error} <button type="button" className="button tiny secondary" onClick={() => setAttempt((n) => n + 1)}>{t('Retry')}</button></div>
  const result = response.data
  if (!result.checks) return (
    <section className="device-telemetry" aria-label={t('Telemetry for {name}', { name: device.name })}>
      <p className="muted">{t('No ping history yet. Run a status check to collect telemetry.')}</p>
      <AnnualSnapshots snapshots={result.snapshots} />
    </section>
  )
  const newestFirstSamples = [...result.samples].reverse()

  return (
    <section className="device-telemetry" aria-label={t('Telemetry for {name}', { name: device.name })}>
      <p>
        <strong>{t('Average ping (365 days)')}: {averagePing(result.avg_latency_ms)}</strong>
        {' · '}{t('Successful checks (365 days)')}: {pct1(result.online, result.checks)}%
        {' · '}{t('Failed checks')}: {result.offline} / {result.checks}
      </p>
      <p className="small muted">{t('Availability is based on observed checks, not continuous uptime. Outages run from the first failed check to the next successful check; actual times may differ.')}</p>
      <PingGraph samples={result.samples} />
      <p className="small muted">{t('Blue: successful ping. Red: failed check (not zero latency). Lines break at missing or failed measurements.')}</p>
      {result.has_more && <p className="small">{t('Showing the latest 1,000 checks. Statistics and outages cover all retained checks.')}</p>}
      <details>
        <summary>{t('Ping samples')} ({result.samples.length})</summary>
        <div className="telemetry-list">
          <table>
            <thead><tr><th>{t('Last checked')}</th><th>{t('Status')}</th><th>{t('Latency')}</th></tr></thead>
            <tbody>{newestFirstSamples.map((s) => <tr key={s.id}><td>{fmtTime(s.checked_at)}</td><td>{t(s.status === 'online' ? 'Online' : 'Offline')}</td><td>{averagePing(s.latency_ms)}</td></tr>)}</tbody>
          </table>
        </div>
      </details>
      <details>
        <summary>{t('Observed outages')} ({result.outages.length})</summary>
        <div className="telemetry-list">
          {result.outages.length ? <ul>{result.outages.map((o) => <li key={o.started_at}>{fmtTime(o.started_at)} → {o.recovered_at == null ? t('No recovery observed') : fmtTime(o.recovered_at)}</li>)}</ul> : <p>{t('No outages observed in retained checks.')}</p>}
        </div>
      </details>
      <AnnualSnapshots snapshots={result.snapshots} />
    </section>
  )
}
