import { useEffect, useRef } from 'react'
import { t } from '../i18n.js'
import { FW_BADGE, FW_LABELS, STATUS_INDEX, STATUS_LABELS } from '../format.js'

export function StatusBadge({ status, checking }) {
  if (checking) return <span className="badge pending">{t('Checking…')}</span>
  return <span className={`badge status-${STATUS_INDEX[status]}`}>{t(STATUS_LABELS[status])}</span>
}

export function FirmwareBadge({ compliance, firmware, latestFirmware, exempt = false }) {
  const status = Object.hasOwn(FW_BADGE, compliance) ? compliance : 'unknown'
  const version = String(firmware ?? '').trim() || '—'
  const latest = String(latestFirmware ?? '').trim()
  const label = exempt ? t('Exempt') : status === 'non_compliant' && latest
    ? `${t(FW_LABELS[status])} · ${t('Latest firmware')}: ${latest}`
    : t(FW_LABELS[status])
  const tooltip = exempt ? t('Exempt') : status === 'non_compliant' && latest ? `${t('Latest firmware')}: ${latest}` : t(FW_LABELS[status])
  return <span className={`badge mono ${FW_BADGE[status]}`} title={tooltip} aria-label={`${version}: ${label}`}>{version}{exempt && ` · ${t('Exempt')}`}</span>
}

/** Native <dialog> driven by the `open` prop. */
export function Modal({ open, onClose, children, label, closeOnOutside = false }) {
  const ref = useRef(null)
  useEffect(() => {
    const dialog = ref.current
    if (open && !dialog.open) dialog.showModal()
    if (!open && dialog.open) dialog.close()
  }, [open])
  useEffect(() => {
    if (!open || !closeOnOutside) return
    const dialog = ref.current
    const dismissOutside = (event) => {
      if (!dialog.open || event.button !== 0) return
      const bounds = dialog.getBoundingClientRect()
      if (event.clientX < bounds.left || event.clientX > bounds.right ||
          event.clientY < bounds.top || event.clientY > bounds.bottom) {
        dialog.close()
      }
    }
    const doc = dialog.ownerDocument
    doc.addEventListener('pointerdown', dismissOutside, true)
    return () => doc.removeEventListener('pointerdown', dismissOutside, true)
  }, [open, closeOnOutside])
  return (
    <dialog ref={ref} onClose={onClose} aria-label={label} closedby={closeOnOutside ? 'any' : undefined}>
      {open ? children : null}
    </dialog>
  )
}
