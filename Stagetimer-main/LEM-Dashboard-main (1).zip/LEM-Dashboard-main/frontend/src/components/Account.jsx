import { useState } from 'react'
import { preparePhoto } from '../photo.js'
import { t } from '../i18n.js'
import Icon from './icons.jsx'

export function PasswordChangeForm({ onSave, required = false }) {
  const [password, setPassword] = useState({ current: '', next: '', confirm: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (event) => {
    event.preventDefault()
    if (password.next !== password.confirm) {
      setError(t('The passwords don’t match.'))
      return
    }
    if (required && password.next === password.current) {
      setError(t('Choose a different password from your temporary password.'))
      return
    }
    setBusy(true)
    setError('')
    try {
      await onSave('change_password', { current: password.current, password: password.next })
      setPassword({ current: '', next: '', confirm: '' })
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form className="account-password" onSubmit={submit}>
      {required && <p className="notice">{t('You must change your temporary password before continuing.')}</p>}
      <label>{t(required ? 'Temporary password' : 'Current password')} <input type="password" autoComplete="current-password" maxLength={200} required value={password.current} onChange={(event) => setPassword((value) => ({ ...value, current: event.target.value }))} /></label>
      <label>{t('New password')} <input type="password" autoComplete="new-password" minLength={8} maxLength={200} required value={password.next} onChange={(event) => setPassword((value) => ({ ...value, next: event.target.value }))} /></label>
      <label>{t('Repeat new password')} <input type="password" autoComplete="new-password" minLength={8} maxLength={200} required value={password.confirm} onChange={(event) => setPassword((value) => ({ ...value, confirm: event.target.value }))} /></label>
      <p className="muted small">{t('Passwords must be at least 8 characters long.')}</p>
      <div className="error" role="alert">{error}</div>
      <button type="submit" className="button primary" disabled={busy}>{busy ? t('Saving…') : t('Change password')}</button>
    </form>
  )
}

export default function Account({ state, visualTheme, onThemeChange, onSave }) {
  const [photoBusy, setPhotoBusy] = useState(false)
  const [photoError, setPhotoError] = useState('')
  const user = state?.auth.user
  const role = state?.auth.role ?? 'user'
  const roleLabel = role === 'admin' ? 'Admin' : role === 'lead' ? 'Lead' : 'User'
  const profile = state?.profile
  const maxPhotoBytes = state?.config.max_photo_bytes ?? 5242880

  const uploadPhoto = async (event) => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    if (!['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(file.type)) {
      setPhotoError(t('The photo must be a JPEG, PNG, GIF or WebP image.'))
      return
    }
    setPhotoBusy(true)
    setPhotoError('')
    try {
      const image = await preparePhoto(file)
      if (image.size > maxPhotoBytes) throw new Error(t('The photo is too large.'))
      const body = new FormData()
      body.append('photo', image, 'profile.jpg')
      await onSave('upload_account_photo', body)
    } catch (error) {
      setPhotoError(error.message)
    } finally {
      setPhotoBusy(false)
    }
  }

  const deletePhoto = async () => {
    setPhotoBusy(true)
    setPhotoError('')
    try {
      await onSave('delete_account_photo')
    } catch (error) {
      setPhotoError(error.message)
    } finally {
      setPhotoBusy(false)
    }
  }

  const photoUrl = profile?.photo_version
    ? `api.php?action=account_photo&v=${encodeURIComponent(profile.photo_version)}`
    : ''

  return (
    <div className="panel account-panel">
      <h2 className="panel-title"><Icon name="user" /> {t('Account')}</h2>
      <div className="account-profile">
        {photoUrl
          ? <img className="account-avatar" src={photoUrl} alt={t('Profile photo')} />
          : <div className="account-avatar account-avatar-empty" aria-hidden="true"><Icon name="user" size={42} /></div>}
        <div className="account-profile-info">
          <strong>{user}</strong>
          <span className="muted small">{t('Signed-in account')}</span>
          <span className="muted small">{t('Role')}: {t(roleLabel)}</span>
          <div className="head-actions">
            <label className="button secondary tiny photo-pick">
              {photoBusy ? t('Uploading…') : t(photoUrl ? 'Replace photo' : 'Upload photo')}
              <input type="file" accept="image/jpeg,image/png,image/gif,image/webp" onChange={uploadPhoto} disabled={photoBusy} />
            </label>
            {photoUrl && <button type="button" className="button tiny danger" disabled={photoBusy} onClick={deletePhoto}>{t('Remove photo')}</button>}
          </div>
          <span className="muted small">{t('Maximum file size: {size} MB.', { size: (maxPhotoBytes / 1048576).toFixed(1) })}</span>
          <div className="error" role="alert">{photoError}</div>
        </div>
      </div>
      <div className="account-settings-grid">
        <section className="account-section">
          <h3><Icon name="sun" size={18} /> {t('Appearance')}</h3>
          <label className="setting account-theme">
            <span className="setting-label">{t('Theme')}</span>
            <select value={visualTheme} onChange={(event) => onThemeChange(event.target.value)}>
              <option value="main">{t('Main theme')}</option>
              <option value="teams">{t('Microsoft Teams')}</option>
              <option value="tui">{t('Terminal TUI')}</option>
              <option value="cmd">{t('Command Prompt (CMD)')}</option>
              <option value="tricaster">{t('Vizrt TriCaster')}</option>
              <option value="win98">{t('Windows 98')}</option>
              <option value="vista">{t('Windows Vista')}</option>
            </select>
            <small className="muted">{t('The main theme supports light and dark mode. Use the sun/moon button in the top bar to switch modes.')}</small>
          </label>
        </section>
        <section className="account-section">
          <h3><Icon name="shield" size={18} /> {t('Security')}</h3>
          <PasswordChangeForm onSave={onSave} />
        </section>
      </div>
    </div>
  )
}
