import { useEffect, useRef, useState } from 'react'
import { loadDiscoveryLog } from '../api.js'
import { t } from '../i18n.js'

const MAX_TEXT = 128 * 1024

export default function DiscoveryLog({ index, host, device, user, loginRevision, onLogin }) {
  // Pin once: later header refreshes must never silently select a different host.
  const [pinnedHost] = useState(() => host || device?.ip || '')
  const [server, setServer] = useState(() => ({ name: device?.ip === pinnedHost ? device.name : '', ip: pinnedHost }))
  const [paused, setPaused] = useState(false)
  const [autoScroll, setAutoScroll] = useState(true)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [authError, setAuthError] = useState(false)
  const [loading, setLoading] = useState(false)
  const retryAt = useRef(0)
  const output = useRef(null)

  useEffect(() => {
    if (!user || index < 0 || !pinnedHost || paused) return undefined
    const controller = new AbortController()
    let timer
    const poll = async () => {
      setAuthError(false)
      setLoading(true)
      try {
        const response = await loadDiscoveryLog(index, pinnedHost, controller.signal)
        if (controller.signal.aborted) return
        if (response.server?.ip !== pinnedHost || typeof response.log?.text !== 'string') {
          throw new Error(t('Invalid log response. Open the log again from the top bar.'))
        }
        const raw = response.log.text
        const lines = raw.replace(/\n$/, '').split('\n')
        const text = lines.slice(-200).join('\n').slice(-MAX_TEXT)
        setResult({ text, truncated: response.log.truncated || lines.length > 200 || text.length < raw.replace(/\n$/, '').length })
        setServer(response.server)
        setError('')
      } catch (err) {
        if (controller.signal.aborted) return
        setResult(null)
        setError(err.message)
        if (err.status === 401 || err.status === 403) {
          setAuthError(true)
          return
        }
        if (err.status === 429) {
          const seconds = Number(err.retryAfter)
          retryAt.current = Date.now() + (Number.isFinite(seconds) ? Math.max(5, seconds) : 5) * 1000
        }
      } finally {
        if (!controller.signal.aborted) setLoading(false)
      }
      if (!controller.signal.aborted) timer = setTimeout(poll, Math.max(5000, retryAt.current - Date.now()))
    }
    timer = setTimeout(() => {
      setResult(null)
      poll()
    }, Math.max(0, retryAt.current - Date.now()))
    return () => {
      clearTimeout(timer)
      controller.abort()
    }
  }, [index, pinnedHost, user, loginRevision, paused])

  useEffect(() => {
    if (autoScroll && output.current) output.current.scrollTop = output.current.scrollHeight
  }, [result, autoScroll])

  const displayError = index < 0 || !pinnedHost ? t('Discovery Server not found. Open the log again from the top bar.') : error
  const needsLogin = !user || authError

  return (
    <section className="page active">
      <div className="panel discovery-log">
        <h2 className="panel-title">{t('Discovery log')}{server.name ? ` · ${server.name}` : ''}</h2>
        <p className="mono">{server.ip}</p>
        <p className="muted">{t('Latest 200 lines. Refreshes 5 seconds after each response.')}</p>
        <div className="discovery-controls">
          <button type="button" className="button secondary" onClick={() => setPaused((value) => !value)} aria-pressed={paused}>{t(paused ? 'Resume' : 'Pause')}</button>
          <label className="discovery-check"><input type="checkbox" checked={autoScroll} onChange={(e) => setAutoScroll(e.target.checked)} /> {t('Auto-scroll')}</label>
          <span role="status">{paused ? t('Paused — log is not live.') : needsLogin ? '' : loading ? t('Loading…') : result && !displayError ? t('Live') : ''}</span>
        </div>
        {needsLogin && <div className="notice">
          <p>{t('Please log in again to view this log. If access is denied, ask an administrator to check your permissions.')}</p>
          <button type="button" className="button primary" onClick={onLogin}>{t('Log in')}</button>
        </div>}
        {displayError && <div className="error" role="alert">{displayError}<p>{t('Log unavailable. No live log is displayed.')}</p></div>}
        {result && !needsLogin && !displayError && <>
          {result.truncated && <p className="muted">{t('Output truncated to the latest lines and display limit.')}</p>}
          <pre ref={output} className="discovery-output" tabIndex={0} aria-label={t('Log output')}>{result.text || t('The log is empty.')}</pre>
        </>}
      </div>
    </section>
  )
}
