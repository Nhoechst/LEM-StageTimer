import { exportUrl } from '../api.js'
import { STATUS_LABELS, averagePing, fmtLatency, fmtTime, ipValue, isCheckable, pct1 } from '../format.js'
import { t } from '../i18n.js'
import Icon from './icons.jsx'
import ImportForm from './ImportForm.jsx'
import Kpi from './Kpi.jsx'
import { FirmwareBadge, StatusBadge } from './ui.jsx'
import { useSort } from './useSort.jsx'
import DeviceTelemetryPopup from './DeviceTelemetryPopup.jsx'
import AnnualSnapshots from './AnnualSnapshots.jsx'
import IpAddress from './IpAddress.jsx'
import EquipmentType from './EquipmentType.jsx'
import TextChip from './TextChip.jsx'

const COLUMNS = {
  status: (d) => d.status,
  name: (d) => d.name,
  ip: (d) => ipValue(d.ip),
  type: (d) => d.type,
  model: (d) => d.model,
  firmware: (d) => d.compliance,
  latency: (d) => d.latency_ms,
  last_checked: (d) => d.last_checked,
  last_online: (d) => d.last_online,
}

function DeviceCell({ label, className, children }) {
  return <td role="cell" data-label={t(label)} className={className}><div className="device-cell-value">{children}</div></td>
}

/** One site: its device list (like the SharePoint "IP Addresses – <site>" list) and import/export. */
export default function SitePage({ admin, user, summary, state, checking, busy, cooldown, deviceCooldowns = {}, now = 0, onCheck, go, onAdd, onEdit, onDelete, onImport }) {
  const rows = summary ? state.devices.filter((d) => d.site_id === summary.site.id) : []
  const [sorted, th] = useSort(rows, COLUMNS)

  if (!summary) {
    return (
      <section className="page active">
        <div className="panel"><p className="empty">{t('This location no longer exists.')} <button type="button" className="link-button" onClick={() => go('dashboard')}>{t('Back to Device Status')}</button></p></div>
      </section>
    )
  }
  const { site, counts } = summary
  const telemetry = state.telemetry?.[site.id]
  const trend = state.telemetry_trends?.[site.id]
  const checkable = rows.some(isCheckable)

  return (
    <section className="page active">
      <div className="site-head">
        <div>
          <button type="button" className="summary-link back-link" onClick={() => go('dashboard')}>← {t('Device Status')}</button>
          <h1>{site.name}{site.code && site.code !== site.name ? ` (${site.code})` : ''}</h1>
          <p className="summary-source">
            {t('Source: IP Addresses')} – {site.code || site.name}{site.subnet ? ` · ${site.subnet}` : ''}
          </p>
        </div>
        {admin && <div className="head-actions">
          <button type="button" className="button secondary location-action" title={t('Edit location')} aria-label={t('Edit location')} onClick={() => onEdit('site', site)}><Icon name="pencil" /></button>
          <button type="button" className="button danger location-action" title={t('Delete location')} aria-label={t('Delete location')} onClick={() => onDelete({ kind: 'site', id: site.id, name: site.name, extra: counts.total ? t('Its {n} device(s) will be deleted too.', { n: counts.total }) : '' }, () => go('dashboard'))}><Icon name="trash" /></button>
        </div>}
      </div>

      <div className="kpi-grid">
        <Kpi icon="monitor" tone="slate" value={counts.total} label={t('Total Devices')} />
        <Kpi icon="ethernet" tone="green" value={counts.online} label={t('Online')}
          trend={trend} trendMetric="online_devices" trendLabel={t('Online devices at their last recorded check each day (30 days, UTC); unchecked devices are excluded.')} />
        <Kpi icon="ethernetOff" tone="red" value={counts.offline} label={t('Offline')} />
        <Kpi icon="globe" tone="orange" value={counts.external} label={t('External Network')} />
        <Kpi icon="help" tone="slate" value={counts.no_status} label={t('No Status')} />
        <Kpi icon="percent" tone="green" value={`${pct1(counts.online, counts.total - counts.external)}%`} label={t('% Online')}
          trend={trend} trendMetric="online_pct" trendMaximum={100} trendFormat={(value) => `${value.toFixed(1)}%`} trendLabel={t('Daily percentage of checked devices online at their last recorded check (30 days, UTC). Unchecked devices are excluded; the current card value excludes External Network devices.')} />
        <Kpi icon="monitor" tone="blue" value={averagePing(telemetry?.avg_latency_ms)} label={t('Average ping (365 days)')}
          trend={trend} trendMetric="avg_latency_ms" trendFormat={averagePing} trendLabel={t('Daily average measured successful ping (30 days, UTC). Missing measurements remain gaps.')} />
        <Kpi icon="percent" tone="green" value={telemetry?.checks ? `${pct1(telemetry.online, telemetry.checks)}%` : '—'} label={t('Successful checks (365 days)')}
          trend={trend} trendMetric="success_pct" trendMaximum={100} trendFormat={(value) => `${value.toFixed(1)}%`} trendLabel={t('Daily successful checks as a percentage of recorded checks (30 days, UTC), not continuous uptime.')} />
      </div>

      <div className="panel summary-panel">
        <div className="section-heading">
          <h2 className="panel-title"><Icon name="monitor" /> {t('IP Addresses')} – {site.name}</h2>
          <div className="head-actions">
            {user && <button type="button" className="button secondary" disabled={busy || cooldown > 0 || !checkable} onClick={() => onCheck([site])}>
              <Icon name="refresh" size={14} /> {checking.siteIds.has(site.id) ? t('Checking…') : cooldown > 0 ? t('Check again in {n}s', { n: cooldown }) : t('Check location')}
            </button>}
            {admin && <button type="button" className="button primary with-icon" onClick={() => onAdd('device', { site_id: site.id }, { lockSite: true })}><Icon name="plus" size={16} /> {t('Add Device')}</button>}
          </div>
        </div>
        <div className="table-wrap">
          <table className="inventory-table location-device-table" role="table" aria-label={t('IP Addresses')}>
            <colgroup>
              {[8, 15, 12, 5, 13, 10, 6, 8, 8, 15].map((width, index) => <col key={index} style={{ width: `${width}%` }} />)}
            </colgroup>
            <thead role="rowgroup">
              <tr role="row">
                {th('status', t('Status'))}{th('name', t('Title'))}{th('ip', t('IP address'))}{th('type', t('Type'))}{th('model', t('Model'))}
                {th('firmware', t('Current firmware'))}{th('latency', t('Latency'))}{th('last_checked', t('Last checked'))}{th('last_online', t('Last online'))}<th scope="col" aria-label={t('Actions')} />
              </tr>
            </thead>
            <tbody role="rowgroup">
              {sorted.map((d) => {
                const deviceCooldown = Math.max(0, Math.ceil(((deviceCooldowns[d.id] ?? 0) - now) / 1000))
                return (
                  <tr key={d.id} role="row">
                  <DeviceCell label="Status"><StatusBadge status={d.status} checking={checking.deviceIds.has(d.id)} /></DeviceCell>
                  <DeviceCell label="Title"><DeviceTelemetryPopup device={d} revision={telemetry?.checks} />{d.notes && <div className="small muted">{d.notes}</div>}</DeviceCell>
                  <DeviceCell label="IP address"><IpAddress device={d} /></DeviceCell>
                  <DeviceCell label="Type"><EquipmentType type={d.type} /></DeviceCell>
                  <DeviceCell label="Model"><TextChip value={d.model} /></DeviceCell>
                  <DeviceCell label="Current firmware"><FirmwareBadge compliance={d.compliance} firmware={d.firmware} latestFirmware={d.required_firmware} exempt={d.firmware_exempt} /></DeviceCell>
                  <DeviceCell label="Latency" className="small mono">{fmtLatency(d.latency_ms)}</DeviceCell>
                  <DeviceCell label="Last checked" className="small">{fmtTime(d.last_checked)}</DeviceCell>
                  <DeviceCell label="Last online" className="small">{fmtTime(d.last_online)}</DeviceCell>
                  <DeviceCell label="Actions" className="actions">
                    {user && isCheckable(d) && <button type="button" className="button tiny secondary item-action device-check-action" title={deviceCooldown > 0 ? t('Check again in {n}s', { n: deviceCooldown }) : t('Check device')} aria-label={`${t('Check device: {name}', { name: d.name })}${deviceCooldown > 0 ? `, ${deviceCooldown}s` : ''}`}
                      disabled={busy || deviceCooldown > 0 || checking.deviceIds.has(d.id)}
                      onClick={() => onCheck([site], d.id)}><Icon name="refresh" size={16} />{deviceCooldown > 0 && <span className="small mono">{deviceCooldown}s</span>}</button>}{admin && ' '}
                    {admin && <>
                      <button type="button" className="button tiny secondary item-action" title={t('Edit')} aria-label={`${t('Edit')}: ${d.name}`} onClick={() => onEdit('device', d)}><Icon name="pencil" size={16} /></button>{' '}
                      <button type="button" className="button tiny danger item-action" title={t('Delete')} aria-label={`${t('Delete')}: ${d.name}`} onClick={() => onDelete({ kind: 'device', id: d.id, name: d.name })}><Icon name="trash" size={16} /></button>
                    </>}
                  </DeviceCell>
                  </tr>
                )
              })}
            </tbody>
          </table>
          {rows.length === 0 && (
            <p className="empty">
              {t('No devices recorded for this location yet.')}{' '}
              {admin && <button type="button" className="link-button" onClick={() => onAdd('device', { site_id: site.id }, { lockSite: true })}>{t('Add a device')}</button>}
            </p>
          )}
        </div>
        <footer>{t('Status')}: {Object.values(STATUS_LABELS).map((l) => t(l)).join(' · ')}. {t('External Network devices are not checked.')}</footer>
      </div>

      {state.telemetry_snapshots?.[site.id]?.length > 0 && (
        <AnnualSnapshots snapshots={state.telemetry_snapshots[site.id]} compact />
      )}

      {admin && <div className="panel summary-panel">
        <h2 className="panel-title"><Icon name="arrow" /> {t('Import & Export')}</h2>
        <div className="io-grid">
          <div>
            <h3>{t('Import devices into {name}', { name: site.name })}</h3>
            <p className="muted small">
              {t('Excel (.xlsx), CSV from Excel or a SharePoint list export (comma, semicolon or tab separated) or a JSON list. Every row is added to this location; devices are matched by IP address (or name). Addresses like http://10.1.2.3:8080/ are reduced to the IP.')}
            </p>
            <ImportForm type="devices" siteId={site.id} config={state.config} aliases={state.aliases.devices} onImport={onImport} />
          </div>
          <div>
            <h3>{t('Export')}</h3>
            <p className="muted small">{t('CSV opens in Excel and can be edited and imported again.')}</p>
            <div className="head-actions" style={{ flexWrap: 'wrap' }}>
              <a className="button primary" href={exportUrl('devices', site.id)}>{t('{name} devices (CSV)', { name: site.name })}</a>
              <a className="button secondary" href={exportUrl('devices')}>{t('All devices (CSV)')}</a>
            </div>
          </div>
        </div>
      </div>}
    </section>
  )
}
