import { fmtTime, isCheckable, pct1 } from '../format.js'
import { t } from '../i18n.js'
import DanteLogo from './DanteLogo.jsx'
import Icon from './icons.jsx'
import Kpi from './Kpi.jsx'
import DeviceTelemetryPopup from './DeviceTelemetryPopup.jsx'
import IpAddress from './IpAddress.jsx'
import NetworkDeviceList from './NetworkDeviceList.jsx'
import SiteCard from './SiteCard.jsx'
import { FirmwareBadge, StatusBadge } from './ui.jsx'

const RANK = { offline: 0, stale: 1, unknown: 2, external: 3, online: 4 }

function statusBar(devices, siteId) {
  return devices.reduce((counts, device) => {
    if (device.site_id !== siteId || device.status === 'external' || device.dante) return counts
    counts.total++
    if (device.status === 'online') counts.online++
    if (device.status === 'offline') counts.offline++
    return counts
  }, { total: 0, online: 0, offline: 0 })
}

export default function Dashboard({ admin, user, state, siteSummaries, total, checking, checkingAll, busy, cooldown, onCheck, go, onAdd, onLogin }) {
  const { devices } = state
  const attention = devices
    .filter((d) => !d.dante && (d.status === 'offline' || d.status === 'stale' || d.status === 'unknown'))
    .sort((a, b) => RANK[a.status] - RANK[b.status] || a.site.localeCompare(b.site) || a.name.localeCompare(b.name))
  const siteNames = new Map(siteSummaries.map(({ site }) => [site.id, site.name]))
  const byLocationAndName = (a, b) => (siteNames.get(a.site_id) || a.site).localeCompare(siteNames.get(b.site_id) || b.site) || a.name.localeCompare(b.name)
  const external = devices.filter((d) => d.status === 'external').sort(byLocationAndName)
  const dante = devices.filter((d) => d.dante).sort(byLocationAndName)
  const danteCount = dante.length
  const checkLabel = checkingAll ? t('Checking…') : cooldown > 0 ? t('Check again in {n}s', { n: cooldown }) : t('Check all locations')

  return (
    <section className="page active">
      <div className="kpi-grid">
        <Kpi icon="monitor" tone="slate" value={total.total} label={t('Total Devices')} />
        <Kpi icon="ethernet" tone="green" value={total.online} label={t('Online')} />
        <Kpi icon="ethernetOff" tone="red" value={total.offline} label={t('Offline')} />
        <Kpi icon="globe" tone="orange" value={total.external} label={t('External Network')} />
        <Kpi icon="help" tone="slate" value={total.no_status} label={t('No Status')} title={t('Never checked, or last check older than the stale limit')} />
        <Kpi icon="percent" tone="green" value={`${pct1(total.online, total.total - total.external)}%`} label={t('% Online')} />
      </div>

      <div className="panel summary-panel">
        <div className="section-heading">
          <h2 className="panel-title"><Icon name="pin" /> {t('Location Summary')}</h2>
          <div className="head-actions">
            {user && <button type="button" className="button secondary icon-only" disabled={busy || cooldown > 0 || !devices.some((d) => d.ownership !== 'standalone' && isCheckable(d))}
              onClick={() => onCheck(state.sites)} title={checkLabel} aria-label={checkLabel}>
              <Icon name="refresh" />
            </button>}
            {admin && <button type="button" className="button primary icon-only" title={t('Add Location')} aria-label={t('Add Location')} onClick={() => onAdd('site')}><Icon name="plus" /></button>}
          </div>
        </div>
        {siteSummaries.length === 0 ? (
          <p className="empty">
            {t('No locations yet.')}{' '}
            {admin ? (
              <><button type="button" className="link-button" onClick={() => onAdd('site')}>{t('Add a location')}</button>{t(', then add or import its devices on the location’s page.')}</>
            ) : t('Log in to add locations.')}
          </p>
        ) : (
          <div className="summary-grid">
            {siteSummaries.map(({ site, counts }) => (
              <SiteCard
                key={site.id}
                site={site}
                percent={pct1(counts.online, counts.total - counts.external)}
                stats={[[t('Total'), counts.total], [t('Online'), counts.online], [t('Offline'), counts.offline], [t('External'), counts.external], [t('No Status'), counts.no_status]]}
                bar={statusBar(devices, site.id)}
                empty={counts.total === 0 ? t('No devices recorded for this location yet.') : null}
                canOpen={Boolean(user)}
                onOpen={() => go(`location/${site.id}`)}
                action={user && counts.total > counts.external && (
                  <button type="button" className="summary-check" disabled={busy || cooldown > 0} onClick={() => onCheck([site])}>
                    <Icon name="refresh" size={14} /> {checking.siteIds.has(site.id) ? t('Checking…') : cooldown > 0 ? `${cooldown}s` : t('Check')}
                  </button>
                )}
              />
            ))}
          </div>
        )}
      </div>

      {!user && (
        <div className="panel summary-panel additional-stats">
          <button type="button" className="additional-stats-login" onClick={onLogin}>{t('Login for Additional Stats')}</button>
        </div>
      )}

      {user && (
        <>
          <div className="network-row">
            <div className="panel summary-panel network-panel">
              <div className="section-heading">
                <h2 className="panel-title"><Icon name="globe" /> {t('External Network')}</h2>
                <span className="count-pill tone-orange">{t(total.external === 1 ? '{n} device' : '{n} devices', { n: total.external })}</span>
              </div>
              {external.length === 0 ? (
                <p className="empty">{t('No devices are on the external network. Devices with a 192.x.x.x address, or with the status External Network, are listed here.')}</p>
              ) : (
                <NetworkDeviceList devices={external} siteNames={siteNames} label={t('External Network')} go={go} />
              )}
            </div>
            <div className="panel summary-panel network-panel dante-panel">
              <div className="section-heading dante-heading">
                <h2 className="panel-title" aria-label={t('Dante Network')}><DanteLogo /></h2>
                <div className="dante-heading-actions">
                  {admin && <button type="button" className="button primary icon-only dante-add" title={t('Add Dante device')} aria-label={t('Add Dante device')} onClick={() => onAdd('dante')}><Icon name="plus" /></button>}
                  <span className="count-pill tone-dante">{t(danteCount === 1 ? '{n} device' : '{n} devices', { n: danteCount })}</span>
                </div>
              </div>
              {dante.length === 0 ? (
                <p className="empty">{t('No Dante devices yet. Devices whose Type contains “Dante” are listed here, regardless of IP address.')}</p>
              ) : (
                <NetworkDeviceList devices={dante} siteNames={siteNames} label={t('Dante Network')} go={go} showNotes />
              )}
            </div>
          </div>

          <div className="panel summary-panel">
            <h2 className="panel-title"><Icon name="alert" /> {t('Needs attention')}</h2>
            {attention.length === 0 ? (
              <p className="empty">{devices.length === 0 ? t('No devices yet.') : t('All checked devices are online.')}</p>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>{t('Status')}</th><th>{t('Device')}</th><th>{t('IP address')}</th><th>{t('Location')}</th><th>{t('Firmware')}</th><th>{t('Last checked')}</th></tr></thead>
                  <tbody>
                    {attention.map((d) => (
                      <tr key={d.id}>
                        <td><StatusBadge status={d.status} checking={checking.deviceIds.has(d.id)} /></td>
                        <td><DeviceTelemetryPopup device={d} /></td>
                        <td><IpAddress device={d} /></td>
                        <td>{d.site}</td>
                        <td><FirmwareBadge compliance={d.compliance} firmware={d.firmware} latestFirmware={d.required_firmware} exempt={d.firmware_exempt} /></td>
                        <td className="small">{fmtTime(d.last_checked)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </section>
  )
}
