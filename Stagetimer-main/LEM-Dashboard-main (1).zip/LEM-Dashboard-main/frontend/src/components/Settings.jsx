import { useEffect, useState } from 'react'
import { exportUrl, loadTrafficUsage } from '../api.js'
import { fmtTime } from '../format.js'
import { t, teamName } from '../i18n.js'
import Icon from './icons.jsx'
import Account from './Account.jsx'
import ImportForm from './ImportForm.jsx'
import { FirmwareManagement } from './Firmware.jsx'

// Settings navigation groups: [group label, [[key, section label, icon]]]
const SECTION_GROUPS = [
  ['Dashboard', [
    ['general', 'General', 'gear'],
    ['teams', 'Country', 'globe'],
  ]],
  ['Operations', [
    ['header', 'Discovery Servers', 'wifi'],
    ['monitoring', 'Monitoring', 'monitor'],
    ['limits', 'Flood Protection', 'alert'],
    ['traffic', 'Traffic', 'chart'],
  ]],
  ['Notifications', [
    ['email', 'Email', 'mail'],
  ]],
  ['Access', [
    ['user', 'Account', 'user'],
    ['users', 'Users', 'user'],
  ]],
  ['Data', [
    ['backup', 'Backup', 'shield'],
    ['firmware', 'Firmware', 'chip'],
    ['pc-import-export', 'PC Maintenance', 'monitor'],
  ]],
]
const SECTIONS = SECTION_GROUPS.flatMap(([, sections]) => sections)
const SECTION_KEYS = SECTIONS.map(([key]) => key)
const ROLE_SECTIONS = {
  admin: SECTION_KEYS,
  lead: SECTION_KEYS.filter((key) => key !== 'traffic'),
  user: ['user', 'firmware'],
}
// Older links to sections now inside "Monitoring".
const MOVED = { status: 'monitoring', maintenance: 'monitoring', checks: 'monitoring' }

// Lists edited as one comma separated text field.
const LISTS = ['online_values', 'corporate_networks', 'external_networks', 'check_schedule']
const DAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']]
const RATE_LABELS = { api: 'All requests', write: 'Changes and uploads', ping: 'Ping API (/ping)', login: 'Login attempts' }

let timeZones = []
try {
  timeZones = Intl.supportedValuesOf('timeZone')
} catch {
  // older browser: keep common time zones selectable
  timeZones = ['America/Los_Angeles', 'America/New_York', 'Europe/Berlin', 'Europe/London', 'Asia/Tokyo']
}
timeZones = ['UTC', ...timeZones]

function timeZoneOptions(value) {
  return [...new Set([...timeZones, value].filter(Boolean))].sort((a, b) => a === 'UTC' ? -1 : b === 'UTC' ? 1 : a.localeCompare(b))
}

export function TimeZoneSelect({ value, onChange, disabled = false, allowGeneral = false, 'aria-label': ariaLabel }) {
  return (
    <select value={value} required={!allowGeneral} disabled={disabled} aria-label={ariaLabel} onChange={onChange}>
      {allowGeneral && <option value="">{t('Use general time zone')}</option>}
      {timeZoneOptions(value).map((zone) => <option key={zone} value={zone}>{zone}</option>)}
    </select>
  )
}

function toForm(settings) {
  const form = structuredClone(settings)
  for (const key of LISTS) form[key] = settings[key].join(', ')
  form.ping.tcp_ports = settings.ping.tcp_ports.join(', ')
  form.email.times = settings.email.times.join(', ')
  form.email.smtp_password = ''
  form.header_devices = form.header_devices.map((device) => ({
    log_enabled: false, ssh_user: '', ssh_port: 22, ssh_key: '', log_path: '', ...device,
    log_source: device.log_source ?? (device.log_path ? 'file' : 'journal'),
    log_service: device.log_service ?? 'ndi-discovery.service',
    ssh_auth: device.ssh_auth ?? (device.ssh_key ? 'key' : 'password'),
    has_ssh_password: device.has_ssh_password ?? false, ssh_password: '',
  }))
  return form
}

/** One Settings section; only the selected one is shown. */
function Panel({ id, section, title, icon: ownIcon, children }) {
  if (id !== section) return null
  const [, sectionLabel, sectionIcon] = SECTIONS.find(([key]) => key === id)
  const label = title ?? sectionLabel
  const icon = ownIcon ?? sectionIcon
  return (
    <div className="panel">
      <h2 className="panel-title"><Icon name={icon} /> {t(label)}</h2>
      {children}
    </div>
  )
}

/** One setting: label, input and an optional hint. */
function Setting({ label, hint, children }) {
  return (
    <label className="setting">
      <span className="setting-label">{t(label)}</span>
      {children}
      {hint && <small className="muted">{t(hint)}</small>}
    </label>
  )
}

/**
 * Admin backend: everything that used to be in config/config.php, plus the
 * user accounts. Only shown to signed-in users (the server checks it too).
 */
export default function Settings({ state, section: wanted, go, onSave, onLogin, visualTheme, onThemeChange, onAdd, onEdit, onDelete, onImport, team }) {
  const role = state.auth.role ?? 'user'
  const allowed = state.auth.user ? (ROLE_SECTIONS[role] ?? ROLE_SECTIONS.user) : ['user']
  const resolved = wanted === 'account' ? 'user' : SECTION_KEYS.includes(wanted) ? wanted : MOVED[wanted] ?? allowed[0]
  const section = allowed.includes(resolved) ? resolved : allowed[0]
  if (!state.auth.user) {
    return (
      <section className="page active">
        <div className="panel">
          <h2 className="panel-title"><Icon name="gear" /> {t('Settings')}</h2>
          <p>{t('Please log in to change the settings.')}</p>
          <button type="button" className="button primary" onClick={onLogin}>{t(state.auth.setup ? 'Create administrator account' : 'Log in')}</button>
        </div>
      </section>
    )
  }
  return (
    <section className="page active settings-layout">
      <nav className="settings-nav" aria-label={t('Settings')}>
        <h2>{t('Settings')}</h2>
        {SECTION_GROUPS.map(([group, sections]) => (
          sections.filter(([key]) => allowed.includes(key)).length > 0 && (
          <div className="settings-nav-group" key={group}>
            <h3>{t(group)}</h3>
            {sections.filter(([key]) => allowed.includes(key)).map(([key, label, icon]) => (
              <button key={key} type="button" className={key === section ? 'active' : ''} aria-current={key === section ? 'page' : undefined} onClick={() => go(`settings/${key}`)}>
                <Icon name={icon} size={18} /> <span>{t(label)}</span>
              </button>
            ))}
          </div>
          )
        ))}
      </nav>
      <div className="settings-content">
        {/* Stays mounted while Users is open so unsaved changes aren't lost. */}
        {role !== 'user' && !['backup', 'firmware', 'pc-import-export', 'traffic'].includes(section) && <SettingsForm key={JSON.stringify(state.settings)} settings={state.settings} emailStatus={state.email} section={section} role={role} onSave={onSave} />}
        {section === 'traffic' && role === 'admin' && <TrafficPanel />}
        {section === 'user' && <Account state={state} visualTheme={visualTheme} onThemeChange={onThemeChange} onSave={onSave} />}
        {section === 'users' && <Users users={state.users} me={state.auth.user} role={role} onSave={onSave} />}
        {section === 'backup' && <BackupPanel config={state.config} onImport={onImport} />}
        {section === 'firmware' && <FirmwareManagement state={state} admin={role !== 'user'} onAdd={onAdd} onEdit={onEdit} onDelete={onDelete} onImport={onImport} onSave={onSave} />}
        {section === 'pc-import-export' && <PcImportExport state={state} team={team} onImport={onImport} />}
      </div>
    </section>
  )
}

function PcImportExport({ state, team, onImport }) {
  return (
    <div className="panel summary-panel">
      <h2 className="panel-title"><Icon name="arrow" /> {t('Import & Export')}</h2>
      <div className="io-grid">
        <div>
          <h3>{t('Import PCs')}</h3>
          <p className="muted small">
            {t('Excel (.xlsx), CSV or a SharePoint list export with columns such as PC Name, Type, IP Address, Operating System, Location, Last Checked, Checked By and Comments. PCs are matched by name and added to the selected team.')}
          </p>
          <ImportForm type="pcs" team={team} config={state.config} aliases={state.aliases.pcs} onImport={onImport} />
        </div>
        <div>
          <h3>{t('Export')}</h3>
          <p className="muted small">{t('CSV opens in Excel and can be edited and imported again.')}</p>
          <a className="button primary" href={exportUrl('pcs')}>{t('All PCs (CSV)')}</a>
        </div>
      </div>
    </div>
  )
}

function BackupPanel({ config, onImport }) {
  return (
    <div className="panel">
      <h2 className="panel-title"><Icon name="shield" /> {t('Backup')}</h2>
      <div className="io-grid">
        <div>
          <p className="muted small">{t('Everything (locations of all teams, devices, latest firmware) is stored on this server in')} <span className="mono">{config.data_file}</span>.</p>
          <a className="button primary" href={exportUrl('backup')}>{t('Download full backup (JSON)')}</a>
        </div>
        <div>
          <p className="muted small">{t('Restoring a backup replaces all current data (all teams).')}</p>
          <ImportForm type="backup" config={config} onImport={onImport} />
        </div>
      </div>
    </div>
  )
}

function SettingsForm({ settings, emailStatus, section, role, onSave }) {
  const [form, setForm] = useState(() => toForm(settings))
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }))
  const setIn = (group, key, value) => setForm((f) => ({ ...f, [group]: { ...f[group], [key]: value } }))
  const setRow = (list, i, key, value) => setForm((f) => ({ ...f, [list]: f[list].map((r, j) => (j === i ? { ...r, [key]: value } : r)) }))
  const addRow = (list, row) => setForm((f) => ({ ...f, [list]: [...f[list], row] }))
  const removeRow = (list, i) => setForm((f) => ({ ...f, [list]: f[list].filter((_, j) => j !== i) }))
  const setEmail = (key, value) => setForm((f) => ({ ...f, email: { ...f.email, [key]: value } }))
  const setEmailIn = (group, team, value) => setForm((f) => ({ ...f, email: { ...f.email, [group]: { ...f.email[group], [team]: value } } }))
  const setLimit = (bucket, i, value) =>
    setForm((f) => ({ ...f, rate_limits: { ...f.rate_limits, [bucket]: f.rate_limits[bucket].map((v, j) => (j === i ? value : v)) } }))
  const readOnlySection = role === 'lead' && ['general', 'teams'].includes(section)

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      const result = await onSave('save_settings', form)
      setForm(toForm(result.state.settings))
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  const num = (value, onChange, props = {}) => <input type="number" value={value} onChange={(e) => onChange(e.target.value)} required {...props} />

  return (
    <form className="settings" onSubmit={submit} hidden={section === 'users' || section === 'user'}>
      {readOnlySection && <p className="notice">{t('Leads can view General and Country settings but cannot edit them.')}</p>}

      <Panel id="general" section={section}>
        <div className="settings-grid">
          <Setting label="Title"><input value={form.app_title} maxLength={100} required readOnly={readOnlySection} className={readOnlySection ? 'readonly' : undefined} onChange={(e) => set('app_title', e.target.value)} /></Setting>
          <Setting label="Subtitle"><input value={form.app_subtitle} maxLength={200} readOnly={readOnlySection} className={readOnlySection ? 'readonly' : undefined} onChange={(e) => set('app_subtitle', e.target.value)} /></Setting>
          <Setting label="Time zone" hint="Used for dates when a country has no time zone of its own.">
            <TimeZoneSelect value={form.timezone} disabled={readOnlySection} onChange={(e) => set('timezone', e.target.value)} />
          </Setting>
        </div>
      </Panel>

      <Panel id="teams" section={section}>
        <p className="muted small">{t('The country selector in the top bar. Automatic checks run at the check times in each country’s time zone.')}</p>
        <table className="settings-rows">
          <thead><tr><th>{t('Code')}</th><th>{t('Name')}</th><th>{t('Time zone')}</th><th /></tr></thead>
          <tbody>
            {form.teams.map((tm, i) => (
              <tr key={i}>
                <td><input value={tm.key} maxLength={10} required readOnly={readOnlySection} className={readOnlySection ? 'readonly' : undefined} aria-label={t('Code')} onChange={(e) => setRow('teams', i, 'key', e.target.value)} /></td>
                <td><input value={tm.name} maxLength={60} required readOnly={readOnlySection} className={readOnlySection ? 'readonly' : undefined} aria-label={t('Name')} onChange={(e) => setRow('teams', i, 'name', e.target.value)} /></td>
                <td>
                  <TimeZoneSelect value={tm.timezone} allowGeneral disabled={readOnlySection} aria-label={t('Time zone')} onChange={(e) => setRow('teams', i, 'timezone', e.target.value)} />
                </td>
                <td>{!readOnlySection && <button type="button" className="button tiny secondary" disabled={form.teams.length < 2} onClick={() => removeRow('teams', i)}>{t('Remove')}</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {!readOnlySection && <button type="button" className="button secondary with-icon" onClick={() => addRow('teams', { key: '', name: '', timezone: '' })}><Icon name="plus" size={16} /> {t('Add country')}</button>}
      </Panel>

      <Panel id="header" section={section}>
        <p className="muted small">{t('Crucial equipment whose status is always shown in the top bar (e.g. Discovery Server).')}</p>
        {form.header_devices.map((d, i) => (
          <fieldset className="discovery-settings" key={i}>
            <legend>{t('Discovery Server {n}', { n: i + 1 })}</legend>
            <div className="settings-grid">
              <Setting label="Name"><input value={d.name} maxLength={60} required onChange={(e) => setRow('header_devices', i, 'name', e.target.value)} /></Setting>
              <Setting label="IP address"><input value={d.ip} maxLength={253} required className="mono" onChange={(e) => setRow('header_devices', i, 'ip', e.target.value)} /></Setting>
            </div>
            <label className="discovery-check"><input type="checkbox" checked={d.log_enabled} onChange={(e) => setRow('header_devices', i, 'log_enabled', e.target.checked)} /> {t('Enable log viewer')}</label>
            <div className="settings-grid">
              <Setting label="SSH user"><input value={d.ssh_user} required={d.log_enabled} autoComplete="off" onChange={(e) => setRow('header_devices', i, 'ssh_user', e.target.value)} /></Setting>
              <Setting label="SSH port">{num(d.ssh_port, (v) => setRow('header_devices', i, 'ssh_port', Number(v)), { min: 1, max: 65535 })}</Setting>
              <Setting label="SSH authentication">
                <select value={d.ssh_auth} onChange={(e) => setRow('header_devices', i, 'ssh_auth', e.target.value)}>
                  <option value="password">{t('Password')}</option>
                  <option value="key">{t('SSH key')}</option>
                </select>
              </Setting>
              {d.ssh_auth === 'password' && <Setting label="SSH password" hint="Leave blank to keep the existing password if the host, SSH user and port are unchanged. Re-enter the password after changing any of them."><input type="password" value={d.ssh_password} autoComplete="new-password" maxLength={1024} required={d.log_enabled && !d.has_ssh_password} onChange={(e) => setRow('header_devices', i, 'ssh_password', e.target.value)} /></Setting>}
              {d.ssh_auth === 'key' && <Setting label="SSH key filename" hint="Filename only, provisioned on the dashboard server in data/ssh. No private key uploads."><input value={d.ssh_key} required={d.log_enabled} pattern={String.raw`[^\/\\]+`} autoComplete="off" onChange={(e) => setRow('header_devices', i, 'ssh_key', e.target.value)} /></Setting>}
              <Setting label="Log source">
                <select value={d.log_source} onChange={(e) => setRow('header_devices', i, 'log_source', e.target.value)}>
                  <option value="journal">{t('Systemd service journal')}</option>
                  <option value="file">{t('Log file')}</option>
                </select>
              </Setting>
              {d.log_source === 'journal'
                ? <Setting label="Systemd service" hint="Current boot, latest 200 messages. The SSH user must have permission to read this service journal."><input value={d.log_service} required={d.log_enabled} maxLength={255} pattern={String.raw`[a-zA-Z0-9_][a-zA-Z0-9_.@:\-]*\.service`} className="mono" placeholder="ndi-discovery.service" onChange={(e) => setRow('header_devices', i, 'log_service', e.target.value)} /></Setting>
                : <Setting label="Log file path" hint="Absolute Linux path to the remote log file."><input value={d.log_path} required={d.log_enabled} pattern="/.*" className="mono" placeholder="/var/log/discovery.log" onChange={(e) => setRow('header_devices', i, 'log_path', e.target.value)} /></Setting>}
            </div>
            <p className="muted small">{t('Password login requires openssh-client and sshpass on the dashboard server. Verify the remote host key and provision data/ssh/known_hosts; host key verification must not be disabled.')}</p>
            <button type="button" className="button tiny danger item-action" title={t('Delete')}
              aria-label={`${t('Delete')}: ${d.name || t('Discovery Server {n}', { n: i + 1 })}`}
              onClick={() => {
                if (window.confirm(t('Delete discovery server "{name}"? This removes it from the settings form. Click Save settings to apply the deletion.', { name: d.name || t('Discovery Server {n}', { n: i + 1 }) }))) {
                  removeRow('header_devices', i)
                }
              }}><Icon name="trash" size={16} /></button>
          </fieldset>
        ))}
        <div className="settings-inline">
          <button type="button" className="button secondary with-icon" disabled={form.header_devices.length >= 10} onClick={() => addRow('header_devices', { name: '', ip: '', log_enabled: false, ssh_user: '', ssh_port: 22, ssh_auth: 'password', has_ssh_password: false, ssh_password: '', ssh_key: '', log_path: '', log_source: 'journal', log_service: 'ndi-discovery.service' })}><Icon name="plus" size={16} /> {t('Add Discovery Server')}</button>
          <Setting label="Refresh every (seconds)">{num(form.header_check_seconds, (v) => set('header_check_seconds', v), { min: 30, max: 3600 })}</Setting>
        </div>
      </Panel>

      <Panel id="monitoring" section={section} title="Status and networks" icon="monitor">
        <div className="settings-grid">
          <Setting label="Online status values" hint="Comma separated, e.g. online, up, reachable."><input value={form.online_values} required onChange={(e) => set('online_values', e.target.value)} /></Setting>
          <Setting label="Stale after (hours)" hint="0 = never.">{num(form.stale_after_hours, (v) => set('stale_after_hours', v), { min: 0, max: 8760, step: 'any' })}</Setting>
          <Setting label="Corporate network" hint="IP addresses outside these networks are shown as External Network and never pinged. Usually 10.0.0.0/8 (10.*.*.*). Comma separated; empty = not used."><input value={form.corporate_networks} className="mono" placeholder="10.0.0.0/8" onChange={(e) => set('corporate_networks', e.target.value)} /></Setting>
          <Setting label="External networks" hint="Devices with an IP address in these networks are shown as External Network and never pinged. Comma separated, e.g. 192.0.0.0/8."><input value={form.external_networks} className="mono" onChange={(e) => set('external_networks', e.target.value)} /></Setting>
        </div>
      </Panel>

      <Panel id="monitoring" section={section} title="PC maintenance and firmware" icon="shield">
        <div className="settings-grid">
          <Setting label="Maintenance interval (days)" hint="A PC is Checked when its last check is within this many days.">{num(form.maintenance_interval_days, (v) => set('maintenance_interval_days', v), { min: 1, max: 3650 })}</Setting>
          <Setting label="Firmware compliance">
            <select value={form.firmware_mode} onChange={(e) => set('firmware_mode', e.target.value)}>
              <option value="minimum">{t('Current firmware is the latest or newer')}</option>
              <option value="exact">{t('Current firmware is exactly the latest')}</option>
            </select>
          </Setting>
        </div>
      </Panel>

      <Panel id="monitoring" section={section} title="Checks" icon="refresh">
        <div className="settings-grid">
          <Setting label="Automatic check times" hint="HH:MM in each country’s time zone, comma separated."><input value={form.check_schedule} className="mono" required onChange={(e) => set('check_schedule', e.target.value)} /></Setting>
          <Setting label="Check window (minutes)" hint="How long after a check time the check may still start.">{num(form.check_window_minutes, (v) => set('check_window_minutes', v), { min: 1, max: 720 })}</Setting>
          <Setting label="Manual check cooldown (seconds)">{num(form.manual_check_cooldown_seconds, (v) => set('manual_check_cooldown_seconds', v), { min: 0, max: 86400 })}</Setting>
          <Setting label="Ping method">
            <select value={form.ping.method} onChange={(e) => setIn('ping', 'method', e.target.value)}>
              <option value="auto">{t('Automatic (ICMP, TCP, then OSC)')}</option>
              <option value="icmp">ICMP</option>
              <option value="tcp">TCP</option>
            </select>
          </Setting>
          <Setting label="Ping timeout (seconds)">{num(form.ping.timeout_seconds, (v) => setIn('ping', 'timeout_seconds', v), { min: 1, max: 30 })}</Setting>
          <Setting label="Pings per check">{num(form.ping.count, (v) => setIn('ping', 'count', v), { min: 1, max: 10 })}</Setting>
          <Setting label="Parallel pings">{num(form.ping.parallel, (v) => setIn('ping', 'parallel', v), { min: 1, max: 256 })}</Setting>
          <Setting label="TCP ports" hint="Used when ICMP isn’t available."><input value={form.ping.tcp_ports} className="mono" required onChange={(e) => setIn('ping', 'tcp_ports', e.target.value)} /></Setting>
          <Setting label="Ping API (/ping?ip=…)">
            <select value={form.ping_api ? '1' : '0'} onChange={(e) => set('ping_api', e.target.value === '1')}>
              <option value="1">{t('On')}</option>
              <option value="0">{t('Off')}</option>
            </select>
          </Setting>
        </div>
      </Panel>
      <Panel id="limits" section={section}>
        <p className="muted small">{t('Requests allowed per client within the time window. 0 turns a limit off (not possible for logins).')}</p>
        <table className="settings-rows">
          <thead><tr><th>{t('Limit')}</th><th>{t('Requests')}</th><th>{t('Window (seconds)')}</th></tr></thead>
          <tbody>
            {Object.keys(RATE_LABELS).map((bucket) => (
              <tr key={bucket}>
                <td>{t(RATE_LABELS[bucket])}</td>
                <td>{num(form.rate_limits[bucket][0], (v) => setLimit(bucket, 0, v), { min: 0, max: 100000, 'aria-label': t('Requests') })}</td>
                <td>{num(form.rate_limits[bucket][1], (v) => setLimit(bucket, 1, v), { min: 0, max: 86400, 'aria-label': t('Window (seconds)') })}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="settings-grid">
          <Setting label="Largest import file (MB)">{num(form.max_import_mb, (v) => set('max_import_mb', v), { min: 0.1, max: 100, step: 0.1 })}</Setting>
          <Setting label="Largest photo (MB)">{num(form.max_photo_mb, (v) => set('max_photo_mb', v), { min: 0.1, max: 50, step: 0.1 })}</Setting>
        </div>
      </Panel>

      {section === 'email' && (
        <EmailSettings form={form} saved={toForm(settings)} status={emailStatus} setEmail={setEmail} setEmailIn={setEmailIn} onSave={onSave} />
      )}

      {!readOnlySection && <div className="settings-save">
        <span className="error" role="alert">{error}</span>
        <button type="button" className="button secondary" onClick={() => setForm(toForm(settings))}>{t('Reset')}</button>
        <button type="submit" className="button primary" disabled={busy}>{busy ? t('Saving…') : t('Save settings')}</button>
      </div>}
    </form>
  )
}

function TrafficPanel() {
  const [usage, setUsage] = useState(null)
  const [error, setError] = useState('')
  const [refresh, setRefresh] = useState(0)
  const [period, setPeriod] = useState(24)

  useEffect(() => {
    const controller = new AbortController()
    const update = () => loadTrafficUsage(controller.signal)
      .then((data) => { setUsage(data); setError('') })
      .catch((err) => { if (!controller.signal.aborted) setError(err.message) })
    update()
    const timer = setInterval(update, 60000)
    return () => {
      controller.abort()
      clearInterval(timer)
    }
  }, [refresh])

  const bytes = (value) => {
    if (!value) return '0 B'
    const units = ['B', 'KB', 'MB', 'GB']
    const unit = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1)
    return `${(value / 1024 ** unit).toLocaleString(undefined, { maximumFractionDigits: 1 })} ${units[unit]}`
  }
  const hours = usage?.hours.slice(-period) ?? []
  const max = Math.max(1, ...hours.flatMap((hour) => [
    hour.request_bytes + hour.ping_received_bytes,
    hour.response_bytes + hour.ping_sent_bytes,
  ]))
  const point = (hour, index, key) => {
    const x = hours.length < 2 ? 450 : 20 + index * 860 / (hours.length - 1)
    const bytes = key === 'in'
      ? hour.request_bytes + hour.ping_received_bytes
      : hour.response_bytes + hour.ping_sent_bytes
    return `${x},${210 - bytes / max * 180}`
  }

  return (
    <div className="panel">
      <h2 className="panel-title"><Icon name="chart" /> {t('Traffic')}</h2>
      <p className="muted small">{t('Includes HTTP requests handled by PHP and estimated status-check probes. Static files served directly by the web server and other server traffic are not included; exact total traffic requires web-server or network-interface logs. HTTP byte counts exclude network protocol overhead; ping sizes are estimates.')}</p>
      {error && <p className="error" role="alert">{error}</p>}
      {!usage && !error && <p className="muted">{t('Loading traffic usage…')}</p>}
      {usage && (
        <>
          <div className="settings-inline">
            <label className="setting"><span className="setting-label">{t('Graph period')}</span>
              <select value={period} onChange={(event) => setPeriod(Number(event.target.value))}>
                <option value={24}>{t('Last 24 hours')}</option>
                <option value={168}>{t('Last 7 days')}</option>
              </select>
            </label>
            <span className="small"><span style={{ color: '#3b82f6' }}>●</span> {t('Incoming')}　<span style={{ color: '#f97316' }}>●</span> {t('Outgoing')}</span>
          </div>
          <div className="telemetry-graph">
            <svg viewBox="0 0 900 240" role="img" aria-label={t('Incoming and outgoing traffic by hour')}>
              <line x1="20" y1="210" x2="880" y2="210" stroke="currentColor" />
              <text x="20" y="20">{bytes(max)} / {t('hour')}</text>
              {hours.length > 0 && <>
                <polyline points={hours.map((hour, index) => point(hour, index, 'in')).join(' ')} fill="none" stroke="#3b82f6" strokeWidth="2" />
                <polyline points={hours.map((hour, index) => point(hour, index, 'out')).join(' ')} fill="none" stroke="#f97316" strokeWidth="2" />
                <text x="20" y="232">{fmtTime(hours[0].hour)}</text>
                {hours.length > 1 && <text x="880" y="232" textAnchor="end">{fmtTime(hours[hours.length - 1].hour)}</text>}
              </>}
            </svg>
          </div>
          <table className="settings-rows">
            <thead><tr><th>{t('Period')}</th><th>{t('HTTP requests')}</th><th>{t('Ping targets')}</th><th>{t('Incoming')}</th><th>{t('Outgoing')}</th></tr></thead>
            <tbody>{[['24h', 'Last 24 hours'], ['7d', 'Last 7 days']].map(([key, label]) => (
              <tr key={key}><th scope="row">{t(label)}</th><td>{usage.totals[key].requests.toLocaleString()}</td><td>{usage.totals[key].ping_hosts.toLocaleString()}</td><td>{bytes(usage.totals[key].in_bytes)}</td><td>{bytes(usage.totals[key].out_bytes)}</td></tr>
            ))}</tbody>
          </table>
          <button type="button" className="button tiny secondary" onClick={() => setRefresh((value) => value + 1)}>{t('Refresh traffic')}</button>
        </>
      )}
    </div>
  )
}

/**
 * Settings → Email: outage notification schedule, sending (PHP mail() or SMTP) and a
 * distribution list per country. "Send now" and the test email use the saved settings.
 */
function EmailSettings({ form, saved, status, setEmail, setEmailIn, onSave }) {
  const email = form.email
  const [adding, setAdding] = useState({})
  const [testTo, setTestTo] = useState('')
  const [sending, setSending] = useState('')
  const [error, setError] = useState('')
  const [testError, setTestError] = useState('')
  const dirty = JSON.stringify(form) !== JSON.stringify(saved)
  const teams = form.teams.filter((tm) => tm.key)
  const list = (team) => email.recipients?.[team] ?? []

  const add = (team) => {
    const value = (adding[team] ?? '').trim()
    if (!value) return
    setError('')
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      setError(t('{address} is not a valid email address.', { address: value }))
      return
    }
    if (!list(team).some((a) => a.toLowerCase() === value.toLowerCase())) setEmailIn('recipients', team, [...list(team), value])
    setAdding((a) => ({ ...a, [team]: '' }))
  }
  const send = async (key, action, body) => {
    const show = key === 'test' ? setTestError : setError
    setSending(key)
    show('')
    try {
      await onSave(action, body)
    } catch (err) {
      show(err.message)
    } finally {
      setSending('')
    }
  }
  const toggleDay = (day, on) => setEmail('days', DAYS.map(([d]) => d).filter((d) => (d === day ? on : email.days.includes(d))))

  return (
    <>
      <Panel id="email" section="email" title="Email service" icon="mail">
        <label className="discovery-check"><input type="checkbox" checked={email.service_enabled} onChange={(e) => setEmail('service_enabled', e.target.checked)} /> {t('Turn on email for this dashboard')}</label>
        <p className="muted small">
          {email.service_enabled
            ? t('Emails are sent through the SMTP server below. Turn this off to stop all emails (scheduled, “Send now” and test emails); the settings are kept.')
            : t('Email is off: this dashboard sends no emails. Turn it on to set up the SMTP server, schedule and distribution lists.')}
        </p>
        {dirty && <p className="small warning-text">{t('Save the settings to apply the change.')}</p>}
      </Panel>

      {email.service_enabled && (<>
      <Panel id="email" section="email" title="Outage notifications" icon="mail">
        <p className="muted small">{t('A snapshot of each country’s “Needs attention” list (offline, stale and unchecked devices) is emailed to that country’s distribution list. Sent by bin/check.php (cron or --loop) at these days and times in each country’s time zone.')}</p>
        <label className="discovery-check"><input type="checkbox" checked={email.enabled} onChange={(e) => setEmail('enabled', e.target.checked)} /> {t('Send outage notification emails')}</label>
        <div className="setting">
          <span className="setting-label">{t('Days')}</span>
          <div className="email-days">
            {DAYS.map(([day, label]) => (
              <label key={day} className="discovery-check"><input type="checkbox" checked={email.days.includes(day)} onChange={(e) => toggleDay(day, e.target.checked)} /> {t(label)}</label>
            ))}
          </div>
        </div>
        <div className="settings-grid">
          <Setting label="Times" hint="HH:MM in each country’s time zone, comma separated, e.g. 08:00 or 08:00, 16:00."><input value={email.times} className="mono" required={email.enabled} onChange={(e) => setEmail('times', e.target.value)} /></Setting>
          <Setting label="Send window (minutes)" hint="How long after a send time the email may still go out.">
            <input type="number" value={email.window_minutes} min={1} max={720} required onChange={(e) => setEmail('window_minutes', e.target.value)} />
          </Setting>
          <Setting label="Subject"><input value={email.subject} maxLength={150} onChange={(e) => setEmail('subject', e.target.value)} /></Setting>
          <Setting label="Dashboard link" hint="Optional link in the email, e.g. http://status.corp.local/"><input value={email.dashboard_url} type="url" maxLength={500} onChange={(e) => setEmail('dashboard_url', e.target.value)} /></Setting>
        </div>
        <label className="discovery-check"><input type="checkbox" checked={email.skip_when_empty} onChange={(e) => setEmail('skip_when_empty', e.target.checked)} /> {t('Only send when devices need attention')}</label>
      </Panel>

      <Panel id="email" section="email" title="Sending" icon="gear">
            <p className="muted small">{t('The dashboard connects to your mail server directly; no mail program is needed on this server. Use your company relay or e.g. smtp.office365.com (port 587, STARTTLS).')}</p>
            <div className="settings-grid">
              <Setting label="SMTP server"><input value={email.smtp_host} maxLength={253} required className="mono" placeholder="smtp.example.com" onChange={(e) => setEmail('smtp_host', e.target.value)} /></Setting>
              <Setting label="SMTP port" hint="587 = STARTTLS, 465 = SSL/TLS, 25 = relay.">
                <input type="number" value={email.smtp_port} min={1} max={65535} required onChange={(e) => setEmail('smtp_port', Number(e.target.value))} />
              </Setting>
              <Setting label="Encryption">
                <select value={email.smtp_encryption} onChange={(e) => setEmail('smtp_encryption', e.target.value)}>
                  <option value="starttls">STARTTLS</option>
                  <option value="ssl">SSL/TLS</option>
                  <option value="none">{t('None (internal relay only)')}</option>
                </select>
              </Setting>
              <Setting label="SMTP user" hint="Leave empty if the server accepts mail without login (relay)."><input value={email.smtp_user} maxLength={254} autoComplete="off" onChange={(e) => setEmail('smtp_user', e.target.value)} /></Setting>
              {email.smtp_user && (
                <Setting label="SMTP password" hint="Stored encrypted. Leave blank to keep the saved password if the server, port and user are unchanged.">
                  <input type="password" value={email.smtp_password} maxLength={1024} autoComplete="new-password" required={!email.has_smtp_password}
                    placeholder={email.has_smtp_password ? '••••••••' : ''} onChange={(e) => setEmail('smtp_password', e.target.value)} />
                </Setting>
              )}
            </div>
            <label className="discovery-check"><input type="checkbox" checked={email.smtp_verify_certificate} onChange={(e) => setEmail('smtp_verify_certificate', e.target.checked)} /> {t('Verify the server’s TLS certificate')}</label>
        <div className="settings-grid">
          <Setting label="From address"><input type="email" value={email.from_address} maxLength={254} required placeholder="noc@example.com" onChange={(e) => setEmail('from_address', e.target.value)} /></Setting>
          <Setting label="From name"><input value={email.from_name} maxLength={100} onChange={(e) => setEmail('from_name', e.target.value)} /></Setting>
          <Setting label="Reply-To address" hint="Optional."><input type="email" value={email.reply_to} maxLength={254} onChange={(e) => setEmail('reply_to', e.target.value)} /></Setting>
          <Setting label="Envelope sender" hint="Optional return path for bounces (SMTP MAIL FROM); default: the From address."><input type="email" value={email.envelope_sender} maxLength={254} onChange={(e) => setEmail('envelope_sender', e.target.value)} /></Setting>
        </div>
        <div className="settings-inline">
          <Setting label="Send a test email to"><input type="email" value={testTo} maxLength={254} onChange={(e) => setTestTo(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && e.preventDefault()} /></Setting>
          <button type="button" className="button secondary" disabled={!testTo || dirty || sending !== ''} onClick={() => send('test', 'send_test_email', { to: testTo })}>{sending === 'test' ? t('Sending…') : t('Send test email')}</button>
        </div>
        {dirty && <p className="small warning-text">{t('Save the settings before sending, “Send now” uses the saved settings.')}</p>}
        <div className="error" role="alert">{testError}</div>
      </Panel>

      <Panel id="email" section="email" title="Distribution lists" icon="user">
        <p className="muted small">{t('Who receives the outage notification of each country. Add or remove addresses, then save the settings.')}</p>
        {dirty && <p className="small warning-text">{t('Save the settings before sending, “Send now” uses the saved settings.')}</p>}
        <div className="error" role="alert">{error}</div>
        {teams.map((tm) => {
          const s = status?.teams?.[tm.key]
          const r = s?.last_result
          return (
            <fieldset className="discovery-settings" key={tm.key}>
              <legend>{teamName(tm)} <span className="muted">({tm.key.toUpperCase()})</span></legend>
              <p className="muted small">
                {t('Next email')}: {s?.next ? fmtTime(s.next, s.timezone) : t('off')}
                {' · '}{t('Last sent')}: {s?.last_sent ? fmtTime(s.last_sent, s.timezone) : '—'}
                {r && ` · ${t('Last result')}: ${r.skipped ? t('nothing needed attention, not sent') : t('{sent} sent, {failed} failed', { sent: r.sent, failed: r.failed.length })}${r.error ? ` – ${r.error}` : ''}`}
                {s?.timezone && ` (${s.timezone})`}
              </p>
              <table className="settings-rows">
                <tbody>
                  {list(tm.key).length === 0 && <tr><td className="muted">{t('No recipients yet.')}</td></tr>}
                  {list(tm.key).map((address) => (
                    <tr key={address}>
                      <td className="mono">{address}</td>
                      <td><button type="button" className="button tiny secondary" onClick={() => setEmailIn('recipients', tm.key, list(tm.key).filter((a) => a !== address))}>{t('Remove')}</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="settings-inline">
                <Setting label="Add recipient">
                  <input type="email" value={adding[tm.key] ?? ''} maxLength={254} placeholder="name@example.com"
                    onChange={(e) => setAdding((a) => ({ ...a, [tm.key]: e.target.value }))}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(tm.key) } }} />
                </Setting>
                <button type="button" className="button secondary with-icon" onClick={() => add(tm.key)}><Icon name="plus" size={16} /> {t('Add')}</button>
                <Setting label="Email language">
                  <select value={email.languages?.[tm.key] ?? (tm.key === 'de' ? 'de' : 'en')} onChange={(e) => setEmailIn('languages', tm.key, e.target.value)}>
                    <option value="en">English</option>
                    <option value="de">Deutsch</option>
                  </select>
                </Setting>
                <button type="button" className="button secondary" disabled={dirty || sending !== '' || (saved.email.recipients?.[tm.key] ?? []).length === 0}
                  onClick={() => send(tm.key, 'send_report', { team: tm.key })}>
                  <Icon name="mail" size={14} /> {sending === tm.key ? t('Sending…') : t('Send now')}
                </button>
              </div>
            </fieldset>
          )
        })}
      </Panel>
      </>)}
    </>
  )
}

function Users({ users, me, role, onSave }) {
  const [add, setAdd] = useState({ username: '', role: 'user' })
  const [credentials, setCredentials] = useState(null)
  const [adding, setAdding] = useState(false)
  const [savingRoles, setSavingRoles] = useState({})
  const [error, setError] = useState('')

  const run = async (action, body, reset) => {
    setError('')
    try {
      await onSave(action, body)
      reset?.()
    } catch (err) {
      setError(err.message)
    }
  }

  const changeRole = async (username, nextRole) => {
    setSavingRoles((current) => ({ ...current, [username]: true }))
    setError('')
    try {
      await onSave('change_user_role', { username, role: nextRole })
    } catch (err) {
      setError(err.message)
    } finally {
      setSavingRoles((current) => ({ ...current, [username]: false }))
    }
  }

  const addUser = async (event) => {
    event.preventDefault()
    setError('')
    setAdding(true)
    setCredentials(null)
    try {
      const response = await onSave('add_user', add)
      setCredentials(response.result)
      setAdd({ username: '', role: 'user' })
    } catch (err) {
      setError(err.message)
    } finally {
      setAdding(false)
    }
  }

  return (
    <Panel id="users" section="users">
      <p className="muted small">{t('Assign each account the access level it needs.')}</p>
      <table className="settings-rows users-table">
        <thead><tr><th>{t('User name')}</th><th>{t('Role')}</th><th>{t('Created')}</th><th>{t('Last logged in')}</th><th /></tr></thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.username}>
              <td>
                <span className="user-name-cell">
                  {u.photo_version
                    ? <img className="user-list-avatar" src={`api.php?action=user_photo&username=${encodeURIComponent(u.username)}&v=${encodeURIComponent(u.photo_version)}`} alt="" />
                    : <span className="user-list-avatar user-list-avatar-empty" aria-hidden="true"><Icon name="user" size={16} /></span>}
                  <b>{u.username}</b>{u.username === me && <span className="muted"> ({t('you')})</span>}
                </span>
              </td>
              <td>
                {['admin', 'lead'].includes(role) && u.username !== me && !(role === 'lead' && u.role === 'admin') ? (
                  <div className="user-role-control">
                    <select value={u.role} disabled={savingRoles[u.username]} onChange={(e) => changeRole(u.username, e.target.value)} aria-label={t('Role for {name}', { name: u.username })}>
                      {role === 'admin' && <option value="admin">{t('Admin')}</option>}
                      <option value="lead">{t('Lead')}</option>
                      <option value="user">{t('User')}</option>
                    </select>
                  </div>
                ) : t(u.role === 'admin' ? 'Admin' : u.role === 'lead' ? 'Lead' : 'User')}
              </td>
              <td className="muted">{u.created ? u.created.slice(0, 10) : '—'}</td>
              <td className="muted">{u.last_login == null ? t('Not recorded') : fmtTime(u.last_login)}</td>
              <td>{role === 'admin' && u.username !== me && <button type="button" className="button tiny danger" onClick={() => run('delete_user', { username: u.username })}>{t('Delete')}</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="error" role="alert">{error}</div>
      {credentials && (
        <div className="notice" role="status">
          <p>{t('Copy these credentials now and share them securely. The temporary password cannot be shown again.')}</p>
          <p><b>{t('User name')}: {credentials.username}</b></p>
          <label>{t('Temporary password')} <input type="text" readOnly autoComplete="off" value={credentials.temporary_password} onFocus={(event) => event.target.select()} /></label>
          <p>{t('The user must choose a different password on first login.')}</p>
          <button type="button" className="button secondary" onClick={() => setCredentials(null)}>{t('Dismiss')}</button>
        </div>
      )}
      <div className="users-management">
        <form className="settings-subform user-add-form" onSubmit={addUser}>
          <h3>{t('Add user')}</h3>
          <Setting label="User name"><input value={add.username} autoComplete="off" maxLength={64} required onChange={(e) => setAdd((a) => ({ ...a, username: e.target.value }))} /></Setting>
          <p className="muted small">{t('A strong temporary password is generated automatically. A password change is required on first login.')}</p>
          <Setting label="Role">
            <select value={add.role} onChange={(e) => setAdd((a) => ({ ...a, role: e.target.value }))}>
              {role === 'admin' && <option value="admin">{t('Admin')}</option>}
              <option value="lead">{t('Lead')}</option>
              <option value="user">{t('User')}</option>
            </select>
          </Setting>
          <button type="submit" className="button secondary" disabled={adding}>{t(adding ? 'Saving…' : 'Add user')}</button>
        </form>
      </div>
    </Panel>
  )
}
