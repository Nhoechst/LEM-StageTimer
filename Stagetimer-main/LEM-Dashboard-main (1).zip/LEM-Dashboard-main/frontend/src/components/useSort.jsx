import { useMemo, useState } from 'react'

/**
 * Client-side sorting. columns: {key: (row) => value}. Values that are numbers
 * sort numerically; strings sort naturally; null/'' always last.
 */
export function useSort(rows, columns) {
  const [sort, setSort] = useState({ key: null, asc: true })
  const sorted = useMemo(() => {
    if (!sort.key || !columns[sort.key]) return rows
    const get = columns[sort.key]
    const out = [...rows].sort((a, b) => {
      const x = get(a)
      const y = get(b)
      const xe = x === null || x === undefined || x === ''
      const ye = y === null || y === undefined || y === ''
      if (xe || ye) return xe && ye ? 0 : xe ? 1 : -1
      const r = typeof x === 'number' && typeof y === 'number'
        ? x - y
        : String(x).localeCompare(String(y), undefined, { numeric: true, sensitivity: 'base' })
      return sort.asc ? r : -r
    })
    return out
  }, [rows, columns, sort])

  const th = (key, label) => (
    <th
      key={key}
      className={sort.key === key ? (sort.asc ? 'asc' : 'desc') : undefined}
      onClick={() => setSort((s) => ({ key, asc: s.key === key ? !s.asc : true }))}
      style={{ cursor: 'pointer', userSelect: 'none' }}
    >
      {label}
    </th>
  )
  return [sorted, th]
}
