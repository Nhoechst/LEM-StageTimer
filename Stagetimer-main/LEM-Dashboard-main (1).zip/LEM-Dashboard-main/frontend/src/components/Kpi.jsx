import { useState } from 'react'
import Icon from './icons.jsx'
import { Modal } from './ui.jsx'
import { fmtTime } from '../format.js'
import { t } from '../i18n.js'

export function Trend({ points, metric, label, format, maximum }) {
  const measured = points.filter((point) => Number.isFinite(point[metric]))
  if (!measured.length) return <p className="kpi-trend-empty small muted">{t('No trend data yet.')}</p>

  const max = maximum ?? Math.max(1, ...measured.map((point) => point[metric]))
  const x = (index) => 4 + index / Math.max(1, points.length - 1) * 232
  const y = (point) => 52 - point[metric] / max * 44
  let connected = false
  let path = ''
  points.forEach((point, index) => {
    if (Number.isFinite(point[metric])) {
      path += `${connected ? 'L' : 'M'}${x(index)},${y(point)} `
      connected = true
    } else {
      connected = false
    }
  })

  return (
    <div className="kpi-trend">
      <svg viewBox="0 0 240 60" role="img" aria-label={label}>
        <title>{label}</title>
        <line x1="4" y1="52" x2="236" y2="52" className="kpi-trend-baseline" />
        <path d={path} fill="none" stroke="currentColor" strokeWidth="2" />
        {points.map((point, index) => Number.isFinite(point[metric]) && (
          <circle key={point.day} cx={x(index)} cy={y(point)} r="2.5" fill="currentColor">
            <title>{`${fmtTime(point.day, 'UTC')} · ${format ? format(point[metric]) : point[metric]}`}</title>
          </circle>
        ))}
      </svg>
      <span className="small muted">{t('Daily trend (30 days, UTC)')}</span>
    </div>
  )
}

export default function Kpi({ icon, tone, value, label, title, trend, trendMetric, trendLabel, trendFormat, trendMaximum }) {
  const [open, setOpen] = useState(false)
  const Tag = trendMetric ? 'button' : 'div'
  return (
    <>
      <Tag className={`kpi-card${trendMetric ? ' kpi-card-clickable' : ''}`} title={title}
        {...(trendMetric ? {
          type: 'button',
          onClick: () => setOpen(true),
          'aria-haspopup': 'dialog',
          'aria-label': t('View performance graph: {label}', { label }),
        } : {})}>
        <span className={`kpi-icon tone-${tone}`}><Icon name={icon} /></span>
        <strong>{value}</strong>
        <span className="kpi-label">{label}</span>
      </Tag>
      {trendMetric && (
        <Modal open={open} onClose={() => setOpen(false)} label={label} closeOnOutside>
          <div className="kpi-trend-popup">
            <h2>{label}</h2>
            <p className="small muted">{trendLabel}</p>
            <Trend points={trend ?? []} metric={trendMetric} label={trendLabel} format={trendFormat} maximum={trendMaximum} />
            <div className="dialog-actions">
              <button type="button" className="button secondary" onClick={() => setOpen(false)}>{t('Close')}</button>
            </div>
          </div>
        </Modal>
      )}
    </>
  )
}
