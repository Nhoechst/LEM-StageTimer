import { useMemo, useState } from 'react'
import { exportUrl } from '../api.js'
import { pct1 } from '../format.js'
import { t } from '../i18n.js'
import Icon from './icons.jsx'
import ImportForm from './ImportForm.jsx'
import Kpi from './Kpi.jsx'
import { FirmwareBadge } from './ui.jsx'
import TextChip from './TextChip.jsx'
import { useSort } from './useSort.jsx'

const BASELINE_COLUMNS = {
  model: (r) => r.rule.model,
  manufacturer: (r) => r.rule.manufacturer,
  approved: (r) => r.rule.approved,
  devices: (r) => r.total,
}

export default function Firmware({ admin, state, total, onEdit, go }) {
  const nonCompliant = state.devices
    .filter((d) => d.compliance === 'non_compliant')
    .sort((a, b) => a.site.localeCompare(b.site) || a.name.localeCompare(b.name))
  const withLatest = total.fw_compliant + total.fw_non_compliant

  return (
    <section className="page active">
      <div className="kpi-grid">
        <Kpi icon="monitor" tone="slate" value={total.total} label={t('Total Devices')} />
        <Kpi icon="shield" tone="green" value={total.fw_compliant} label={t('Compliant')} />
        <Kpi icon="alert" tone="red" value={total.fw_non_compliant} label={t('Non-compliant')} />
        <Kpi icon="help" tone="slate" value={total.fw_unknown} label={t('No Latest Info')} title={t('No latest firmware listed for the model, or current firmware unknown')} />
        <Kpi icon="chip" tone="orange" value={state.firmware.length} label={t('Models Listed')} title={t('Models with a latest firmware version')} />
        <Kpi icon="percent" tone="green" value={`${pct1(total.fw_compliant, withLatest)}%`} label={t('% Compliant')} title={t('Of devices with latest firmware info')} />
      </div>

      <div className="panel summary-panel">
        <div className="section-heading">
          <h2 className="panel-title"><Icon name="alert" /> {t('Non-compliant devices')}</h2>
          {admin && <button type="button" className="button secondary" onClick={() => go('settings/firmware')}>{t('Manage firmware')}</button>}
        </div>
        {nonCompliant.length === 0 ? (
          <p className="empty">{state.firmware.length === 0 ? t('No latest firmware versions have been added.') : t('All devices with latest firmware info are on the latest version.')}</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Device')}</th><th>{t('Location')}</th><th>{t('Model')}</th><th>{t('Current')}</th><th>{t('Latest')}</th>{admin && <th />}</tr></thead>
              <tbody>
                {nonCompliant.map((d) => (
                  <tr key={d.id}>
                    <td><span className="device-title-chip">{d.name}</span></td>
                    <td>{d.site}</td>
                    <td><TextChip value={d.model} /></td>
                    <td><FirmwareBadge compliance={d.compliance} firmware={d.firmware} latestFirmware={d.required_firmware} exempt={d.firmware_exempt} /></td>
                    <td className="mono">{d.required_firmware}</td>
                    {admin && <td className="actions"><button type="button" className="button tiny secondary item-action" title={t('Edit')} aria-label={`${t('Edit')}: ${d.name}`} onClick={() => onEdit('device', d)}><Icon name="pencil" size={16} /></button></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </section>
  )
}

export function FirmwareManagement({ state, admin, onAdd, onEdit, onDelete, onImport, onSave }) {
  const { firmware, devices } = state
  const rows = useMemo(() => firmware.map((rule) => {
    const matching = devices.filter((d) => d.model.trim().replace(/\s+/g, ' ').toLowerCase() === String(rule.model).trim().replace(/\s+/g, ' ').toLowerCase())
    return { rule, total: matching.length, ok: matching.filter((d) => d.compliance === 'compliant').length }
  }), [firmware, devices])
  const [sorted, th] = useSort(rows, BASELINE_COLUMNS)

  return (
    <div className="panel summary-panel">
      <div className="section-heading">
        <h2 className="panel-title"><Icon name="chip" /> {t('Latest firmware')}</h2>
        {admin && <button type="button" className="button primary with-icon" onClick={() => onAdd('firmware')}><Icon name="plus" size={16} /> {t('Add Latest Firmware')}</button>}
      </div>
      <p className="muted small">{t('Latest Firmware is Researched by Admin and uploaded at regular intervals')}</p>
      <p className="muted small">{t('Firmware comparison ignores product labels, version prefixes and trailing zero components. Minimum mode accepts newer versions; ambiguous versions are shown as unknown.')}</p>
      <FirmwareExemptions state={state} admin={admin} onSave={onSave} />
      <div className="table-wrap">
        <table>
          <thead><tr>{th('manufacturer', t('Manufacturer'))}{th('model', t('Model'))}{th('approved', t('Latest firmware'))}{th('devices', t('Devices'))}<th>{t('Notes')}</th>{admin && <th />}</tr></thead>
          <tbody>
            {sorted.map(({ rule, total, ok }) => (
              <tr key={rule.id}>
                <td>{rule.manufacturer}</td>
                <td><TextChip value={rule.model} /></td>
                <td className="mono">{rule.approved}</td>
                <td>{t('{ok} / {total} compliant', { ok, total })}</td>
                <td className="small">{rule.notes}</td>
                {admin && (
                  <td className="actions">
                    <button type="button" className="button tiny secondary item-action" title={t('Edit')} aria-label={`${t('Edit')}: ${rule.model}`} onClick={() => onEdit('firmware', rule)}><Icon name="pencil" size={16} /></button>{' '}
                    <button type="button" className="button tiny danger item-action" title={t('Delete')} aria-label={`${t('Delete')}: ${rule.model}`} onClick={() => onDelete({ kind: 'firmware', id: rule.id, name: rule.model })}><Icon name="trash" size={16} /></button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {firmware.length === 0 && <p className="empty">{t('No latest firmware versions yet.')}</p>}
      </div>
      {admin && <div className="io-grid">
        <div>
          <h3>{t('Upload latest firmware')}</h3>
          <p className="muted small">{t('Excel (.xlsx) or CSV with the columns Manufacturer, Model and Latest Firmware. Models already listed are updated; choose Replace to clear the list first.')}</p>
          <ImportForm type="firmware" config={state.config} aliases={state.aliases.firmware} onImport={onImport} />
        </div>
        <div>
          <h3>{t('Export')}</h3>
          <a className="button secondary" href={exportUrl('firmware')}>{t('Latest firmware (CSV)')}</a>
        </div>
      </div>}
    </div>
  )
}

function FirmwareExemptions({ state, admin, onSave }) {
  const [model, setModel] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const exemptions = state.config?.firmware_exemptions ?? []
  const models = [...new Set([...state.firmware.map(rule => rule.model), ...state.devices.map(device => device.model)].filter(Boolean))].sort()
  const update = async (name, exempt) => {
    setBusy(true)
    setError('')
    try {
      await onSave('set_firmware_exemption', { model: name, exempt })
      if (exempt) setModel('')
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }
  return (
    <section className="firmware-exemptions" aria-label={t('Firmware exemptions')}>
      <h3>{t('Firmware exemptions')}</h3>
      <p className="muted small">{t('All devices matching an exempt model are compliant, even without firmware information. Model matching ignores case and extra spaces. Remove an exemption to resume normal checks.')}</p>
      {admin && <form className="head-actions" onSubmit={(event) => { event.preventDefault(); update(model.trim(), true) }}>
        <label>{t('Exempt model')} <input list="firmware-exempt-models" value={model} maxLength={200} required disabled={busy} onChange={(event) => setModel(event.target.value)} /></label>
        <datalist id="firmware-exempt-models">{models.map(name => <option key={name} value={name} />)}</datalist>
        <button type="submit" className="button secondary" disabled={busy || !model.trim()}>{t('Add exemption')}</button>
      </form>}
      {error && <p className="error" role="alert">{error}</p>}
      {exemptions.length === 0 ? <p className="muted small">{t('No firmware exemptions.')}</p> : <ul>
        {exemptions.map(name => <li key={name}><TextChip value={name} /> {admin && <button type="button" className="button tiny danger" disabled={busy} aria-label={`${t('Remove exemption')}: ${name}`} onClick={() => update(name, false)}>{t('Remove exemption')}</button>}</li>)}
      </ul>}
    </section>
  )
}
