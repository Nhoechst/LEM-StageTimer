import { averagePing, fmtTime, pct1 } from '../format.js'
import { t } from '../i18n.js'

export default function AnnualSnapshots({ snapshots = [], compact = false }) {
  if (!snapshots?.length) return null

  return (
    <details className={compact ? 'annual-snapshots-compact' : undefined}>
      <summary className={compact ? 'button tiny secondary' : undefined}>{t('Yearly snapshots (previous 5 years)')}</summary>
      <p className="small muted">{t('Completed UTC calendar years only. Summaries preserve check counts and average ping, not individual pings or outage periods. Coverage may be partial; missing years have no recorded data.')}</p>
      <div className="table-wrap">
        <table>
          <thead><tr>
            <th>{t('Year (UTC)')}</th><th>{t('Recorded coverage (UTC)')}</th><th>{t('Checks')}</th>
            <th>{t('Failed checks')}</th><th>{t('Successful checks')}</th><th>{t('Average ping')}</th>
          </tr></thead>
          <tbody>{snapshots.map((s) => (
            <tr key={s.year}>
              <td>{s.year}</td>
              <td>{fmtTime(s.first_checked_at, 'UTC')} → {fmtTime(s.last_checked_at, 'UTC')}</td>
              <td>{s.checks}</td><td>{s.offline}</td>
              <td>{s.checks ? `${pct1(s.online, s.checks)}%` : '—'}</td>
              <td>{averagePing(s.avg_latency_ms)}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </details>
  )
}
