import { useState } from 'react'
import { fmtDate, fmtLatency, fmtTime, ipValue, isCheckable, maintenance } from '../format.js'
import { t } from '../i18n.js'
import Icon from './icons.jsx'
import Kpi from './Kpi.jsx'
import { DeviceName } from './Photo.jsx'
import IpAddress from './IpAddress.jsx'
import TextChip from './TextChip.jsx'
import { StatusBadge } from './ui.jsx'
import { useSort } from './useSort.jsx'

const isLaptop = (pc) => /\b(laptop|notebook)\b/i.test(pc.type)
const isDesktop = (pc) => /\b(desktop|workstation|tower|mini ?pc|nuc|all.in.one|aio)\b/i.test(pc.type)
const ORDER = { pending: 0, checked: 1 }
const COLUMNS = {
  name: (r) => r.pc.name,
  type: (r) => r.pc.type,
  ip: (r) => ipValue(r.pc.ip),
  online: (r) => r.pc.status,
  os: (r) => r.pc.os,
  location: (r) => r.pc.location,
  checked: (r) => r.pc.checked,
  checked_by: (r) => r.pc.checked_by,
  comments: (r) => r.pc.comments,
  state: (r) => ORDER[r.state],
}

function PcCell({ label, className, children }) {
  return <td role="cell" data-label={t(label)} className={className}><div className="device-cell-value">{children}</div></td>
}

/**
 * PC Maintenance: its own list of PCs (not the Device Status devices), with
 * online status from the same ping checks and the operating system.
 * A PC is "Checked" when its last check is within the maintenance interval.
 */
export default function Maintenance({ admin, user, state, team, checking, busy, cooldown, onCheckPcs, onAdd, onEdit, onDelete, onLogin }) {
  const interval = state.config.maintenance_days
  const pcs = state.pcs.map((pc) => {
    const m = maintenance({ maintained: pc.checked }, interval)
    return { pc, m, state: m.state === 'current' || m.state === 'due_soon' ? 'checked' : 'pending' }
  })
  const checked = pcs.filter((r) => r.state === 'checked').length
  const online = pcs.filter((r) => r.pc.status === 'online').length
  const lastCheck = pcs.reduce((max, r) => (r.pc.checked > max ? r.pc.checked : max), '')
  const [query, setQuery] = useState('')
  const q = query.trim().toLowerCase()
  const matches = (r) => !q || [r.pc.name, r.pc.type, r.pc.ip, r.pc.os, r.pc.location, r.pc.checked, r.pc.checked_by, r.pc.comments,
    t(r.state === 'checked' ? 'Checked' : 'Pending')].some((v) => String(v ?? '').toLowerCase().includes(q))
  const listed = pcs.filter(matches)
  const [sorted, th] = useSort(listed, COLUMNS)
  const checkable = pcs.some((r) => isCheckable(r.pc))
  const checkLabel = busy && checking.deviceIds.size > 0 && pcs.some((r) => checking.deviceIds.has(r.pc.id)) ? t('Checking…') : cooldown > 0 ? t('Check again in {n}s', { n: cooldown }) : t('Check PCs')

  return (
    <section className="page active">
      <div className="kpi-grid">
        <Kpi icon="monitor" tone="slate" value={pcs.length} label={t('Total PCs')} />
        <Kpi icon="ethernet" tone="green" value={online} label={t('Online')} />
        <Kpi icon="shield" tone="green" value={checked} label={t('Checked')} title={t('Checked within the last {n} days', { n: interval })} />
        <Kpi icon="alert" tone="orange" value={pcs.length - checked} label={t('Pending')} />
        <Kpi icon="monitor" tone="slate" value={`${pcs.filter((r) => isDesktop(r.pc)).length} / ${pcs.filter((r) => isLaptop(r.pc)).length}`} label={t('Desktops / Laptops')} />
        <Kpi icon="refresh" tone="slate" value={lastCheck ? fmtDate(new Date(`${lastCheck}T12:00`)) : '—'} label={t('Last Check')} />
      </div>

      <div className="panel summary-panel">
        <div className="section-heading">
          <div>
            <h2 className="panel-title"><Icon name="monitor" /> {t('PC maintenance records')}</h2>
            <p className="small muted">{t('PCs are kept separately from Device Status.')}</p>
          </div>
          <div className="head-actions table-tools">
            <input type="search" className="table-search" placeholder={t('Search any column…')} aria-label={t('Search any column…')} value={query} onChange={(e) => setQuery(e.target.value)} />
            {user && <button type="button" className="button secondary icon-only" disabled={busy || cooldown > 0 || !checkable} onClick={onCheckPcs}
              title={!checkable ? t('No PCs with an IP address to check.') : checkLabel} aria-label={checkLabel}>
              <Icon name="refresh" />
            </button>}
            {admin && <button type="button" className="button primary icon-only" title={t('Add PC')} aria-label={t('Add PC')} onClick={() => onAdd('pc', { team, type: 'Desktop' })}><Icon name="plus" /></button>}
          </div>
        </div>
        {pcs.length > 0 && (
          <p className="small muted table-note">
            {t('Showing {n} of {total} PCs.', { n: listed.length, total: pcs.length })} {t('Hover over a PC (or long-press on a phone) to see its photo.')}
          </p>
        )}
        {listed.length === 0 ? (
          <p className="empty">{pcs.length === 0 ? (admin ? t('No PCs yet. Use “Add PC” or import your PC list below.') : t('No PCs yet. Log in to add PCs.')) : t('No PCs match “{q}”.', { q: query.trim() })}</p>
        ) : (
          <div className="table-wrap">
            <table className="inventory-table pc-maintenance-table" role="table" aria-label={t('PC maintenance records')}>
              <colgroup>
                {[12, 6, 11, 8, 9, 7, 8, 7, 10, 7, 15].map((width, index) => <col key={index} style={{ width: `${width}%` }} />)}
              </colgroup>
              <thead role="rowgroup">
                <tr role="row">
                  {th('name', t('PC name'))}{th('type', t('Type'))}{th('ip', t('IP address'))}{th('online', t('Online'))}{th('os', t('Operating system'))}
                  {th('location', t('Location'))}{th('checked', t('Last checked'))}{th('checked_by', t('Checked by'))}{th('comments', t('Comments'))}
                  {th('state', t('Status'))}<th scope="col">{t('Actions')}</th>
                </tr>
              </thead>
              <tbody role="rowgroup">
                {sorted.map(({ pc, state: s }) => (
                  <tr key={pc.id} role="row">
                    <PcCell label="PC name"><DeviceName device={pc} /></PcCell>
                    <PcCell label="Type"><TextChip value={pc.type || '—'} /></PcCell>
                    <PcCell label="IP address"><IpAddress device={pc} /></PcCell>
                    <PcCell label="Online">
                      <StatusBadge status={pc.status} checking={checking.deviceIds.has(pc.id)} />
                      {pc.status === 'online' && pc.latency_ms !== null && <div className="small muted">{fmtLatency(pc.latency_ms)}</div>}
                      {pc.last_checked && <div className="small muted" title={t('Last pinged')}>{fmtTime(pc.last_checked)}</div>}
                    </PcCell>
                    <PcCell label="Operating system">{pc.os || '—'}</PcCell>
                    <PcCell label="Location">{pc.location || '—'}</PcCell>
                    <PcCell label="Last checked" className="small">{pc.checked || '—'}</PcCell>
                    <PcCell label="Checked by">{pc.checked_by || '—'}</PcCell>
                    <PcCell label="Comments" className="small">{pc.comments || '—'}</PcCell>
                    <PcCell label="Status"><span className={`badge ${s === 'checked' ? 'checked' : 'pending'}`}>{t(s === 'checked' ? 'Checked' : 'Pending')}</span></PcCell>
                    <PcCell label="Actions" className="actions">
                      {user
                        ? <button type="button" className="button tiny primary" onClick={() => onAdd('pc_check', { id: pc.id, name: pc.name, comments: pc.comments })}>{t('Complete check')}</button>
                        : <button type="button" className="button tiny secondary" onClick={onLogin}>{t('Log in to complete check')}</button>}{' '}
                      {admin && (
                        <span className="pc-edit-actions">
                          <button type="button" className="button tiny secondary item-action" title={t('Edit')} aria-label={`${t('Edit')}: ${pc.name}`} onClick={() => onEdit('pc', pc)}><Icon name="pencil" size={16} /></button>{' '}
                          <button type="button" className="button tiny danger item-action" title={t('Delete')} aria-label={`${t('Delete')}: ${pc.name}`} onClick={() => onDelete({ kind: 'pc', id: pc.id, name: pc.name })}><Icon name="trash" size={16} /></button>
                        </span>
                      )}
                    </PcCell>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </section>
  )
}
