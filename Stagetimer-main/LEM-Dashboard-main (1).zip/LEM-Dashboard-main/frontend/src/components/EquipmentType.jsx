import DanteLogo from './DanteLogo.jsx'
import TextChip from './TextChip.jsx'

export default function EquipmentType({ type }) {
  const value = String(type ?? '')
  const ndi = /\bndi\b/i.test(value)
  const dante = /\bdante\b/i.test(value)
  if (!ndi && !dante) return <TextChip value={value} />

  return (
    <span className="equipment-type">
      {ndi && <span className="equipment-ndi-badge">NDI</span>}
      {dante && <span className="equipment-dante-logo"><DanteLogo /></span>}
    </span>
  )
}
