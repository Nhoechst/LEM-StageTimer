import { t } from '../i18n.js'
import Icon from './icons.jsx'

/**
 * Summary card used on the Device Status and Firmware Compliance pages:
 * name + source, headline percentage, a row of counts, a progress bar and a link.
 * Signed-in users can open the site page from the card.
 */
export default function SiteCard({ site, percent, stats, bar, empty, canOpen = false, onOpen, action }) {
  const onKeyDown = (e) => {
    if (e.target === e.currentTarget && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault()
      onOpen()
    }
  }
  return (
    <article className={`summary-card${canOpen ? ' clickable' : ''}`} role={canOpen ? 'link' : undefined} tabIndex={canOpen ? 0 : undefined} aria-label={canOpen ? `${site.name} – ${t('View location details')}` : undefined} onClick={canOpen ? onOpen : undefined} onKeyDown={canOpen ? onKeyDown : undefined}>
      <div className="summary-card-head">
        <div>
          <h3>{site.name}</h3>
          <p className="summary-source">{t('Source: IP Addresses')} – {site.code || site.name}{site.subnet ? ` · ${site.subnet}` : ''}</p>
        </div>
        <span className="summary-pct">
          {percent}% {canOpen && <Icon name="arrow" size={18} />}
        </span>
      </div>
      {empty ? (
        <p className="summary-empty">{empty}</p>
      ) : (
        <>
          <dl className="summary-stats" style={{ gridTemplateColumns: `repeat(${stats.length}, minmax(0, 1fr))` }}>
            {stats.map(([label, value]) => (
              <div key={label}><dt>{label}</dt><dd>{value}</dd></div>
            ))}
          </dl>
          <div className="summary-bar" role="img" aria-label={t('Status bar: {online} online, {offline} offline, {unknown} unknown or stale', {
            online: bar.online,
            offline: bar.offline,
            unknown: bar.total - bar.online - bar.offline,
          })}>
            <span className="summary-online" style={{ width: `${bar.total ? (bar.online / bar.total) * 100 : 0}%` }} />
            <span className="summary-offline" style={{ width: `${bar.total ? (bar.offline / bar.total) * 100 : 0}%` }} />
          </div>
        </>
      )}
      <div className="summary-foot">
        {canOpen && <span className="summary-link">{t('View location details')} →</span>}
        {action && <span onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>{action}</span>}
      </div>
    </article>
  )
}
