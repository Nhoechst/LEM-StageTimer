import { t } from '../i18n.js'
import Icon from './icons.jsx'
import IpAddress from './IpAddress.jsx'
import { StatusBadge } from './ui.jsx'

export default function DanteManager({ devices, admin, onAdd, onEdit, onDelete, go }) {
  const standalone = devices.filter((d) => d.ownership === 'standalone')
  return (
    <section className="page active">
      <div className="panel">
        <button type="button" className="button secondary" onClick={() => go('dashboard')}>← {t('Device Status')}</button>
        <div className="section-heading">
          <h2>{t('Manage standalone Dante')}</h2>
          {admin && <button type="button" className="button primary with-icon" onClick={() => onAdd('dante')}><Icon name="plus" size={16} /> {t('Add Dante device')}</button>}
        </div>
        <p className="muted">{t('Location devices stay on their location pages. Only standalone Dante devices are managed here.')}</p>
        {standalone.length === 0 ? <p className="empty">{t('No standalone Dante devices yet.')}</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>{t('Title')}</th><th>{t('IP address')}</th><th>{t('Status')}</th>{admin && <th>{t('Actions')}</th>}</tr></thead>
              <tbody>{standalone.map((d) => (
                <tr key={d.id}>
                  <td>{d.name}</td><td><IpAddress device={d} /></td><td><StatusBadge status={d.status} /></td>
                  {admin && <td className="row-actions">
                    <button type="button" className="button secondary tiny" onClick={() => onEdit('dante', d)}>{t('Edit')}</button>
                    <button type="button" className="button danger tiny" onClick={() => onDelete({ kind: 'device', id: d.id, name: d.name })}>{t('Delete')}</button>
                  </td>}
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  )
}
