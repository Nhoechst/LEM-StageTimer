export default function TextChip({ value }) {
  if (value === undefined || value === null || !String(value).trim()) return null
  return <span className="text-chip">{value}</span>
}
