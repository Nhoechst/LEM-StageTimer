import { useEffect, useRef, useState } from 'react'
import { t } from '../i18n.js'
import { photoUrl } from '../photo.js'
import Icon from './icons.jsx'

const LONG_PRESS_MS = 500
const POPUP = { width: 320, height: 240 }
const canHover = () => typeof window !== 'undefined' && window.matchMedia?.('(hover: hover)').matches

/**
 * Device name with its photo: hovering shows the photo (desktop), a long press
 * (touch screens) or clicking the camera icon opens it full size.
 */
export function DeviceName({ device, children }) {
  const [hover, setHover] = useState(null)
  const [zoom, setZoom] = useState(false)
  const timer = useRef(0)
  const pressed = useRef(false)
  useEffect(() => () => clearTimeout(timer.current), [])

  const name = children ?? <span className="device-title-chip">{device.name}</span>
  if (!device.photo) return name

  const showHover = (e) => {
    if (!canHover()) return
    const r = e.currentTarget.getBoundingClientRect()
    const right = r.right + 12 + POPUP.width <= window.innerWidth
    setHover({
      left: right ? r.right + 12 : Math.max(8, r.left - 12 - POPUP.width),
      top: Math.min(Math.max(8, r.top + r.height / 2 - POPUP.height / 2), window.innerHeight - POPUP.height - 8),
    })
  }
  const startPress = () => {
    pressed.current = false
    clearTimeout(timer.current)
    timer.current = setTimeout(() => {
      pressed.current = true
      setZoom(true)
    }, LONG_PRESS_MS)
  }
  const endPress = (e) => {
    clearTimeout(timer.current)
    if (pressed.current && e.cancelable) e.preventDefault() // no click after a long press
  }

  return (
    <>
      <span
        className="photo-target"
        onMouseEnter={showHover}
        onMouseLeave={() => setHover(null)}
        onTouchStart={startPress}
        onTouchEnd={endPress}
        onTouchMove={() => clearTimeout(timer.current)}
        onTouchCancel={() => clearTimeout(timer.current)}
        onContextMenu={(e) => pressed.current && e.preventDefault()}
      >
        {name}
        <button type="button" className="photo-icon" title={t('Show photo')} aria-label={t('Show photo of {name}', { name: device.name })} onClick={() => setZoom(true)}>
          <Icon name="camera" size={14} />
        </button>
      </span>
      {hover && !zoom && (
        <span className="photo-popup" style={{ left: hover.left, top: hover.top }} aria-hidden="true">
          <img src={photoUrl(device)} alt="" />
        </span>
      )}
      {zoom && <PhotoViewer device={device} onClose={() => setZoom(false)} />}
    </>
  )
}

/** Full-size photo over the page; closes on click/tap or Escape. */
export function PhotoViewer({ device, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])
  return (
    <div className="photo-viewer" role="dialog" aria-modal="true" aria-label={device.name} onClick={onClose}>
      <figure>
        <img src={photoUrl(device)} alt={t('Photo of {name}', { name: device.name })} />
        <figcaption>{device.name}{device.site ? ` · ${device.site}` : ''}<span className="muted"> — {t('tap or press Esc to close')}</span></figcaption>
      </figure>
    </div>
  )
}
