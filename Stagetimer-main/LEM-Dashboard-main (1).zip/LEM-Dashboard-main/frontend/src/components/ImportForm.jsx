import { useRef, useState } from 'react'
import { t } from '../i18n.js'

/**
 * File import. siteId set = devices import into that site only.
 * type = 'devices' | 'firmware' | 'pcs' | 'backup' (backup restores everything).
 * team = team of imported PCs without a team column.
 */
export default function ImportForm({ type, siteId, team, config, aliases, onImport, modes = true }) {
  const formRef = useRef(null)
  const [busy, setBusy] = useState(false)
  const [showHelp, setShowHelp] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    const form = formRef.current
    const file = form.elements.file.files[0]
    if (!file) return
    if (file.size > config.max_import_bytes) {
      onImport(null, t('The file is too large (limit {n} MB).', { n: (config.max_import_bytes / 1048576).toFixed(0) }))
      return
    }
    const data = new FormData(form)
    data.set('type', type === 'backup' ? 'devices' : type)
    if (team) data.set('team', team)
    if (siteId) {
      data.set('site_id', String(siteId))
      data.set('scope', 'site')
    }
    setBusy(true)
    try {
      if (await onImport(data)) form.elements.file.value = ''
    } finally {
      setBusy(false)
    }
  }

  const accept = type === 'backup'
    ? '.json,application/json'
    : '.xlsx,.csv,.txt,.tsv,.json,text/csv,application/json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  return (
    <form ref={formRef} onSubmit={submit} className="import-form">
      <label>{type === 'backup' ? t('Backup file (JSON)') : t('Excel (.xlsx), CSV or JSON file')}
        <input type="file" name="file" accept={accept} required />
      </label>
      {modes && type !== 'backup' && (
        <label>{t('Existing records')}
          <select name="mode" defaultValue="merge">
            <option value="merge">{t('Merge – add new, update matching')}</option>
            <option value="replace">{siteId ? t('Replace – remove this location’s devices first') : type === 'pcs' ? t('Replace – remove this team’s PCs first') : t('Replace – remove existing first')}</option>
          </select>
        </label>
      )}
      <div className="dialog-actions">
        {aliases && <button type="button" className="button secondary" onClick={() => setShowHelp((v) => !v)}>{t('Columns')}</button>}
        <button type="submit" className={`button ${type === 'backup' ? 'danger' : 'primary'}`} disabled={busy}>
          {busy ? t('Importing…') : type === 'backup' ? t('Restore') : t('Import')}
        </button>
      </div>
      {showHelp && aliases && (
        <div className="local-note column-help" style={{ gridColumn: '1 / -1' }}>
          <strong>{t('Recognised columns')}</strong> {t('(not case sensitive; spaces and punctuation ignored)')}
          {Object.entries(aliases).filter(([f]) => f !== 'site').map(([field, names]) => (
            <div key={field}><b>{field}</b>: {names.slice(0, 6).map((n) => <span key={n}><span className="pill small">{n}</span> </span>)}</div>
          ))}
        </div>
      )}
    </form>
  )
}
