import { useMemo, useRef, useState } from 'react'
import { t } from '../i18n.js'
import { searchInventory, searchTarget } from '../search.js'
import { FirmwareBadge, StatusBadge } from './ui.jsx'
import Icon from './icons.jsx'

function ResultLink({ result, onNavigate, details = false }) {
  return (
    <a className="inventory-search-result" href={`#${result.target || 'dashboard'}`} onClick={onNavigate}>
      <span className="small muted">{t(result.kind)}</span>
      <strong>{result.name || '—'}</strong>
      {result.count != null && <span>{t('{n} device(s)', { n: result.count })}</span>}
      {result.detail && <span className="small muted">{result.detail}</span>}
      {details && result.device && <span className="search-device-status">
        <StatusBadge status={result.device.status} />
        <FirmwareBadge compliance={result.device.compliance} firmware={result.device.firmware} latestFirmware={result.device.required_firmware} exempt={result.device.firmware_exempt} />
      </span>}
    </a>
  )
}

export default function GlobalSearch({ index }) {
  const [query, setQuery] = useState('')
  const [open, setOpen] = useState(false)
  const input = useRef(null)
  const results = useMemo(() => searchInventory(index, query), [index, query])
  const target = searchTarget(query.trim())
  const close = () => setOpen(false)
  return (
    <form className="inventory-search" role="search" aria-label={t('Search inventory')}
      onBlur={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) close() }}
      onKeyDown={(event) => {
        if (event.key === 'Escape') { input.current?.focus(); close() }
        if (event.key === 'ArrowDown' && event.target === input.current) {
          event.preventDefault()
          const form = event.currentTarget
          setOpen(true)
          requestAnimationFrame(() => form.querySelector('.inventory-search-result')?.focus())
        }
      }}
      onSubmit={(event) => { event.preventDefault(); if (query.trim()) { close(); window.location.assign(`#${target}`) } }}>
      <div className="inventory-search-input">
        <input ref={input} type="search" value={query} aria-label={t('Search inventory')} placeholder={t('Search IP, model, location…')}
          aria-expanded={open && !!query.trim()} aria-controls="inventory-search-suggestions" autoComplete="off"
          onFocus={() => setOpen(true)} onClick={() => setOpen(true)} onChange={(event) => { setQuery(event.target.value); setOpen(true) }} />
        <button type="submit" className="button secondary" aria-label={t('Search')} disabled={!query.trim()}><Icon name="search" size={18} /></button>
      </div>
      {open && query.trim() && <div id="inventory-search-suggestions" className="inventory-search-suggestions">
        <p className="small muted" role="status">{t('{n} result(s) across all countries', { n: results.length })}</p>
        <ul>{results.slice(0, 10).map(result => <li key={result.key}><ResultLink result={result} onNavigate={close} /></li>)}</ul>
        {!results.length && <p className="muted">{t('No matching inventory found.')}</p>}
        <a className="inventory-search-all" href={`#${target}`} onClick={close}>{t('View all search results')}</a>
      </div>}
    </form>
  )
}

export function SearchPage({ index, query, model }) {
  const [limit, setLimit] = useState(50)
  const results = useMemo(() => searchInventory(index, query, model), [index, query, model])
  return (
    <section className="page active">
      <div className="panel inventory-search-panel">
        <h1>{model !== null ? t('Devices with model: {model}', { model }) : t('Search results: {query}', { query })}</h1>
        <p className="muted" role="status">{t('{n} result(s) across all countries', { n: results.length })}</p>
        <p className="small muted">{t('Select a device or location to open its location. Standalone Dante devices and PCs open their inventory pages.')}</p>
        {!results.length && <p className="empty">{t('No matching inventory found.')}</p>}
        <ul className="inventory-search-results">{results.slice(0, limit).map(result => <li key={result.key}><ResultLink result={result} details /></li>)}</ul>
        {results.length > limit && <button type="button" className="button secondary" onClick={() => setLimit(value => value + 50)}>{t('Show more results')}</button>}
      </div>
    </section>
  )
}
