import { useEffect, useId, useRef, useState } from 'react'
import Icon from './icons.jsx'
import { STATUS_LABELS, fmtLatency, fmtTime } from '../format.js'
import { t } from '../i18n.js'
import { Modal } from './ui.jsx'
import { closeAccountOnBlur } from '../accountMenu.js'

export function AccountMenu({ user, onLogin, onSettings, onLogout }) {
  const ref = useRef(null)
  const [open, setOpen] = useState(false)
  const dropdownId = useId()
  useEffect(() => {
    if (!user) return
    const closeOutside = (event) => {
      if (!ref.current?.contains(event.target)) setOpen(false)
    }
    const closeOnEscape = (event) => {
      if (event.key === 'Escape' && ref.current?.querySelector('.account-trigger')?.getAttribute('aria-expanded') === 'true') {
        setOpen(false)
        ref.current.querySelector('.account-trigger')?.focus()
      }
    }
    document.addEventListener('pointerdown', closeOutside)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOutside)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [user])

  if (!user) return (
    <button type="button" className="button secondary account-trigger" onClick={onLogin}>
      <Icon name="user" size={16} /> <span>{t('Log in')}</span>
    </button>
  )
  const select = (action) => {
    setOpen(false)
    action()
  }
  return (
    <div ref={ref} className="account-menu" onBlur={(event) => closeAccountOnBlur(event, () => setOpen(false))}>
      <button type="button" className="button secondary account-trigger" title={t('Logged in as {name}', { name: user })} aria-expanded={open} aria-controls={dropdownId} onClick={() => setOpen((value) => !value)}>
        <Icon name="user" size={16} /> <span>{user}</span>
      </button>
      <div id={dropdownId} className="account-dropdown" hidden={!open}>
        <button type="button" onClick={() => select(onSettings)}><Icon name="gear" size={16} /> {t('Settings')}</button>
        <button type="button" onClick={() => select(onLogout)}><Icon name="logout" size={16} /> {t('Log out')}</button>
      </div>
    </div>
  )
}

/** Crucial devices (e.g. Discovery Server) whose status is always shown in the top bar. */
export function HeaderStatus({ devices }) {
  const [mobile, setMobile] = useState(() => window.matchMedia('(max-width: 700px), (pointer: coarse)').matches)
  useEffect(() => {
    const media = window.matchMedia('(max-width: 700px), (pointer: coarse)')
    const update = () => setMobile(media.matches)
    update()
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])

  if (!devices?.length) return null
  return (
    <div className="header-status" aria-label={t('Crucial equipment')}>
      {devices.map((d, index) => {
        const Tag = d.log_enabled ? 'a' : 'span'
        const href = `#discovery-log/${index}?host=${encodeURIComponent(d.ip)}&returnTo=${encodeURIComponent(window.location.hash || '#dashboard')}`
        return <Tag
          key={`${d.name}-${d.ip}`}
          className={`header-chip chip-${d.status}`}
          title={`${d.name} · ${d.ip}\n${t(STATUS_LABELS[d.status])}${d.latency_ms !== null ? ` · ${fmtLatency(d.latency_ms)}` : ''}\n${t('Last check')}: ${fmtTime(d.checked)}`}
          {...(d.log_enabled ? {
            href,
            target: mobile ? '_self' : '_blank',
            rel: 'noopener noreferrer',
            'aria-label': t(mobile ? 'Open log for {name}' : 'Open log for {name} (new window)', { name: d.name }),
            onClick: (event) => {
              if (mobile || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return
              event.preventDefault()
              window.open(href, '_blank', 'noopener,noreferrer,width=1100,height=760')
            },
          } : {})}
        >
          <i className="header-dot" aria-hidden="true" />
          <b>{d.name}</b>
          <span className="header-chip-state">{t(STATUS_LABELS[d.status])}</span>
        </Tag>
      })}
    </div>
  )
}

/**
 * Log in to the admin backend, or create the first administrator account
 * (setup) when there are no accounts yet.
 */
export function LoginDialog({ open, setup, onClose, onSubmit }) {
  return (
    <Modal open={open} onClose={onClose}>
      <LoginForm setup={setup} onClose={onClose} onSubmit={onSubmit} />
    </Modal>
  )
}

function LoginForm({ setup, onClose, onSubmit }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    if (setup && password !== confirm) {
      setError(t('The passwords don’t match.'))
      return
    }
    setBusy(true)
    setError('')
    try {
      await onSubmit(setup ? 'setup' : 'login', { username, password })
      onClose()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>{t(setup ? 'Create administrator account' : 'Log in')}</h2>
      {setup && <p className="notice">{t('No accounts exist yet. The first account you create here can change the settings and add other users.')}</p>}
      <label>{t('User name')} <input name="username" autoComplete="username" required maxLength={64} value={username} onChange={(e) => setUsername(e.target.value)} autoFocus /></label>
      <label>{t('Password')} <input name="password" type="password" autoComplete={setup ? 'new-password' : 'current-password'} required minLength={setup ? 8 : undefined} maxLength={200} value={password} onChange={(e) => setPassword(e.target.value)} /></label>
      {setup && <label>{t('Repeat password')} <input name="confirm" type="password" autoComplete="new-password" required maxLength={200} value={confirm} onChange={(e) => setConfirm(e.target.value)} /></label>}
      <div className="error" role="alert">{error}</div>
      <div className="dialog-actions">
        <button type="button" className="button secondary" onClick={onClose}>{t('Cancel')}</button>
        <button type="submit" className="button primary" disabled={busy}>{busy ? t('Please wait…') : t(setup ? 'Create account' : 'Log in')}</button>
      </div>
    </form>
  )
}
