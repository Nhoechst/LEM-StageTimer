import { useEffect, useId, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { t } from '../i18n.js'
import DeviceTelemetry from './DeviceTelemetry.jsx'
import { DeviceName } from './Photo.jsx'

export default function DeviceTelemetryPopup({ device, revision }) {
  const id = useId()
  const popup = useRef(null)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!open) return
    const close = () => popup.current?.hidePopover()
    const onScroll = (event) => {
      if (event.target instanceof Node && popup.current?.contains(event.target)) return
      close()
    }
    window.addEventListener('scroll', onScroll, true)
    window.addEventListener('resize', close)
    return () => {
      window.removeEventListener('scroll', onScroll, true)
      window.removeEventListener('resize', close)
    }
  }, [open])

  return (
    <>
      <DeviceName device={device}>
        <button type="button" className="device-title-chip" popoverTarget={id} aria-haspopup="dialog" title={t('Telemetry for {name}', { name: device.name })}>
          {device.name}
        </button>
      </DeviceName>
      {createPortal(
        <div ref={popup} id={id} popover="auto" role="dialog" className="telemetry-popup"
          aria-labelledby={`${id}-title`} onToggle={(event) => {
            if (event.target === event.currentTarget) setOpen(event.newState === 'open')
          }}>
          <div className="section-heading">
            <h2 id={`${id}-title`}>{t('Telemetry for {name}', { name: device.name })}</h2>
            <button type="button" className="button tiny secondary" popoverTarget={id} popoverTargetAction="hide">{t('Close')}</button>
          </div>
          <p className="small muted">{t('Scroll the page, click outside, or press Escape to close.')}</p>
          {open && <DeviceTelemetry device={device} revision={revision} />}
        </div>,
        document.body,
      )}
    </>
  )
}
