export default function IpAddress({ device, className = 'mono' }) {
  const ip = String(device.ip ?? '').trim()
  if (!ip) return '—'
  if (ip === '*******' || ip === '0.0.0.0') return <span className={className}>{ip}</span>

  const host = ip.includes(':') && !ip.startsWith('[') ? `[${ip}]` : ip
  const href = /^https?:\/\//i.test(device.web_url ?? '') ? device.web_url : `http://${host}`

  return (
    <a className={`ip-chip ${className}`} href={href} target="_blank" rel="noopener noreferrer" title={t('Open device interface')} aria-label={`${ip}: ${t('Open device interface (opens in a new tab)')}`}>
      <span>{ip}</span>
      <Icon name="externalLink" size={13} />
    </a>
  )
}
import { t } from '../i18n.js'
import Icon from './icons.jsx'
