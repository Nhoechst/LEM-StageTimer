import { t } from '../i18n.js'
import IpAddress from './IpAddress.jsx'

export default function NetworkDeviceList({ devices, siteNames, label, go, showNotes = false }) {
  return (
    <table className="network-device-list" aria-label={label}>
      <thead>
        <tr><th scope="col">{t('Title')}</th><th scope="col">{t(showNotes ? 'Notes' : 'Location')}</th><th scope="col">{t('IP address')}</th></tr>
      </thead>
      <tbody>
        {devices.map((device) => (
          <tr key={device.id}>
            <td><span className="device-title-chip">{device.name}</span></td>
            <td>{showNotes ? device.notes || '—' : device.ownership === 'standalone' ? t('Standalone') : <button type="button" className="device-title-chip network-location" onClick={() => go(`location/${device.site_id}`)}>{siteNames.get(device.site_id) || device.site}</button>}</td>
            <td><IpAddress device={device} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
