import { useState } from 'react'
import Icon from './icons.jsx'

// Try the known Dante logo filenames; dark mode inverts the logo (see extras.css).
const SOURCES = ['logos/Dante_logo.svg', 'logos/dante.svg', 'logos/dante.png']

export default function DanteTitle() {
  const [index, setIndex] = useState(0)
  if (index >= SOURCES.length) return <Icon name="audio" />
  return <img className="dante-logo" src={SOURCES[index]} alt="DANTE" onError={() => setIndex((i) => i + 1)} />
}
