<?php

declare(strict_types=1);

namespace StatusDashboard;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use RuntimeException;

/**
 * Outage notification emails: a snapshot of the "Needs attention" list
 * (offline, stale and unchecked devices) of one country, sent to that
 * country's distribution list through an SMTP server (SmtpClient).
 * `service_enabled` switches all email of the dashboard on or off.
 *
 * Reports go out on the configured week days and times (`email.days`,
 * `email.times`) in each country's own time zone; each slot is sent only once
 * (state "email" in the database), however often bin/check.php runs.
 */
class OutageMailer
{
    public const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
    public const LANGUAGES = ['en', 'de'];
    public const MAX_RECIPIENTS = 100;

    /** Defaults for the `email` setting (weekly, Wednesday morning). */
    public const DEFAULTS = [
        'service_enabled' => false, // master switch: no email at all while off
        'enabled'         => false, // scheduled outage emails
        'days'            => ['wed'],
        'times'           => ['08:00'],
        'window_minutes'  => 59,
        'from_address'    => '',
        'from_name'       => 'Equipment Status',
        'reply_to'        => '',
        'envelope_sender' => '',
        'subject'         => 'Outage notification',
        'dashboard_url'   => '',
        'skip_when_empty' => false,
        'recipients'      => [],  // country key => list of email addresses
        'languages'       => [],  // country key => 'en' | 'de'
        'smtp_host'       => '',
        'smtp_port'       => 587,
        'smtp_encryption' => 'starttls', // starttls | ssl | none
        'smtp_user'       => '',
        'smtp_password_encrypted' => '',
        'smtp_verify_certificate' => true,
    ];

    /** Status order of the "Needs attention" list. */
    private const RANK = [EquipmentService::STATUS_OFFLINE => 0, EquipmentService::STATUS_STALE => 1, EquipmentService::STATUS_UNKNOWN => 2];

    private const TEXT = [
        'de' => [
            'Needs attention' => 'Handlungsbedarf',
            'Status' => 'Status',
            'Device' => 'Gerät',
            'IP address' => 'IP-Adresse',
            'Location' => 'Standort',
            'Firmware' => 'Firmware',
            'Last checked' => 'Zuletzt geprüft',
            'Offline' => 'Offline',
            'Stale' => 'Veraltet',
            'Unknown' => 'Unbekannt',
            'never' => 'nie',
            'Total devices' => 'Geräte gesamt',
            'Online' => 'Online',
            'External Network' => 'Externes Netz',
            'No Status' => 'Kein Status',
            '% Online' => '% online',
            'All checked devices are online.' => 'Alle geprüften Geräte sind online.',
            'Snapshot of {country} at {time}.' => 'Momentaufnahme für {country} am {time}.',
            '{n} device(s) need attention' => '{n} Gerät(e) mit Handlungsbedarf',
            'all devices online' => 'alle Geräte online',
            'Open the dashboard' => 'Dashboard öffnen',
            'You receive this email because you are on the outage notification list for {country}.' => 'Sie erhalten diese E-Mail, weil Sie auf dem Verteiler für Ausfallmeldungen für {country} stehen.',
            'Test email' => 'Test-E-Mail',
            'This is a test email from {title}. Outage notifications can be sent from this server.' => 'Dies ist eine Test-E-Mail von {title}. Ausfallmeldungen können von diesem Server versendet werden.',
        ],
    ];

    /** @var callable(string, string, string, string, string): void */
    private $transport;

    /**
     * @param array<string, mixed> $config Full application configuration.
     * @param SshPassword|null $passwords Decrypts the stored SMTP password.
     * @param (callable(string, string, string, string, string): void)|null $transport
     *        Sends one email (envelope sender, to, encoded subject, headers, body) and
     *        throws a RuntimeException on failure; default: the configured transport.
     */
    public function __construct(private readonly array $config, private readonly ?SshPassword $passwords = null, ?callable $transport = null)
    {
        $this->transport = $transport ?? $this->defaultTransport(...);
    }

    /**
     * Context the SMTP password is encrypted for: it can only be decrypted for the same
     * host, user and port (see SshPassword).
     *
     * @param array<string, mixed> $email
     * @return array{ip: string, ssh_user: string, ssh_port: int}
     */
    public static function smtpContext(array $email): array
    {
        return ['ip' => 'smtp:' . (string) $email['smtp_host'], 'ssh_user' => (string) $email['smtp_user'], 'ssh_port' => (int) $email['smtp_port']];
    }

    /**
     * The `email` setting with every key present.
     *
     * @param array<string, mixed> $config
     * @return array<string, mixed>
     */
    public static function settings(array $config): array
    {
        $stored = (array) ($config['email'] ?? []);
        if (!array_key_exists('service_enabled', $stored) && !empty($stored['enabled'])) {
            $stored['service_enabled'] = true; // saved before the master switch existed
        }
        return array_replace(self::DEFAULTS, array_intersect_key($stored, self::DEFAULTS));
    }

    /**
     * Language of a country's emails: the configured one, else German for "de".
     */
    public static function language(array $email, string $team): string
    {
        $lang = (string) (((array) ($email['languages'] ?? []))[$team] ?? '');
        return in_array($lang, self::LANGUAGES, true) ? $lang : ($team === 'de' ? 'de' : 'en');
    }

    /**
     * @return list<string>
     */
    public static function recipients(array $email, string $team): array
    {
        return array_values(array_filter(
            array_map('strval', (array) (((array) ($email['recipients'] ?? []))[$team] ?? [])),
            static fn (string $a): bool => self::validAddress($a)
        ));
    }

    public static function validAddress(string $address): bool
    {
        // FILTER_VALIDATE_EMAIL rejects CR/LF, so addresses can't inject headers.
        return strlen($address) <= 254 && filter_var($address, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Validate the `email` block of the Settings form.
     *
     * @param array<string, mixed> $in
     * @param list<string> $teams Country keys
     * @return array<string, mixed>
     */
    public static function validate(array $in, array $teams, array $existing = [], ?SshPassword $passwords = null): array
    {
        $text = static function (mixed $value, int $max): string {
            $value = is_scalar($value) ? trim((string) $value) : '';
            return mb_substr((string) preg_replace('/[\x00-\x1F\x7F]/u', '', $value), 0, $max);
        };
        $address = static function (mixed $value, string $label) use ($text): string {
            $value = $text($value, 254);
            if ($value !== '' && !self::validAddress($value)) {
                throw new InvalidArgumentException("{$label}: '{$value}' is not a valid email address.");
            }
            return $value;
        };

        $out = [
            'service_enabled' => filter_var($in['service_enabled'] ?? false, FILTER_VALIDATE_BOOL),
            'enabled'         => filter_var($in['enabled'] ?? false, FILTER_VALIDATE_BOOL),
        ];

        $days = [];
        foreach ((array) ($in['days'] ?? []) as $day) {
            $day = strtolower($text($day, 3));
            if (in_array($day, self::DAYS, true)) {
                $days[$day] = true;
            }
        }
        $out['days'] = array_values(array_filter(self::DAYS, static fn (string $d): bool => isset($days[$d])));

        $times = $in['times'] ?? [];
        $times = is_array($times) ? $times : preg_split('/[\s,;]+/', is_scalar($times) ? (string) $times : '');
        $times = array_values(array_unique(array_filter(array_map(static fn ($t) => $text($t, 10), (array) $times), static fn ($t) => $t !== '')));
        $out['times'] = CheckGuard::normaliseTimes($times);
        if (count($out['times']) !== count($times) || count($out['times']) > 24) {
            throw new InvalidArgumentException('Email times must be HH:MM (24 hour), e.g. 08:00.');
        }
        if ($out['enabled'] && ($out['days'] === [] || $out['times'] === [])) {
            throw new InvalidArgumentException('Choose at least one day and one time for the outage emails.');
        }
        $window = $in['window_minutes'] ?? 59;
        if (!is_numeric($window) || (int) $window != $window || (int) $window < 1 || (int) $window > 720) {
            throw new InvalidArgumentException('Send window must be a whole number from 1 to 720.');
        }
        $out['window_minutes'] = (int) $window;

        $out['from_address'] = $address($in['from_address'] ?? '', 'From address');
        if (($out['service_enabled'] || $out['enabled']) && $out['from_address'] === '') {
            throw new InvalidArgumentException('Enter a From address for the outage emails.');
        }
        $out['from_name'] = $text($in['from_name'] ?? '', 100);
        $out['reply_to'] = $address($in['reply_to'] ?? '', 'Reply-To address');
        $out['envelope_sender'] = $address($in['envelope_sender'] ?? '', 'Envelope sender');
        if ($out['envelope_sender'] !== '' && preg_match('/^[A-Za-z0-9._+-]+@[A-Za-z0-9.-]+$/', $out['envelope_sender']) !== 1) {
            // Used as SMTP MAIL FROM, so only plain addresses are allowed.
            throw new InvalidArgumentException("Envelope sender: '{$out['envelope_sender']}' is not a valid email address.");
        }
        $out['subject'] = $text($in['subject'] ?? '', 150);
        if ($out['subject'] === '') {
            $out['subject'] = self::DEFAULTS['subject'];
        }
        $out['dashboard_url'] = $text($in['dashboard_url'] ?? '', 500);
        if ($out['dashboard_url'] !== '' && (filter_var($out['dashboard_url'], FILTER_VALIDATE_URL) === false
            || !in_array(strtolower((string) parse_url($out['dashboard_url'], PHP_URL_SCHEME)), ['http', 'https'], true))) {
            throw new InvalidArgumentException('Dashboard link must be an http:// or https:// address.');
        }
        $out['skip_when_empty'] = filter_var($in['skip_when_empty'] ?? false, FILTER_VALIDATE_BOOL);

        $out['smtp_host'] = $text($in['smtp_host'] ?? '', 253);
        if ($out['smtp_host'] !== '' && preg_match('/^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$/', $out['smtp_host']) !== 1
            && filter_var($out['smtp_host'], FILTER_VALIDATE_IP) === false) {
            throw new InvalidArgumentException("SMTP server: '{$out['smtp_host']}' is not a valid host name or IP address.");
        }
        if ($out['service_enabled'] && $out['smtp_host'] === '') {
            throw new InvalidArgumentException('Enter the SMTP server.');
        }
        $port = $in['smtp_port'] ?? 587;
        if (!is_numeric($port) || (int) $port != $port || (int) $port < 1 || (int) $port > 65535) {
            throw new InvalidArgumentException('SMTP port must be a whole number from 1 to 65535.');
        }
        $out['smtp_port'] = (int) $port;
        $out['smtp_encryption'] = in_array($in['smtp_encryption'] ?? '', SmtpClient::ENCRYPTIONS, true) ? (string) $in['smtp_encryption'] : 'starttls';
        $out['smtp_user'] = $text($in['smtp_user'] ?? '', 254);
        $out['smtp_verify_certificate'] = filter_var($in['smtp_verify_certificate'] ?? true, FILTER_VALIDATE_BOOL);
        if ($out['smtp_user'] !== '' && $out['smtp_encryption'] === 'none') {
            throw new InvalidArgumentException('SMTP login needs STARTTLS or SSL/TLS, so the password is not sent unencrypted.');
        }
        // Like the SSH passwords: stored encrypted, never sent to the browser. Blank keeps the
        // saved one while server, port and user are unchanged.
        $password = $in['smtp_password'] ?? '';
        if (!is_string($password) || strlen($password) > 1024 || preg_match('/[\x00\r\n]/', $password)) {
            throw new InvalidArgumentException('SMTP password must be at most 1024 bytes without NUL or newline characters.');
        }
        $out['smtp_password_encrypted'] = '';
        if ($out['smtp_user'] !== '') {
            if ($password !== '') {
                if ($passwords === null) {
                    throw new RuntimeException('SMTP password storage is unavailable.');
                }
                $out['smtp_password_encrypted'] = $passwords->encrypt($password, self::smtpContext($out));
            } else {
                $old = self::settings($existing);
                if ($old['smtp_host'] === $out['smtp_host'] && (int) $old['smtp_port'] === $out['smtp_port'] && $old['smtp_user'] === $out['smtp_user']) {
                    $out['smtp_password_encrypted'] = (string) $old['smtp_password_encrypted'];
                }
            }
            if ($out['service_enabled'] && $out['smtp_password_encrypted'] === '') {
                throw new InvalidArgumentException('Enter the SMTP password for this server, port and user.');
            }
        }

        $out['recipients'] = [];
        $out['languages'] = [];
        foreach ($teams as $team) {
            $list = [];
            foreach ((array) (((array) ($in['recipients'] ?? []))[$team] ?? []) as $a) {
                $a = $address($a, 'Distribution list');
                if ($a !== '' && !in_array(strtolower($a), array_map('strtolower', $list), true)) {
                    $list[] = $a;
                }
            }
            if (count($list) > self::MAX_RECIPIENTS) {
                throw new InvalidArgumentException('At most ' . self::MAX_RECIPIENTS . ' recipients per country.');
            }
            $out['recipients'][$team] = $list;
            $lang = (string) (((array) ($in['languages'] ?? []))[$team] ?? '');
            $out['languages'][$team] = in_array($lang, self::LANGUAGES, true) ? $lang : ($team === 'de' ? 'de' : 'en');
        }
        return $out;
    }

    /**
     * Report slots ($days at $times in $timezone) from the day of $from for $count days, ascending.
     *
     * @param list<string> $days
     * @param list<string> $times
     * @return list<int>
     */
    public static function slots(array $days, array $times, string $timezone, int $from, int $count): array
    {
        $slots = [];
        $day = (new DateTimeImmutable('@' . $from))->setTimezone(new DateTimeZone($timezone))->setTime(0, 0);
        for ($d = 0; $d <= $count; $d++) {
            $date = $day->modify("+{$d} days");
            if (!in_array(strtolower($date->format('D')), $days, true)) {
                continue;
            }
            foreach (CheckGuard::normaliseTimes($times) as $t) {
                [$h, $i] = array_map('intval', explode(':', $t));
                $slots[] = $date->setTime($h, $i)->getTimestamp();
            }
        }
        sort($slots);
        return $slots;
    }

    public function nextSlot(string $timezone, ?int $now = null): ?int
    {
        $email = self::settings($this->config);
        if (!$email['service_enabled'] || !$email['enabled']) {
            return null;
        }
        $now ??= time();
        foreach (self::slots($email['days'], $email['times'], $timezone, $now, 8) as $slot) {
            if ($slot > $now) {
                return $slot;
            }
        }
        return null;
    }

    /**
     * Claim the report slot of $team that is due now, so it is sent only once.
     *
     * @return int|null The slot's timestamp, or null if no report is due.
     */
    public function claimDueSlot(Database $db, string $team, string $timezone, ?int $now = null): ?int
    {
        $email = self::settings($this->config);
        if (!$email['service_enabled'] || !$email['enabled']) {
            return null;
        }
        $now ??= time();
        $window = max(1, (int) $email['window_minutes']) * 60;
        $due = null;
        foreach (self::slots($email['days'], $email['times'], $timezone, $now - 86400, 2) as $slot) {
            if ($slot <= $now && $now < $slot + $window) {
                $due = $slot;
            }
        }
        if ($due === null) {
            return null;
        }
        return $db->stateUpdate('email', static function (array &$state) use ($due, $team): ?int {
            if ((int) ($state['teams'][$team]['slot'] ?? 0) >= $due) {
                return null;
            }
            $state['teams'][$team] = ['slot' => $due] + (array) ($state['teams'][$team] ?? []);
            return $due;
        });
    }

    /**
     * Remember the result of a report (shown in Settings → Email).
     *
     * @param array{sent: int, failed: list<string>, skipped: bool, attention: int, error: string} $result
     */
    public static function record(Database $db, string $team, array $result, ?int $now = null): void
    {
        $now ??= time();
        $db->stateUpdate('email', static function (array &$state) use ($team, $result, $now): void {
            $state['teams'][$team] = [
                'last_sent'   => $result['sent'] > 0 ? $now : ($state['teams'][$team]['last_sent'] ?? null),
                'last_run'    => $now,
                'last_result' => $result,
            ] + (array) ($state['teams'][$team] ?? []);
        });
    }

    /**
     * The "Needs attention" rows of one country plus its totals.
     *
     * @param array<string, mixed> $data Inventory (see Store::emptyData())
     * @param callable(mixed): string $teamOf Country key of a stored location team value
     * @return array{rows: list<array<string, mixed>>, total: array<string, int>}
     */
    public function snapshot(array $data, string $team, callable $teamOf, ?int $now = null): array
    {
        $sites = [];
        foreach ($data['sites'] as $site) {
            if ($teamOf($site['team'] ?? '') === $team) {
                $sites[(int) $site['id']] = true;
            }
        }
        $rows = array_values(array_filter(
            (new EquipmentService($this->config))->buildRows($data, $now),
            static fn (array $r): bool => Inventory::isStandalone($r)
                ? $teamOf($r['team'] ?? '') === $team
                : isset($sites[$r['site_id']])
        ));
        $total = ['total' => count($rows), 'online' => 0, 'offline' => 0, 'external' => 0, 'no_status' => 0];
        foreach ($rows as $r) {
            match ($r['status']) {
                EquipmentService::STATUS_ONLINE => $total['online']++,
                EquipmentService::STATUS_OFFLINE => $total['offline']++,
                EquipmentService::STATUS_EXTERNAL => $total['external']++,
                default => $total['no_status']++,
            };
        }
        $attention = array_values(array_filter($rows, static fn (array $r): bool => !$r['dante'] && isset(self::RANK[$r['status']])));
        usort($attention, static fn (array $a, array $b): int => self::RANK[$a['status']] <=> self::RANK[$b['status']]
            ?: strnatcasecmp($a['site'], $b['site']) ?: strnatcasecmp($a['name'], $b['name']));
        return ['rows' => $attention, 'total' => $total];
    }

    /**
     * Send the snapshot of one country to its distribution list (one email per
     * recipient, so addresses aren't shared and one bad address doesn't stop the rest).
     *
     * @param array{rows: list<array<string, mixed>>, total: array<string, int>} $snapshot
     * @return array{sent: int, failed: list<string>, skipped: bool, attention: int, error: string}
     */
    public function sendReport(string $team, string $countryName, string $timezone, array $snapshot, ?int $now = null): array
    {
        $email = self::settings($this->config);
        self::assertServiceOn($email);
        $recipients = self::recipients($email, $team);
        $count = count($snapshot['rows']);
        $result = ['sent' => 0, 'failed' => [], 'skipped' => false, 'attention' => $count, 'error' => ''];
        if ($recipients === []) {
            throw new InvalidArgumentException("The distribution list of {$countryName} is empty.");
        }
        if ($count === 0 && $email['skip_when_empty']) {
            $result['skipped'] = true;
            return $result;
        }
        $lang = self::language($email, $team);
        $tr = static fn (string $text, array $vars = []): string => self::tr($text, $lang, $vars);
        $subject = $email['subject'] . ' – ' . $tr($countryName) . ': '
            . ($count > 0 ? $tr('{n} device(s) need attention', ['n' => $count]) : $tr('all devices online'));
        [$text, $html] = $this->render($snapshot, $tr($countryName), $timezone, $lang, $now ?? time());

        foreach ($recipients as $to) {
            try {
                $this->deliver($to, $subject, $text, $html);
                $result['sent']++;
            } catch (RuntimeException $e) {
                $result['failed'][] = $to;
                $result['error'] = $e->getMessage();
            }
        }
        return $result;
    }

    /**
     * A short test email to check that sending works. Throws a RuntimeException
     * with the reason if it doesn't.
     */
    public function sendTest(string $to, string $lang): void
    {
        if (!self::validAddress($to)) {
            throw new InvalidArgumentException("'{$to}' is not a valid email address.");
        }
        $email = self::settings($this->config);
        self::assertServiceOn($email);
        $lang = in_array($lang, self::LANGUAGES, true) ? $lang : 'en';
        $title = (string) ($this->config['app_title'] ?? 'Equipment Status');
        $body = self::tr('This is a test email from {title}. Outage notifications can be sent from this server.', $lang, ['title' => self::tr($title, $lang)]);
        $html = '<p style="font-family:Arial,Helvetica,sans-serif;font-size:14px">' . self::h($body) . '</p>';
        $this->deliver($to, $email['subject'] . ' – ' . self::tr('Test email', $lang), $body . "\n", $html);
    }

    /**
     * @param array{rows: list<array<string, mixed>>, total: array<string, int>} $snapshot
     * @return array{0: string, 1: string} plain text and HTML body
     */
    private function render(array $snapshot, string $country, string $timezone, string $lang, int $now): array
    {
        $email = self::settings($this->config);
        $tr = static fn (string $text, array $vars = []): string => self::tr($text, $lang, $vars);
        $fmt = static fn (?int $ts): string => $ts === null ? $tr('never')
            : (new DateTimeImmutable('@' . $ts))->setTimezone(new DateTimeZone($timezone))->format('Y-m-d H:i');
        $labels = [EquipmentService::STATUS_OFFLINE => 'Offline', EquipmentService::STATUS_STALE => 'Stale', EquipmentService::STATUS_UNKNOWN => 'Unknown'];
        $colors = [EquipmentService::STATUS_OFFLINE => '#dc2626', EquipmentService::STATUS_STALE => '#d97706', EquipmentService::STATUS_UNKNOWN => '#64748b'];
        $t = $snapshot['total'];
        $pct = $t['total'] > 0 ? number_format($t['online'] / $t['total'] * 100, 1, $lang === 'de' ? ',' : '.', '') : '0' . ($lang === 'de' ? ',' : '.') . '0';
        $kpis = [
            [$tr('Total devices'), (string) $t['total']],
            [$tr('Online'), (string) $t['online']],
            [$tr('Offline'), (string) $t['offline']],
            [$tr('External Network'), (string) $t['external']],
            [$tr('No Status'), (string) $t['no_status']],
            [$tr('% Online'), $pct . '%'],
        ];
        $intro = $tr('Snapshot of {country} at {time}.', ['country' => $country, 'time' => $fmt($now) . ' (' . $timezone . ')']);
        $footer = $tr('You receive this email because you are on the outage notification list for {country}.', ['country' => $country]);
        $url = (string) $email['dashboard_url'];
        $heads = [$tr('Status'), $tr('Device'), $tr('IP address'), $tr('Location'), $tr('Firmware'), $tr('Last checked')];

        // Plain text
        $text = $intro . "\n\n" . implode("\n", array_map(static fn (array $k): string => "{$k[0]}: {$k[1]}", $kpis)) . "\n\n";
        $text .= $tr('Needs attention') . "\n" . str_repeat('-', 40) . "\n";
        if ($snapshot['rows'] === []) {
            $text .= $tr('All checked devices are online.') . "\n";
        }
        foreach ($snapshot['rows'] as $r) {
            $text .= sprintf("%-9s %s | %s | %s | %s | %s\n", $tr($labels[$r['status']]), $r['name'], $r['ip'], $r['site'], $r['firmware'] !== '' ? $r['firmware'] : '—', $fmt($r['last_checked']));
        }
        if ($url !== '') {
            $text .= "\n" . $tr('Open the dashboard') . ': ' . $url . "\n";
        }
        $text .= "\n-- \n" . $footer . "\n";

        // HTML (inline styles: most mail clients ignore <style>)
        $cell = 'padding:6px 10px;border-bottom:1px solid #e2e8f0;text-align:left;vertical-align:top';
        $html = '<!DOCTYPE html><html><body style="margin:0;padding:16px;background:#f8fafc;font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#0f172a">';
        $html .= '<h2 style="margin:0 0 4px">' . self::h((string) $email['subject'] . ' – ' . $country) . '</h2>';
        $html .= '<p style="margin:0 0 16px;color:#475569">' . self::h($intro) . '</p>';
        $html .= '<table cellspacing="0" cellpadding="0" style="border-collapse:separate;border-spacing:8px 0;margin:0 -8px 16px"><tr>';
        foreach ($kpis as [$label, $value]) {
            $html .= '<td style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px"><div style="font-size:20px;font-weight:bold">'
                . self::h($value) . '</div><div style="font-size:12px;color:#64748b">' . self::h($label) . '</div></td>';
        }
        $html .= '</tr></table>';
        $html .= '<h3 style="margin:0 0 8px">&#9888; ' . self::h($tr('Needs attention')) . '</h3>';
        if ($snapshot['rows'] === []) {
            $html .= '<p>' . self::h($tr('All checked devices are online.')) . '</p>';
        } else {
            $html .= '<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;background:#fff;border:1px solid #e2e8f0;width:100%"><thead><tr>';
            foreach ($heads as $head) {
                $html .= '<th style="' . $cell . ';background:#f1f5f9;font-size:12px">' . self::h($head) . '</th>';
            }
            $html .= '</tr></thead><tbody>';
            foreach ($snapshot['rows'] as $r) {
                $html .= '<tr><td style="' . $cell . '"><span style="color:#fff;background:' . $colors[$r['status']]
                    . ';border-radius:10px;padding:2px 8px;font-size:12px;white-space:nowrap">' . self::h($tr($labels[$r['status']])) . '</span></td>'
                    . '<td style="' . $cell . '">' . self::h((string) $r['name']) . '</td>'
                    . '<td style="' . $cell . ';font-family:Consolas,monospace">' . self::h((string) $r['ip']) . '</td>'
                    . '<td style="' . $cell . '">' . self::h((string) $r['site']) . '</td>'
                    . '<td style="' . $cell . ';font-family:Consolas,monospace">' . self::h((string) $r['firmware']) . '</td>'
                    . '<td style="' . $cell . ';white-space:nowrap">' . self::h($fmt($r['last_checked'])) . '</td></tr>';
            }
            $html .= '</tbody></table>';
        }
        if ($url !== '') {
            $html .= '<p style="margin:16px 0"><a href="' . self::h($url) . '" style="color:#2563eb">' . self::h($tr('Open the dashboard')) . ' &rarr;</a></p>';
        }
        $html .= '<p style="margin-top:24px;font-size:12px;color:#94a3b8">' . self::h($footer) . '</p></body></html>';

        return [$text, $html];
    }

    /**
     * @param array<string, mixed> $email
     */
    private static function assertServiceOn(array $email): void
    {
        if (!$email['service_enabled']) {
            throw new InvalidArgumentException('Email is turned off for this dashboard. Turn on Email service in Settings → Email and save.');
        }
    }

    private function deliver(string $to, string $subject, string $text, string $html): void
    {
        $email = self::settings($this->config);
        $from = (string) $email['from_address'];
        if (!self::validAddress($from)) {
            throw new InvalidArgumentException('Enter a From address for the outage emails.');
        }
        $boundary = 'b' . bin2hex(random_bytes(12));
        $name = trim((string) $email['from_name']);
        $headers = [
            'From: ' . ($name !== '' ? mb_encode_mimeheader($name, 'UTF-8', 'B') . ' <' . $from . '>' : $from),
            'MIME-Version: 1.0',
            'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
            'Auto-Submitted: auto-generated',
            'X-Mailer: Equipment Status dashboard',
        ];
        if (self::validAddress((string) $email['reply_to'])) {
            $headers[] = 'Reply-To: ' . $email['reply_to'];
        }
        $part = static fn (string $type, string $content): string => "--{$boundary}\r\n"
            . "Content-Type: {$type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
            . rtrim(chunk_split(base64_encode($content), 76, "\r\n")) . "\r\n";
        $body = $part('text/plain', $text) . $part('text/html', $html) . "--{$boundary}--\r\n";
        $sender = (string) $email['envelope_sender'];
        $sender = $sender !== '' && preg_match('/^[A-Za-z0-9._+-]+@[A-Za-z0-9.-]+$/', $sender) === 1 ? $sender : '';

        ($this->transport)($sender, $to, mb_encode_mimeheader($subject, 'UTF-8', 'B'), implode("\r\n", $headers), $body);
    }

    /**
     * Send through the configured SMTP server.
     */
    private function defaultTransport(string $sender, string $to, string $subject, string $headers, string $body): void
    {
        $email = self::settings($this->config);
        if ((string) $email['smtp_host'] === '') {
            throw new RuntimeException('No SMTP server is set. Enter it in Settings → Email.');
        }
        $password = '';
        if ($email['smtp_user'] !== '') {
            try {
                $password = ($this->passwords ?? throw new RuntimeException('no key'))
                    ->decrypt((string) $email['smtp_password_encrypted'], self::smtpContext($email));
            } catch (RuntimeException) {
                throw new RuntimeException('The saved SMTP password can’t be read. Enter it again in Settings → Email.');
            }
        }
        $domain = substr((string) strrchr((string) $email['from_address'], '@'), 1);
        $message = 'Date: ' . date(DATE_RFC2822) . "\r\n"
            . 'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . ($domain !== '' ? $domain : 'localhost') . ">\r\n"
            . 'To: ' . $to . "\r\n"
            . 'Subject: ' . $subject . "\r\n"
            . $headers . "\r\n\r\n" . $body;
        (new SmtpClient((string) $email['smtp_host'], (int) $email['smtp_port'], (string) $email['smtp_encryption'],
            (string) $email['smtp_user'], $password, (bool) $email['smtp_verify_certificate']))
            ->send($sender !== '' ? $sender : (string) $email['from_address'], $to, $message);
    }

    /**
     * @param array<string, scalar> $vars
     */
    private static function tr(string $text, string $lang, array $vars = []): string
    {
        $out = self::TEXT[$lang][$text] ?? ($lang === 'de' ? (['United States' => 'USA', 'Germany' => 'Deutschland', 'Equipment Status' => 'Gerätestatus'][$text] ?? $text) : $text);
        foreach ($vars as $k => $v) {
            $out = str_replace('{' . $k . '}', (string) $v, $out);
        }
        return $out;
    }

    private static function h(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
