<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;
use RuntimeException;

/** Bounded SSH reads with verified host keys and noninteractive authentication. */
class DiscoveryLog
{
    private const MAX_BYTES = 262144;
    private const SNAPSHOT_SECONDS = 5;

    public function __construct(private string $sshDirectory)
    {
    }

    /**
     * @param array<string, mixed> $device
     * @return array<string, mixed>
     */
    public static function settings(array $device): array
    {
        $out = [
            'log_enabled' => filter_var($device['log_enabled'] ?? false, FILTER_VALIDATE_BOOL),
            'ssh_user' => self::text($device['ssh_user'] ?? ''),
            'ssh_port' => $device['ssh_port'] ?? 22,
            'ssh_key' => self::text($device['ssh_key'] ?? ''),
            'ssh_auth' => $device['ssh_auth'] ?? (empty($device['ssh_key']) ? 'password' : 'key'),
            'log_path' => self::text($device['log_path'] ?? ''),
            'log_source' => $device['log_source'] ?? (empty($device['log_path']) ? 'journal' : 'file'),
            'log_service' => self::text($device['log_service'] ?? 'ndi-discovery.service'),
        ];
        $port = filter_var($out['ssh_port'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
        if ($port === false) {
            throw new InvalidArgumentException('SSH port must be a whole number from 1 to 65535.');
        }
        $out['ssh_port'] = $port;
        if (!in_array($out['ssh_auth'], ['key', 'password'], true)) {
            throw new InvalidArgumentException('SSH authentication must be password or key.');
        }
        if (!in_array($out['log_source'], ['file', 'journal'], true)) {
            throw new InvalidArgumentException('Discovery log source must be a log file or systemd journal.');
        }
        if ($out['log_service'] !== '' && (strlen($out['log_service']) > 255
            || preg_match('/^[a-zA-Z0-9_][a-zA-Z0-9_.@:-]*\.service$/D', $out['log_service']) !== 1)) {
            throw new InvalidArgumentException('Discovery service must be a systemd service unit name (e.g. ndi-discovery.service).');
        }
        if ($out['ssh_user'] !== '' && preg_match('/^[a-zA-Z_][a-zA-Z0-9_.-]{0,63}$/D', $out['ssh_user']) !== 1) {
            throw new InvalidArgumentException('SSH user must be a valid Linux user name.');
        }
        if ($out['ssh_key'] !== '' && preg_match('/^[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,99}$/D', $out['ssh_key']) !== 1) {
            throw new InvalidArgumentException('SSH key must be a file name inside the server-side data/ssh directory.');
        }
        if ($out['log_path'] !== '' && ($out['log_path'][0] !== '/' || strlen($out['log_path']) > 1024
            || preg_match('/[\x00-\x1F\x7F]/', $out['log_path']) === 1)) {
            throw new InvalidArgumentException('Discovery log path must be an absolute Linux file path without control characters.');
        }
        $sourceConfigured = $out['log_source'] === 'journal' ? $out['log_service'] !== '' : $out['log_path'] !== '';
        if ($out['log_enabled'] && ($out['ssh_user'] === '' || ($out['ssh_auth'] === 'key' && $out['ssh_key'] === '') || !$sourceConfigured)) {
            throw new InvalidArgumentException('Enable log viewing only after specifying an SSH user, log source and authentication details.');
        }
        return $out;
    }

    /** @param array<string, mixed> $device */
    public static function remoteCommand(array $device): string
    {
        $settings = self::settings($device);
        return $settings['log_source'] === 'journal'
            ? 'journalctl --quiet --no-pager --boot=0 --lines=200 --output=cat --unit=' . escapeshellarg($settings['log_service'])
            : 'tail -n 200 -- ' . escapeshellarg($settings['log_path']);
    }

    /**
     * Share one bounded SSH read between viewers without holding a database transaction.
     *
     * @param array<string, mixed> $device
     * @return array{text: string, truncated: bool}
     */
    public function readShared(Database $db, array $device): array
    {
        $settings = self::settings($device);
        if (!$settings['log_enabled']) {
            throw new InvalidArgumentException('Discovery server log viewing is not configured.');
        }
        $host = self::text($device['ip'] ?? '');
        if (!Inventory::isValidAddress($host) || str_starts_with($host, '-')) {
            throw new InvalidArgumentException('Invalid discovery server SSH host.');
        }
        $key = hash('sha256', $host);
        $fingerprint = hash('sha256', (string) json_encode([
            $host, $settings, $device['ssh_password_encrypted'] ?? '',
        ], JSON_THROW_ON_ERROR));
        $lock = @fopen(dirname($this->sshDirectory) . '/discovery-log-' . $key . '.lock', 'c');
        if ($lock === false) {
            throw new RuntimeException('Cannot lock discovery server log access.');
        }
        try {
            // SSH reads are limited to eight seconds; allow overlapping viewers to wait.
            $deadline = microtime(true) + 10;
            while (!flock($lock, LOCK_EX | LOCK_NB)) {
                if (microtime(true) >= $deadline) {
                    throw new RuntimeException('Timed out waiting for the discovery server log refresh.');
                }
                usleep(20000);
            }
            $name = 'discovery_log:' . $key;
            $snapshot = $db->stateRead($name);
            $age = microtime(true) - (float) ($snapshot['checked_at'] ?? 0);
            if (($snapshot['fingerprint'] ?? '') !== $fingerprint || $age < 0 || $age >= self::SNAPSHOT_SECONDS) {
                try {
                    $snapshot = ['log' => $this->read($device)];
                } catch (RuntimeException $e) {
                    // Share failures too, so additional viewers do not retry a failing SSH server.
                    $snapshot = ['error' => $e->getMessage()];
                }
                $snapshot += ['fingerprint' => $fingerprint, 'checked_at' => microtime(true)];
                $db->stateUpdate($name, static function (array &$stored) use ($snapshot): void {
                    $stored = $snapshot;
                });
            }
            if (isset($snapshot['error'])) {
                throw new RuntimeException((string) $snapshot['error']);
            }
            return $snapshot['log'];
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * @param array<string, mixed> $device
     * @return array{text: string, truncated: bool}
     */
    public function read(array $device): array
    {
        $settings = self::settings($device);
        if (!$settings['log_enabled']) {
            throw new InvalidArgumentException('Discovery server log viewing is not configured.');
        }
        $host = self::text($device['ip'] ?? '');
        if (!Inventory::isValidAddress($host) || str_starts_with($host, '-')) {
            throw new InvalidArgumentException('Invalid discovery server SSH host.');
        }
        if (!function_exists('proc_open')) {
            throw new RuntimeException('SSH log viewing requires PHP proc_open and the OpenSSH client.');
        }
        $passwordMode = $settings['ssh_auth'] === 'password';
        $password = $passwordMode
            ? (new SshPassword($this->sshDirectory . '/password.key'))->decrypt((string) ($device['ssh_password_encrypted'] ?? ''), $device)
            : null;
        $key = $passwordMode ? null : $this->file($settings['ssh_key']);
        $knownHosts = $this->file('known_hosts');
        $command = [
            '/usr/bin/ssh', '-F', '/dev/null', '-T', '-n', '-a', '-x',
            '-o', 'BatchMode=' . ($passwordMode ? 'no' : 'yes'), '-o', 'IdentitiesOnly=yes', '-o', 'IdentityAgent=none',
            '-o', 'PreferredAuthentications=' . ($passwordMode ? 'password' : 'publickey'),
            '-o', 'PasswordAuthentication=' . ($passwordMode ? 'yes' : 'no'),
            '-o', 'PubkeyAuthentication=' . ($passwordMode ? 'no' : 'yes'),
            '-o', 'NumberOfPasswordPrompts=1',
            '-o', 'KbdInteractiveAuthentication=no', '-o', 'StrictHostKeyChecking=yes',
            '-o', 'UserKnownHostsFile=' . $knownHosts, '-o', 'GlobalKnownHostsFile=/dev/null',
            '-o', 'UpdateHostKeys=no', '-o', 'VerifyHostKeyDNS=no',
            '-o', 'ControlMaster=no', '-o', 'ControlPath=none', '-o', 'ClearAllForwardings=yes',
            '-o', 'ConnectTimeout=5', '-o', 'ConnectionAttempts=1',
            '-o', 'ServerAliveInterval=2', '-o', 'ServerAliveCountMax=1',
            '-o', 'LogLevel=ERROR',
            '-p', (string) $settings['ssh_port'], '-l', $settings['ssh_user'],
        ];
        if ($key !== null) {
            array_push($command, '-i', $key);
        }
        array_push($command, '--', $host, self::remoteCommand($device));
        $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        if ($passwordMode) {
            // A private descriptor keeps the password out of process arguments and environment.
            $command = array_merge(['/usr/bin/sshpass', '-d', '3'], $command);
            $descriptors[3] = ['pipe', 'r'];
        }
        $startupError = '';
        set_error_handler(static function (int $severity, string $message) use (&$startupError): bool {
            $startupError = $message;
            return true;
        });
        try {
            $process = proc_open($command, $descriptors, $pipes);
        } catch (\Throwable $e) {
            $startupError = get_class($e) . ': ' . $e->getMessage();
            $process = false;
        } finally {
            restore_error_handler();
        }
        if (!is_resource($process)) {
            error_log('Equipment dashboard: SSH startup failed (' . PHP_SAPI . '): '
                . ($startupError !== '' ? $startupError : 'proc_open returned false without a PHP warning.'));
            throw new RuntimeException('Could not start the SSH client. '
                . ($passwordMode ? 'Password login requires /usr/bin/sshpass. ' : '')
                . 'Ask an administrator to check the PHP server error log for "SSH startup failed".');
        }
        fclose($pipes[0]);
        $text = '';
        $truncated = false;
        $exitCode = -1;
        $deadline = microtime(true) + 8;
        try {
            if ($passwordMode) {
                $expected = strlen($password) + 1;
                $written = @fwrite($pipes[3], $password . "\n");
                fclose($pipes[3]);
                unset($pipes[3], $password);
                if ($written !== $expected) {
                    throw new RuntimeException('Could not pass the password to the SSH client.');
                }
            }
            stream_set_blocking($pipes[1], false);
            stream_set_blocking($pipes[2], false);
            do {
                $chunk = stream_get_contents($pipes[1], 65536);
                $text .= $chunk === false ? '' : $chunk;
                if (strlen($text) > self::MAX_BYTES) {
                    $text = substr($text, -self::MAX_BYTES);
                    $truncated = true;
                }
                // Drain stderr without returning local paths or remote diagnostics to the browser.
                stream_get_contents($pipes[2], 65536);
                $status = proc_get_status($process);
                if (!$status['running'] && (int) $status['exitcode'] >= 0) {
                    $exitCode = (int) $status['exitcode'];
                }
                if (!$status['running'] && feof($pipes[1]) && feof($pipes[2])) {
                    break;
                }
                if (microtime(true) >= $deadline) {
                    throw new RuntimeException('SSH log read timed out. Check the server address, port and log source.');
                }
                usleep(10000);
            } while (true);
            if ($exitCode !== 0) {
                throw new RuntimeException('SSH log read failed. Check the SSH credentials, trusted host key, user and log file or journal permissions.');
            }
        } finally {
            if (isset($pipes[3]) && is_resource($pipes[3])) {
                fclose($pipes[3]);
            }
            if (proc_get_status($process)['running']) {
                proc_terminate($process, 9);
            }
            fclose($pipes[1]);
            fclose($pipes[2]);
            proc_close($process);
        }
        return ['text' => mb_convert_encoding($text, 'UTF-8', 'UTF-8'), 'truncated' => $truncated];
    }

    private static function text(mixed $value): string
    {
        return is_scalar($value) ? trim((string) $value) : '';
    }

    private function file(string $name): string
    {
        $directory = realpath($this->sshDirectory);
        $path = realpath($this->sshDirectory . '/' . $name);
        if ($directory === false || $path === false || dirname($path) !== $directory || !is_file($path) || !is_readable($path)) {
            throw new RuntimeException('Provision the required credential files and verified known_hosts file in the server-side data/ssh directory.');
        }
        return $path;
    }
}
