<?php

declare(strict_types=1);

namespace StatusDashboard;

use JsonException;

/**
 * Stores the inventory (locations, devices, latest firmware and PCs) in the
 * SQLite database, one table per list. The rest of the code works on a plain
 * data array (see emptyData()); update() loads it, lets the callback change it
 * and writes back only the changed rows, all in one write transaction, so
 * concurrent requests and the ping job cannot overwrite each other.
 */
class Store
{
    /** Other fields, including devices' explicit standalone ownership/team, persist in `extra` (JSON). */
    public const COLUMNS = [
        'sites'    => ['name', 'code', 'address', 'subnet', 'notes', 'team'],
        'devices'  => ['site_id', 'name', 'ip', 'type', 'model', 'firmware', 'notes', 'maintained',
                       'status', 'last_checked', 'last_online', 'latency_ms', 'photo'],
        'firmware' => ['manufacturer', 'model', 'approved', 'notes'],
        'pcs'      => ['name', 'ip', 'type', 'location', 'os', 'checked', 'checked_by', 'comments', 'team',
                       'status', 'last_checked', 'last_online', 'latency_ms', 'photo'],
    ];

    public function __construct(private readonly Database $db)
    {
    }

    /**
     * @return array{sites: list<array<string, mixed>>, devices: list<array<string, mixed>>, firmware: list<array<string, mixed>>, pcs: list<array<string, mixed>>, next_id: int}
     */
    public static function emptyData(): array
    {
        return ['sites' => [], 'devices' => [], 'firmware' => [], 'pcs' => [], 'next_id' => 1];
    }

    /**
     * Read the current inventory.
     *
     * @return array{sites: list<array<string, mixed>>, devices: list<array<string, mixed>>, firmware: list<array<string, mixed>>, pcs: list<array<string, mixed>>, next_id: int}
     */
    public function load(): array
    {
        return $this->db->transaction(fn (): array => $this->read(), false);
    }

    /**
     * Modify the inventory inside a write transaction. The callback receives
     * the data by reference; its return value is passed through.
     *
     * @template T
     * @param callable(array<string, mixed>&): T $callback
     * @return T
     */
    public function update(callable $callback)
    {
        return $this->db->transaction(function () use ($callback) {
            $before = $this->read();
            $data = $before;
            $result = $callback($data);
            $this->write($before, $data);
            return $result;
        });
    }

    /**
     * @return array{sites: list<array<string, mixed>>, devices: list<array<string, mixed>>, firmware: list<array<string, mixed>>, pcs: list<array<string, mixed>>, next_id: int}
     */
    private function read(): array
    {
        $data = self::emptyData();
        foreach (self::COLUMNS as $table => $columns) {
            foreach ($this->db->pdo->query("SELECT * FROM {$table} ORDER BY id") as $row) {
                $data[$table][] = self::toRecord($row, $columns);
            }
        }
        $next = $this->db->pdo->query("SELECT value FROM meta WHERE key = 'next_id'")->fetchColumn();
        $data['next_id'] = max(1, (int) $next);
        return $data;
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     */
    private function write(array $before, array $after): void
    {
        $pdo = $this->db->pdo;
        $maxId = 0;
        foreach (self::COLUMNS as $table => $columns) {
            $old = [];
            foreach ($before[$table] as $record) {
                $old[(int) $record['id']] = $record;
            }
            $new = [];
            foreach (array_values(is_array($after[$table] ?? null) ? $after[$table] : []) as $record) {
                $id = is_array($record) ? (int) ($record['id'] ?? 0) : 0;
                if ($id <= 0) {
                    continue;
                }
                $new[$id] = ['id' => $id] + $record;
                $maxId = max($maxId, $id);
            }

            $gone = array_diff_key($old, $new);
            if ($gone !== []) {
                $delete = $pdo->prepare("DELETE FROM {$table} WHERE id = ?");
                foreach (array_keys($gone) as $id) {
                    $delete->execute([$id]);
                }
            }

            $all = array_merge(['id'], $columns, ['extra']);
            $save = $pdo->prepare(sprintf(
                'INSERT INTO %s (%s) VALUES (%s) ON CONFLICT(id) DO UPDATE SET %s',
                $table,
                implode(', ', $all),
                implode(', ', array_fill(0, count($all), '?')),
                implode(', ', array_map(static fn (string $column): string => "{$column} = excluded.{$column}", array_merge($columns, ['extra'])))
            ));
            foreach ($new as $id => $record) {
                if (isset($old[$id]) && $old[$id] == $record) {
                    continue; // unchanged
                }
                $save->execute(self::toRow($record, $columns));
            }
        }

        $next = max(1, (int) ($after['next_id'] ?? 1), $maxId + 1);
        $pdo->prepare("INSERT OR REPLACE INTO meta (key, value) VALUES ('next_id', ?)")->execute([(string) $next]);
    }

    /**
     * @param array<string, mixed> $row
     * @param list<string> $columns
     * @return array<string, mixed>
     */
    private static function toRecord(array $row, array $columns): array
    {
        $record = ['id' => (int) $row['id']];
        foreach ($columns as $column) {
            $value = $row[$column];
            if ($column === 'latency_ms') {
                $record[$column] = $value === null ? null : (float) $value;
            } elseif ($column === 'site_id') {
                $record[$column] = (int) $value;
            } elseif ($value !== null) {
                $record[$column] = (string) $value; // NULL = field not set
            }
        }
        if ($row['extra'] !== null && $row['extra'] !== '') {
            try {
                $extra = json_decode((string) $row['extra'], true, 32, JSON_THROW_ON_ERROR);
                if (is_array($extra)) {
                    $record += $extra;
                }
            } catch (JsonException) {
                // ignore a damaged extra column
            }
        }
        return $record;
    }

    /**
     * @param array<string, mixed> $record
     * @param list<string> $columns
     * @return list<mixed>
     */
    private static function toRow(array $record, array $columns): array
    {
        $row = [(int) $record['id']];
        foreach ($columns as $column) {
            $value = $record[$column] ?? null;
            if ($column === 'latency_ms') {
                $row[] = is_numeric($value) ? (float) $value : null;
            } elseif ($column === 'site_id') {
                $row[] = (int) $value;
            } else {
                $row[] = $value === null ? null : (is_scalar($value) ? (string) $value : json_encode($value));
            }
        }
        $extra = array_diff_key($record, array_flip(array_merge(['id'], $columns)));
        $row[] = $extra === [] ? null : json_encode($extra, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return $row;
    }
}
