<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * Observed device checks, not time-based uptime. Missing checks remain gaps.
 */
class Telemetry
{
    private const RETENTION_SECONDS = 365 * 86400;

    public function __construct(private readonly Database $db)
    {
    }

    /** @return array<int, string> */
    public function deviceVersions(): array
    {
        $versions = [];
        foreach ($this->db->pdo->query('SELECT id, telemetry_version FROM devices') as $row) {
            $versions[(int) $row['id']] = (string) $row['telemetry_version'];
        }
        return $versions;
    }

    /**
     * Called inside the same Store transaction that applies the latest status.
     * The version also rejects deleted/recreated or changed-then-restored rows.
     *
     * @param array<string, mixed> $device
     * @param array<string, mixed> $result
     */
    public function record(array $device, string $version, array $result, int $checkedAt): bool
    {
        return $this->db->transaction(function () use ($device, $version, $result, $checkedAt): bool {
            $stmt = $this->db->pdo->prepare(
                'INSERT INTO device_samples (device_id, site_id, checked_at, status, latency_ms)
                 SELECT id, site_id, ?, ?, ? FROM devices WHERE id = ? AND telemetry_version = ?'
            );
            $online = (bool) $result['online'];
            $latency = $online && is_numeric($result['latency_ms'] ?? null) ? (float) $result['latency_ms'] : null;
            $stmt->execute([
                $checkedAt, $online ? 'online' : 'offline', $latency, (int) $device['id'], $version,
            ]);
            if ($stmt->rowCount() !== 1) {
                return false;
            }
            $year = (int) gmdate('Y', $checkedAt);
            if ($year >= (int) gmdate('Y') - 5) {
                $this->db->pdo->prepare(
                    'INSERT INTO device_annual_samples
                        (device_id, site_id, year, checks, online, offline, latency_sum, latency_count,
                         first_checked_at, last_checked_at)
                     SELECT device_id, site_id, ?, 1, ?, ?, ?, ?, checked_at, checked_at
                     FROM device_samples WHERE id = ?
                     ON CONFLICT(device_id, site_id, year) DO UPDATE SET
                        checks = checks + 1, online = online + excluded.online, offline = offline + excluded.offline,
                        latency_sum = latency_sum + excluded.latency_sum,
                        latency_count = latency_count + excluded.latency_count,
                        first_checked_at = MIN(first_checked_at, excluded.first_checked_at),
                        last_checked_at = MAX(last_checked_at, excluded.last_checked_at)'
                )->execute([
                    $year, (int) $online, (int) !$online, $latency ?? 0, $latency === null ? 0 : 1,
                    (int) $this->db->pdo->lastInsertId(),
                ]);
            }
            return true;
        });
    }

    public function prune(): void
    {
        $this->db->pdo->prepare('DELETE FROM device_samples WHERE checked_at < ?')
            ->execute([time() - self::RETENTION_SECONDS]);
        $this->db->pdo->prepare('DELETE FROM device_annual_samples WHERE year < ?')
            ->execute([(int) gmdate('Y') - 5]);
    }

    /**
     * Join the inventory restore transaction: overlapping IDs are new devices,
     * even when restored records happen to have identical field values.
     */
    public function clearForRestore(): void
    {
        $this->db->transaction(function (): void {
            $this->db->pdo->exec('DELETE FROM device_samples');
            $this->db->pdo->exec('DELETE FROM device_annual_samples');
            $this->db->pdo->exec('UPDATE devices SET telemetry_version = lower(hex(randomblob(16)))');
        });
    }

    /** @return array<int, list<array<string, int|float|null>>> */
    public function siteSnapshots(): array
    {
        return $this->db->transaction(function (): array {
            $this->prune();
            $snapshots = [];
            foreach ($this->db->pdo->query('SELECT id FROM sites') as $row) {
                $snapshots[(int) $row['id']] = [];
            }
            foreach ($this->annualRows('site_id') as $row) {
                $siteId = (int) $row['site_id'];
                if (isset($snapshots[$siteId])) {
                    $snapshots[$siteId][] = self::snapshot($row);
                }
            }
            return $snapshots;
        });
    }

    /** @return array<int, array<string, int|float|null>> */
    public function siteSummaries(): array
    {
        return $this->db->transaction(function (): array {
            $this->prune();
            $stmt = $this->db->pdo->prepare(
                'SELECT s.id, COUNT(t.id) AS checks,
                        COALESCE(SUM(t.status = \'online\'), 0) AS online,
                        COALESCE(SUM(t.status = \'offline\'), 0) AS offline,
                        AVG(CASE WHEN t.status = \'online\' THEN t.latency_ms END) AS avg_latency_ms
                 FROM sites s LEFT JOIN device_samples t ON t.site_id = s.id AND t.checked_at >= ?
                 GROUP BY s.id'
            );
            $stmt->execute([time() - self::RETENTION_SECONDS]);
            $summaries = [];
            foreach ($stmt as $row) {
                $summaries[(int) $row['id']] = self::stats($row);
            }
            return $summaries;
        });
    }

    /** @return array<int, list<array<string, int|float|null>>> */
    public function siteTrends(?int $now = null): array
    {
        $now ??= time();
        $today = intdiv($now, 86400) * 86400;
        $start = $today - 29 * 86400;
        $stmt = $this->db->pdo->prepare(
            'WITH daily AS (
                SELECT site_id, device_id, checked_at - checked_at % 86400 AS day,
                       status, latency_ms,
                       ROW_NUMBER() OVER (
                           PARTITION BY site_id, device_id, checked_at - checked_at % 86400
                           ORDER BY checked_at DESC, id DESC
                       ) AS latest
                FROM device_samples WHERE checked_at >= ? AND checked_at <= ?
             )
             SELECT site_id, day, COUNT(*) AS checks,
                    SUM(status = \'online\') AS online,
                    SUM(latest = 1 AND status = \'online\') AS online_devices,
                    SUM(latest = 1) AS checked_devices,
                    AVG(CASE WHEN status = \'online\' THEN latency_ms END) AS avg_latency_ms
             FROM daily GROUP BY site_id, day ORDER BY day'
        );
        $stmt->execute([$start, $now]);
        $days = [];
        foreach ($stmt as $row) {
            $days[(int) $row['site_id']][(int) $row['day']] = [
                'online_devices' => (int) $row['online_devices'],
                'online_pct' => 100 * (int) $row['online_devices'] / (int) $row['checked_devices'],
                'avg_latency_ms' => $row['avg_latency_ms'] === null ? null : (float) $row['avg_latency_ms'],
                'success_pct' => 100 * (int) $row['online'] / (int) $row['checks'],
            ];
        }
        $trends = [];
        foreach ($this->db->pdo->query('SELECT id FROM sites') as $site) {
            $id = (int) $site['id'];
            $trends[$id] = [];
            for ($day = $start; $day <= $today; $day += 86400) {
                $trends[$id][] = ['day' => $day] + ($days[$id][$day] ?? [
                    'online_devices' => null,
                    'online_pct' => null,
                    'avg_latency_ms' => null,
                    'success_pct' => null,
                ]);
            }
        }
        return $trends;
    }

    /** @return array<string, mixed>|null null means the device does not exist. */
    public function deviceHistory(int $deviceId): ?array
    {
        return $this->db->transaction(function () use ($deviceId): ?array {
            $this->prune();
            $exists = $this->db->pdo->prepare('SELECT 1 FROM devices WHERE id = ?');
            $exists->execute([$deviceId]);
            if ($exists->fetchColumn() === false) {
                return null;
            }
            $params = [$deviceId, time() - self::RETENTION_SECONDS];
            $stmt = $this->db->pdo->prepare(
                'SELECT COUNT(*) AS checks,
                        COALESCE(SUM(status = \'online\'), 0) AS online,
                        COALESCE(SUM(status = \'offline\'), 0) AS offline,
                        AVG(CASE WHEN status = \'online\' THEN latency_ms END) AS avg_latency_ms
                 FROM device_samples WHERE device_id = ? AND checked_at >= ?'
            );
            $stmt->execute($params);
            $stats = self::stats($stmt->fetch());

            $stmt = $this->db->pdo->prepare(
                'SELECT id, checked_at, status, latency_ms FROM device_samples
                 WHERE device_id = ? AND checked_at >= ? ORDER BY checked_at DESC, id DESC LIMIT 1000'
            );
            $stmt->execute($params);
            $samples = [];
            foreach (array_reverse($stmt->fetchAll()) as $row) {
                $samples[] = [
                    'id' => (int) $row['id'],
                    'checked_at' => (int) $row['checked_at'],
                    'status' => (string) $row['status'],
                    'latency_ms' => $row['latency_ms'] === null ? null : (float) $row['latency_ms'],
                ];
            }

            // Transitions retain the first observed offline check, with the next
            // online transition as recovery. No checks are invented across gaps.
            $stmt = $this->db->pdo->prepare(
                'WITH ordered AS (
                    SELECT id, checked_at, status,
                           LAG(status) OVER (ORDER BY checked_at, id) AS previous
                    FROM device_samples WHERE device_id = ? AND checked_at >= ?
                 ), transitions AS (
                    SELECT checked_at, status,
                           LEAD(checked_at) OVER (ORDER BY checked_at, id) AS recovered_at
                    FROM ordered WHERE previous IS NULL OR previous <> status
                 )
                 SELECT checked_at, recovered_at FROM transitions WHERE status = \'offline\' ORDER BY checked_at'
            );
            $stmt->execute($params);
            $outages = [];
            foreach ($stmt as $row) {
                $outages[] = [
                    'started_at' => (int) $row['checked_at'],
                    'recovered_at' => $row['recovered_at'] === null ? null : (int) $row['recovered_at'],
                ];
            }
            return ['samples' => $samples] + $stats + [
                'snapshots' => array_map(self::snapshot(...), $this->annualRows('device_id', $deviceId)),
                'outages' => $outages,
                'has_more' => $stats['checks'] > count($samples),
            ];
        });
    }

    /** @return list<array<string, mixed>> */
    private function annualRows(string $group, ?int $deviceId = null): array
    {
        $year = (int) gmdate('Y');
        $stmt = $this->db->pdo->prepare(
            "SELECT {$group}, year, SUM(checks) AS checks, SUM(online) AS online, SUM(offline) AS offline,
                    SUM(latency_sum) / NULLIF(SUM(latency_count), 0) AS avg_latency_ms,
                    MIN(first_checked_at) AS first_checked_at, MAX(last_checked_at) AS last_checked_at
             FROM device_annual_samples WHERE year >= ? AND year < ?"
            . ($deviceId === null ? '' : ' AND device_id = ?')
            . " GROUP BY {$group}, year ORDER BY year DESC"
        );
        $stmt->execute($deviceId === null ? [$year - 5, $year] : [$year - 5, $year, $deviceId]);
        return $stmt->fetchAll();
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, int|float|null>
     */
    private static function snapshot(array $row): array
    {
        return ['year' => (int) $row['year']] + self::stats($row) + [
            'first_checked_at' => (int) $row['first_checked_at'],
            'last_checked_at' => (int) $row['last_checked_at'],
        ];
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, int|float|null>
     */
    private static function stats(array $row): array
    {
        $checks = (int) $row['checks'];
        $online = (int) $row['online'];
        return [
            'checks' => $checks,
            'online' => $online,
            'offline' => (int) $row['offline'],
            'avg_latency_ms' => $row['avg_latency_ms'] === null ? null : (float) $row['avg_latency_ms'],
            'availability_pct' => $checks === 0 ? null : 100.0 * $online / $checks,
        ];
    }
}
