<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;

/**
 * Accounts for the admin backend (Settings page), stored in the `users` table
 * of the database with password hashes only. Every account is an administrator.
 */
class Users
{
    public const MIN_PASSWORD = 8;
    public const ROLES = ['admin', 'lead', 'user'];
    private const PHOTO_TYPES = [
        IMAGETYPE_JPEG => 'image/jpeg',
        IMAGETYPE_PNG => 'image/png',
        IMAGETYPE_GIF => 'image/gif',
        IMAGETYPE_WEBP => 'image/webp',
    ];

    public function __construct(private readonly Database $db)
    {
    }

    /**
     * @return list<array{username: string, created: string, role: string, photo_version: string, last_login: ?int}>
     */
    public function all(): array
    {
        $out = [];
        foreach ($this->db->pdo->query('SELECT users.username, users.created, users.role, users.last_login, COALESCE(user_profiles.photo_version, \'\') AS photo_version FROM users LEFT JOIN user_profiles ON user_profiles.username = users.username') as $user) {
            $out[] = [
                'username' => (string) $user['username'],
                'created' => (string) $user['created'],
                'role' => (string) $user['role'],
                'photo_version' => (string) $user['photo_version'],
                'last_login' => $user['last_login'] === null ? null : (int) $user['last_login'],
            ];
        }
        usort($out, static fn ($a, $b) => strnatcasecmp($a['username'], $b['username']));
        return $out;
    }

    public function isEmpty(): bool
    {
        return (int) $this->db->pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0;
    }

    public function recordLogin(string $username): void
    {
        $this->db->pdo->prepare('UPDATE users SET last_login = ? WHERE username = ?')
            ->execute([time(), trim($username)]);
    }

    public function exists(string $username): bool
    {
        return $this->find($username) !== null;
    }

    public function role(string $username): string
    {
        $stmt = $this->db->pdo->prepare('SELECT role FROM users WHERE username = ?');
        $stmt->execute([trim($username)]);
        $role = $stmt->fetchColumn();
        return is_string($role) && in_array($role, self::ROLES, true) ? $role : 'user';
    }

    /**
     * The stored user name if the password is right, otherwise null.
     */
    public function verify(string $username, string $password): ?string
    {
        $user = $this->find($username);
        // Verify against a dummy hash for unknown users so timing doesn't reveal them.
        $hash = $user !== null ? $user['password_hash'] : '$2y$10$ok5.BF.PDB0EqUKvV2O4qe8unwZ2ROq2fVEFEx5HnEmnzcRG50Vbu';
        if (!password_verify($password, $hash) || $user === null) {
            return null;
        }
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            $this->db->pdo->prepare('UPDATE users SET password_hash = ? WHERE username = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $user['username']]);
        }
        return $user['username'];
    }

    /**
     * Add an account. With $onlyIfEmpty the account is only created when there
     * are no accounts yet (first-run setup); returns false otherwise.
     */
    public function add(string $username, string $password, bool $onlyIfEmpty = false, string $role = 'user', bool $mustChangePassword = false): bool
    {
        $username = self::validName($username);
        self::validPassword($password);
        $role = self::validRole($role);
        $hash = password_hash($password, PASSWORD_DEFAULT);
        return $this->db->transaction(function () use ($username, $hash, $onlyIfEmpty, $role, $mustChangePassword): bool {
            if ($onlyIfEmpty && !$this->isEmpty()) {
                return false;
            }
            if ($this->find($username) !== null) {
                throw new InvalidArgumentException("A user named '{$username}' already exists.");
            }
            $this->db->pdo->prepare('INSERT INTO users (username, password_hash, created, role, must_change_password) VALUES (?, ?, ?, ?, ?)')
                ->execute([$username, $hash, date('c'), $role, (int) $mustChangePassword]);
            return true;
        });
    }

    public function addTemporary(string $username, string $role = 'user'): string
    {
        $password = rtrim(strtr(base64_encode(random_bytes(18)), '+/', '-_'), '=');
        $this->add($username, $password, false, $role, true);
        return $password;
    }

    public function mustChangePassword(string $username): bool
    {
        $stmt = $this->db->pdo->prepare('SELECT must_change_password FROM users WHERE username = ?');
        $stmt->execute([trim($username)]);
        return (bool) $stmt->fetchColumn();
    }

    public function changePassword(string $username, string $current, string $password): void
    {
        $this->db->transaction(function () use ($username, $current, $password): void {
            if ($this->verify($username, $current) === null) {
                throw new InvalidArgumentException('The current password is wrong.');
            }
            if ($this->mustChangePassword($username) && hash_equals($current, $password)) {
                throw new InvalidArgumentException('Choose a different password from your temporary password.');
            }
            $this->setPassword($username, $password);
        });
    }

    public function setRole(string $username, string $role): void
    {
        $username = trim($username);
        $role = self::validRole($role);
        $this->db->transaction(function () use ($username, $role): void {
            $current = $this->role($username);
            if (!$this->exists($username)) {
                throw new InvalidArgumentException('Unknown user.');
            }
            if ($current === 'admin' && $role !== 'admin'
                && (int) $this->db->pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() <= 1) {
                throw new InvalidArgumentException('The last Admin cannot be demoted.');
            }
            $this->db->pdo->prepare('UPDATE users SET role = ? WHERE username = ?')->execute([$role, $username]);
        });
    }

    public function setPassword(string $username, string $password): void
    {
        self::validPassword($password);
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->db->pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE username = ?');
        $stmt->execute([$hash, trim($username)]);
        if ($stmt->rowCount() === 0) {
            throw new InvalidArgumentException('Unknown user.');
        }
    }

    /**
     * @return array{photo_version: string, theme: string}
     */
    public function profile(string $username): array
    {
        $stmt = $this->db->pdo->prepare('SELECT photo_version, theme FROM user_profiles WHERE username = ?');
        $stmt->execute([trim($username)]);
        $profile = $stmt->fetch();
        return [
            'photo_version' => is_array($profile) ? (string) $profile['photo_version'] : '',
            'theme' => is_array($profile) && in_array($profile['theme'], self::THEMES, true) ? (string) $profile['theme'] : 'main',
        ];
    }

    private const THEMES = ['main', 'teams', 'tui', 'cmd', 'tricaster', 'win98', 'vista'];

    public function setTheme(string $username, string $theme): void
    {
        if (!in_array($theme, self::THEMES, true)) {
            throw new InvalidArgumentException('Choose a valid theme.');
        }
        $stmt = $this->db->pdo->prepare(<<<'SQL'
            INSERT INTO user_profiles (username, theme) VALUES (?, ?)
            ON CONFLICT(username) DO UPDATE SET theme = excluded.theme
            SQL);
        $stmt->execute([trim($username), $theme]);
    }

    /**
     * Validate and save an uploaded account photo.
     */
    public function setProfilePhoto(string $username, string $tmpFile, int $maxBytes): void
    {
        $size = (int) @filesize($tmpFile);
        if ($size <= 0) {
            throw new InvalidArgumentException('Please choose a photo to upload.');
        }
        if ($size > $maxBytes) {
            throw new InvalidArgumentException('The photo is too large.');
        }
        $info = @getimagesize($tmpFile);
        if ($info === false || !isset(self::PHOTO_TYPES[$info[2]]) || $info[0] < 1 || $info[1] < 1) {
            throw new InvalidArgumentException('The photo must be a JPEG, PNG, GIF or WebP image.');
        }
        $photo = @file_get_contents($tmpFile);
        if ($photo === false) {
            throw new \RuntimeException('Cannot read the uploaded photo.');
        }
        $stmt = $this->db->pdo->prepare(<<<'SQL'
            INSERT INTO user_profiles (username, photo, photo_mime, photo_version) VALUES (?, ?, ?, ?)
            ON CONFLICT(username) DO UPDATE SET photo = excluded.photo, photo_mime = excluded.photo_mime,
                photo_version = excluded.photo_version
            SQL);
        $stmt->bindValue(1, trim($username));
        $stmt->bindValue(2, $photo, \PDO::PARAM_LOB);
        $stmt->bindValue(3, self::PHOTO_TYPES[$info[2]]);
        $stmt->bindValue(4, bin2hex(random_bytes(8)));
        $stmt->execute();
    }

    /**
     * @return array{photo: string, mime: string}|null
     */
    public function profilePhoto(string $username): ?array
    {
        $stmt = $this->db->pdo->prepare('SELECT photo, photo_mime FROM user_profiles WHERE username = ?');
        $stmt->execute([trim($username)]);
        $row = $stmt->fetch();
        if (!is_array($row) || $row['photo'] === null) {
            return null;
        }
        $photo = is_resource($row['photo']) ? stream_get_contents($row['photo']) : $row['photo'];
        return is_string($photo) ? ['photo' => $photo, 'mime' => (string) $row['photo_mime']] : null;
    }

    public function deleteProfilePhoto(string $username): void
    {
        $this->db->pdo->prepare('DELETE FROM user_profiles WHERE username = ?')->execute([trim($username)]);
    }

    /**
     * Delete an account. The last account can't be deleted.
     */
    public function delete(string $username): void
    {
        $this->db->transaction(function () use ($username): void {
            if ($this->find($username) === null) {
                throw new InvalidArgumentException('Unknown user.');
            }
            if ((int) $this->db->pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() <= 1) {
                throw new InvalidArgumentException('The last user can’t be deleted.');
            }
            if ($this->role($username) === 'admin'
                && (int) $this->db->pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn() <= 1) {
                throw new InvalidArgumentException('The last Admin cannot be deleted.');
            }
            $this->db->pdo->prepare('DELETE FROM user_profiles WHERE username = ?')->execute([trim($username)]);
            $this->db->pdo->prepare('DELETE FROM users WHERE username = ?')->execute([trim($username)]);
        });
    }

    public static function validName(string $username): string
    {
        $username = trim($username);
        if (preg_match('/^[A-Za-z0-9._@-]{2,64}$/', $username) !== 1) {
            throw new InvalidArgumentException('User names have 2 to 64 letters, digits or . _ @ -');
        }
        return $username;
    }

    public static function validPassword(string $password): void
    {
        if (strlen($password) < self::MIN_PASSWORD || strlen($password) > 200) {
            throw new InvalidArgumentException('Passwords need at least ' . self::MIN_PASSWORD . ' characters.');
        }
    }

    public static function validRole(string $role): string
    {
        if (!in_array($role, self::ROLES, true)) {
            throw new InvalidArgumentException('Choose a valid user role.');
        }
        return $role;
    }

    /**
     * @return array{username: string, password_hash: string}|null
     */
    private function find(string $username): ?array
    {
        $stmt = $this->db->pdo->prepare('SELECT username, password_hash FROM users WHERE username = ?');
        $stmt->execute([trim($username)]);
        $row = $stmt->fetch();
        return is_array($row) ? ['username' => (string) $row['username'], 'password_hash' => (string) $row['password_hash']] : null;
    }
}
