<?php

declare(strict_types=1);

namespace StatusDashboard;

/** Remove network addresses from data sent to anonymous viewers. */
class AddressPrivacy
{
    public const MASK = '*******';

    public static function redact(mixed $value): mixed
    {
        if (is_array($value) || is_object($value)) {
            $result = [];
            foreach ($value as $key => $item) {
                $result[$key] = match ($key) {
                    'ip', 'subnet' => $item === '' || $item === null ? $item : self::MASK,
                    'web_url' => '',
                    'log_enabled' => false,
                    default => self::redact($item),
                };
            }
            return is_object($value) ? (object) $result : $result;
        }
        if (!is_string($value)) {
            return $value;
        }

        // Also cover addresses embedded in names, notes, URLs and error details.
        $value = preg_replace_callback(
            '/(?:[a-f0-9]{1,4}:|::)[a-f0-9:.]*(?:%[\w.-]+)?/i',
            static function (array $m): string {
                $candidate = $m[0];
                do {
                    $address = explode('%', $candidate, 2)[0];
                    if (filter_var($address, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
                        return self::MASK . substr($m[0], strlen($candidate));
                    }
                    $last = substr($candidate, -1);
                    $candidate = substr($candidate, 0, -1);
                } while ($candidate !== '' && ($last === '.' || $last === ':'));
                return $m[0];
            },
            $value
        );
        return preg_replace_callback(
            '/(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?!\d)/',
            static fn (array $m): string => filter_var($m[0], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false ? self::MASK : $m[0],
            $value
        );
    }
}
