<?php

declare(strict_types=1);

namespace StatusDashboard;

final class NetworkUsage
{
    private const RETENTION_HOURS = 30 * 24;

    /**
     * @param array<string, array{ip: string, online: bool, latency_ms: ?float}> $pings
     * @param array<string, mixed> $config
     */
    public static function record(Database $db, array $pings, array $config, string $effectiveMethod, ?int $now = null): void
    {
        if ($pings === []) {
            return;
        }
        $now ??= time();
        $ping = (array) ($config['ping'] ?? []);
        $count = max(1, (int) ($ping['count'] ?? 1));
        $ports = max(1, count((array) ($ping['tcp_ports'] ?? [80, 443])));
        $mode = (string) ($ping['method'] ?? 'auto');
        $sent = 0;
        $received = 0;

        foreach ($pings as $ip => $result) {
            if ($effectiveMethod === 'icmp') {
                $packetBytes = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 104 : 84;
                $sent += $count * $packetBytes;
                if (!empty($result['online'])) {
                    $received += $count * $packetBytes;
                }
                if ($mode === 'auto') {
                    $sent += $ports * 60;
                    if (!empty($result['online'])) {
                        $received += 60;
                    }
                }
            } else {
                $packetBytes = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? 80 : 60;
                $sent += $ports * $packetBytes;
                if (!empty($result['online'])) {
                    $received += $packetBytes;
                }
            }
        }

        self::updateBucket($db, $now, static function (array &$bucket) use ($pings, $sent, $received): void {
            $bucket['ping_hosts'] += count($pings);
            $bucket['ping_sent_bytes'] += $sent;
            $bucket['ping_received_bytes'] += $received;
        });
    }

    /**
     * @param array<string, mixed> $server
     * @param list<string> $responseHeaders
     */
    public static function recordHttp(Database $db, array $server, int $responseBytes, array $responseHeaders = [], ?int $now = null): void
    {
        $requestBytes = strlen((string) ($server['REQUEST_METHOD'] ?? 'GET'))
            + 1 + strlen((string) ($server['REQUEST_URI'] ?? '/'))
            + 1 + strlen((string) ($server['SERVER_PROTOCOL'] ?? 'HTTP/1.1')) + 2;
        foreach ($server as $key => $value) {
            if ((str_starts_with((string) $key, 'HTTP_') || in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH'], true)) && is_scalar($value)) {
                $name = str_replace('_', '-', (string) $key);
                $requestBytes += strlen($name) + 2 + strlen((string) $value) + 2;
            }
        }
        $requestBytes += max(0, (int) ($server['CONTENT_LENGTH'] ?? 0));
        $responseHeaderBytes = 0;
        foreach ($responseHeaders as $header) {
            $responseHeaderBytes += strlen($header) + 2;
        }
        $responseBytes = max(0, $responseBytes) + $responseHeaderBytes;
        self::updateBucket($db, $now ?? time(), static function (array &$bucket) use ($requestBytes, $responseBytes): void {
            $bucket['requests']++;
            $bucket['request_bytes'] += $requestBytes;
            $bucket['response_bytes'] += $responseBytes;
        });
    }

    /**
     * @return array{totals: array<string, array<string, int>>, hours: list<array<string, int>>}
     */
    public static function summary(Database $db, ?int $now = null): array
    {
        $now ??= time();
        $stored = $db->stateRead('traffic_usage');
        $currentHour = intdiv($now, 3600) * 3600;
        $hours = [];
        for ($offset = 167; $offset >= 0; $offset--) {
            $hour = $currentHour - $offset * 3600;
            $hours[] = ['hour' => $hour] + array_replace(self::emptyBucket(), (array) ($stored[(string) $hour] ?? []));
        }

        $totals = [];
        foreach (['24h' => 24, '7d' => 168] as $period => $count) {
            $total = ['requests' => 0, 'ping_hosts' => 0, 'in_bytes' => 0, 'out_bytes' => 0];
            foreach (array_slice($hours, -$count) as $bucket) {
                $total['requests'] += $bucket['requests'];
                $total['ping_hosts'] += $bucket['ping_hosts'];
                $total['in_bytes'] += $bucket['request_bytes'] + $bucket['ping_received_bytes'];
                $total['out_bytes'] += $bucket['response_bytes'] + $bucket['ping_sent_bytes'];
            }
            $totals[$period] = $total;
        }
        return ['totals' => $totals, 'hours' => $hours];
    }

    /** @return array<string, int> */
    private static function emptyBucket(): array
    {
        return [
            'requests' => 0, 'request_bytes' => 0, 'response_bytes' => 0,
            'ping_hosts' => 0, 'ping_sent_bytes' => 0, 'ping_received_bytes' => 0,
        ];
    }

    private static function updateBucket(Database $db, int $now, callable $update): void
    {
        $hour = intdiv($now, 3600) * 3600;
        $db->stateUpdate('traffic_usage', static function (array &$buckets) use ($hour, $update, $now): void {
            $buckets = array_filter(
                $buckets,
                static fn ($bucketHour): bool => (int) $bucketHour >= $now - self::RETENTION_HOURS * 3600
            , ARRAY_FILTER_USE_KEY);
            $key = (string) $hour;
            $buckets[$key] = array_replace(self::emptyBucket(), (array) ($buckets[$key] ?? []));
            $update($buckets[$key]);
        });
    }
}
