<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * Reachability check for devices. Hosts are checked in parallel so whole sites
 * can be checked from the web UI.
 *
 * Methods:
 *  - icmp: the system 'ping' command (needs the ping package and permission to
 *          send ICMP, which locked-down containers such as Pelican/Docker eggs
 *          often do not have).
 *  - tcp:  pure PHP TCP connect to common device ports. A host that accepts or
 *          actively refuses the connection is online. Works without any
 *          packages, root or extra capabilities.
 *  - auto: icmp when the system ping works, otherwise tcp. Hosts that do not
 *          answer ICMP are also tried with tcp (ICMP is often firewalled),
 *          then a read-only X32/M32 OSC /info query on UDP 10023.
 */
final class Pinger
{
    private const ECONNREFUSED = [111, 61, 10061]; // Linux, macOS/BSD, Windows

    private static ?bool $icmpWorks = null;

    /**
     * @param list<int> $tcpPorts
     */
    public function __construct(
        private int $timeoutSeconds = 2,
        private int $count = 1,
        private int $parallel = 32,
        private string $method = 'auto',
        private array $tcpPorts = [80, 443, 22, 23, 554, 8080, 135, 139, 445, 3389],
    ) {
        $this->timeoutSeconds = max(1, $this->timeoutSeconds);
        $this->count = max(1, $this->count);
        $this->parallel = max(1, $this->parallel);
        $this->method = in_array($this->method, ['auto', 'icmp', 'tcp'], true) ? $this->method : 'auto';
        $ports = array_values(array_unique(array_filter(
            array_map('intval', $this->tcpPorts),
            static fn (int $p): bool => $p > 0 && $p < 65536
        )));
        $this->tcpPorts = $ports === [] ? [80, 443] : $ports;
    }

    /** The method actually used: 'icmp' or 'tcp' (auto is resolved). */
    public function effectiveMethod(): string
    {
        if ($this->method === 'auto') {
            return $this->icmpAvailable() ? 'icmp' : 'tcp';
        }
        return $this->method;
    }

    /** True if the system ping command can be run and gets a reply from 127.0.0.1. */
    public function icmpAvailable(): bool
    {
        if (self::$icmpWorks === null) {
            self::$icmpWorks = false;
            if (function_exists('proc_open')) {
                $result = $this->icmpMany(['127.0.0.1'])['127.0.0.1'];
                self::$icmpWorks = $result['online'];
            }
        }
        return self::$icmpWorks;
    }

    /**
     * Ping one host. Same result shape as the Status-Check ping_api.py.
     *
     * @return array{ip: string, online: bool, latency_ms: ?float, error?: string}
     */
    public function ping(string $host): array
    {
        return $this->pingMany([$host])[$host];
    }

    /**
     * Ping several hosts in parallel.
     *
     * @param list<string> $hosts
     * @return array<string, array{ip: string, online: bool, latency_ms: ?float, error?: string}>
     */
    public function pingMany(array $hosts): array
    {
        $results = [];
        $queue = [];
        foreach (array_unique($hosts) as $host) {
            if (Inventory::isUndefinedAddress($host) || !Inventory::isValidAddress($host)) {
                $results[$host] = ['ip' => $host, 'online' => false, 'latency_ms' => null, 'error' => 'Invalid IP address or host name'];
            } else {
                $queue[] = $host;
            }
        }
        if ($queue === []) {
            return $results;
        }

        $method = $this->effectiveMethod();
        if ($method === 'tcp') {
            $icmp = $this->tcpMany($queue);
        } else {
            $icmp = $this->icmpMany($queue);
        }
        if ($this->method === 'auto' && $method !== 'tcp') {
            $retry = array_keys(array_filter($icmp, static fn (array $r): bool => !$r['online'] && !isset($r['error'])));
            if ($retry !== []) {
                foreach ($this->tcpMany($retry) as $host => $result) {
                    if ($result['online']) {
                        $icmp[$host] = $result;
                    }
                }
            }
        }
        if ($this->method === 'auto') {
            $retry = array_keys(array_filter($icmp, static fn (array $r): bool => !$r['online'] && !isset($r['error'])));
            foreach ($this->oscMany($retry) as $host => $result) {
                if ($result['online']) {
                    $icmp[$host] = $result;
                }
            }
        }
        return $results + $icmp;
    }

    /**
     * UDP connect/send alone is not proof of reachability: require an OSC /info reply.
     *
     * @param list<string> $hosts
     * @return array<string, array{ip: string, online: bool, latency_ms: ?float}>
     */
    private function oscMany(array $hosts): array
    {
        $results = [];
        foreach (array_chunk($hosts, $this->parallel) as $chunk) {
            $start = microtime(true);
            $deadline = $start + $this->timeoutSeconds;
            $sockets = [];
            $targets = [];
            foreach ($chunk as $host) {
                $results[$host] = ['ip' => $host, 'online' => false, 'latency_ms' => null];
                $address = str_contains($host, ':') ? "[{$host}]" : $host;
                $socket = @stream_socket_client("udp://{$address}:10023", $errno, $errstr, $this->timeoutSeconds);
                if ($socket === false) {
                    continue;
                }
                stream_set_blocking($socket, false);
                // OSC strings are NUL-terminated and padded to four-byte boundaries.
                if (@fwrite($socket, "/info\0\0\0,\0\0\0") !== 12) {
                    fclose($socket);
                    continue;
                }
                $key = (int) $socket;
                $sockets[$key] = $socket;
                $targets[$key] = $host;
            }
            while ($sockets !== [] && ($remaining = $deadline - microtime(true)) > 0) {
                $read = $sockets;
                $write = $except = null;
                $seconds = (int) $remaining;
                if (@stream_select($read, $write, $except, $seconds, (int) (($remaining - $seconds) * 1e6)) === false) {
                    break;
                }
                foreach ($read as $key => $socket) {
                    $packet = @fread($socket, 4096);
                    if (is_string($packet) && self::isOscInfo($packet)) {
                        $host = $targets[$key];
                        $results[$host] = ['ip' => $host, 'online' => true, 'latency_ms' => round((microtime(true) - $start) * 1000, 2)];
                    } elseif (is_string($packet) && $packet !== '') {
                        // Ignore unrelated or malformed datagrams until the deadline.
                        continue;
                    }
                    fclose($socket);
                    unset($sockets[$key]);
                }
            }
            foreach ($sockets as $socket) {
                fclose($socket);
            }
        }
        return $results;
    }

    private static function isOscInfo(string $packet): bool
    {
        if (!str_starts_with($packet, "/info\0\0\0,ssss\0\0\0") || strlen($packet) % 4 !== 0) {
            return false;
        }
        $offset = 16;
        for ($i = 0; $i < 4; $i++) {
            $end = strpos($packet, "\0", $offset);
            if ($end === false) {
                return false;
            }
            $next = $end + 4 - ($end % 4);
            if (substr($packet, $end, $next - $end) !== str_repeat("\0", $next - $end)) {
                return false;
            }
            $offset = $next;
        }
        return $offset === strlen($packet);
    }

    /**
     * @param list<string> $queue
     * @return array<string, array{ip: string, online: bool, latency_ms: ?float, error?: string}>
     */
    private function icmpMany(array $queue): array
    {
        $results = [];
        if (!function_exists('proc_open')) {
            foreach ($queue as $host) {
                $results[$host] = ['ip' => $host, 'online' => false, 'latency_ms' => null, 'error' => 'proc_open is disabled in PHP'];
            }
            return $results;
        }

        $running = [];
        while ($queue !== [] || $running !== []) {
            while ($queue !== [] && count($running) < $this->parallel) {
                $host = array_shift($queue);
                $process = proc_open($this->command($host), [1 => ['pipe', 'w'], 2 => ['redirect', 1]], $pipes);
                if (!is_resource($process)) {
                    $results[$host] = ['ip' => $host, 'online' => false, 'latency_ms' => null, 'error' => 'Could not run ping'];
                    continue;
                }
                stream_set_blocking($pipes[1], false);
                $running[$host] = [$process, $pipes[1], ''];
            }

            usleep(20000);
            foreach ($running as $host => [$process, $pipe, $output]) {
                $output .= (string) stream_get_contents($pipe);
                $status = proc_get_status($process);
                if ($status['running']) {
                    $running[$host][2] = $output;
                    continue;
                }
                $output .= (string) stream_get_contents($pipe);
                fclose($pipe);
                proc_close($process);
                unset($running[$host]);
                $results[$host] = $this->parse($host, (int) $status['exitcode'], $output);
            }
        }

        return $results;
    }

    /**
     * TCP connect check, in parallel: one non-blocking connect per host and port.
     *
     * @param list<string> $hosts
     * @return array<string, array{ip: string, online: bool, latency_ms: ?float, error?: string}>
     */
    private function tcpMany(array $hosts): array
    {
        $results = [];
        foreach (array_chunk($hosts, $this->parallel) as $chunk) {
            $results += $this->tcpBatch($chunk);
        }
        return $results;
    }

    /**
     * @param list<string> $hosts
     * @return array<string, array{ip: string, online: bool, latency_ms: ?float, error?: string}>
     */
    private function tcpBatch(array $hosts): array
    {
        $start = microtime(true);
        $deadline = $start + $this->timeoutSeconds;
        $sockets = [];   // key => socket
        $targets = [];   // key => [host, port]
        $online = [];    // host => latency ms
        $failed = [];    // host => list of ports that failed quickly (refused or unreachable)

        foreach ($hosts as $host) {
            $address = str_contains($host, ':') ? "[{$host}]" : $host;
            foreach ($this->tcpPorts as $port) {
                $socket = @stream_socket_client(
                    "tcp://{$address}:{$port}",
                    $errno,
                    $errstr,
                    $this->timeoutSeconds,
                    STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT
                );
                if ($socket === false) {
                    if (in_array($errno, self::ECONNREFUSED, true)) {
                        $online[$host] ??= round((microtime(true) - $start) * 1000, 2);
                    }
                    continue;
                }
                $key = count($targets);
                $sockets[$key] = $socket;
                $targets[$key] = [$host, $port];
            }
        }

        while ($sockets !== []) {
            $remaining = $deadline - microtime(true);
            if ($remaining <= 0) {
                break;
            }
            $write = $sockets;
            $except = $sockets;
            $read = null;
            $seconds = (int) $remaining;
            $ready = @stream_select($read, $write, $except, $seconds, (int) (($remaining - $seconds) * 1e6));
            if ($ready === false) {
                break;
            }
            if ($ready === 0) {
                continue;
            }
            $elapsed = round((microtime(true) - $start) * 1000, 2);
            foreach ($write + $except as $key => $_) {
                if (!isset($sockets[$key])) {
                    continue;
                }
                [$host, $port] = $targets[$key];
                if (@stream_socket_get_name($sockets[$key], true) !== false) {
                    $online[$host] ??= $elapsed;
                } else {
                    $failed[$host][] = $port;
                }
                fclose($sockets[$key]);
                unset($sockets[$key]);
            }
            // Stop early once every host has answered on some port.
            if (count($online) === count($hosts)) {
                break;
            }
        }
        foreach ($sockets as $socket) {
            fclose($socket);
        }

        // A quick failure is either "connection refused" (host is up) or
        // "host unreachable". Reconnect once to read the error code.
        foreach ($failed as $host => $ports) {
            if (isset($online[$host])) {
                continue;
            }
            $address = str_contains($host, ':') ? "[{$host}]" : $host;
            $t = microtime(true);
            $socket = @fsockopen($address, $ports[0], $errno, $errstr, 1);
            if ($socket !== false) {
                fclose($socket);
                $errno = 0;
            }
            if ($socket !== false || in_array($errno, self::ECONNREFUSED, true)) {
                $online[$host] = round((microtime(true) - $t) * 1000, 2);
            }
        }

        $results = [];
        foreach ($hosts as $host) {
            $results[$host] = isset($online[$host])
                ? ['ip' => $host, 'online' => true, 'latency_ms' => $online[$host]]
                : ['ip' => $host, 'online' => false, 'latency_ms' => null];
        }
        return $results;
    }

    private function command(string $host): string
    {
        $arg = escapeshellarg($host);
        if (PHP_OS_FAMILY === 'Windows') {
            return "ping -n {$this->count} -w " . ($this->timeoutSeconds * 1000) . " {$arg}";
        }
        if (PHP_OS_FAMILY === 'Darwin') {
            return "exec ping -c {$this->count} -t {$this->timeoutSeconds} {$arg}";
        }
        return "exec ping -n -c {$this->count} -W {$this->timeoutSeconds} {$arg}";
    }

    /**
     * @return array{ip: string, online: bool, latency_ms: ?float, error?: string}
     */
    private function parse(string $host, int $exitCode, string $output): array
    {
        // Windows returns 0 for "Destination host unreachable", so also require a TTL in the reply.
        $online = $exitCode === 0 && (PHP_OS_FAMILY !== 'Windows' || stripos($output, 'TTL=') !== false);
        if (!$online) {
            $result = ['ip' => $host, 'online' => false, 'latency_ms' => null];
            if (preg_match('/(unknown host|could not find host|name or service not known|no address associated with hostname|temporary failure in name resolution|operation not permitted|not found)/i', $output, $m)) {
                $result['error'] = $m[1];
            }
            return $result;
        }

        $times = [];
        if (preg_match_all('/time\s*[=<]\s*([\d.]+)\s*ms/i', $output, $m)) {
            $times = array_map('floatval', $m[1]);
        }
        $latency = $times === [] ? null : round(array_sum($times) / count($times), 2);

        return ['ip' => $host, 'online' => true, 'latency_ms' => $latency];
    }
}
