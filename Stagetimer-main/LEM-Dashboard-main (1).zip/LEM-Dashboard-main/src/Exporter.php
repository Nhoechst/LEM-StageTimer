<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * CSV and JSON exports. CSV files can be edited in Excel and imported again.
 */
class Exporter
{
    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public static function backup(array $data): array
    {
        $sites = [];
        foreach ($data['sites'] as $site) {
            $sites[(int) $site['id']] = (string) $site['name'];
        }
        $devices = [];
        foreach ($data['devices'] as $device) {
            $devices[] = ['site' => $sites[(int) $device['site_id']] ?? ''] + $device;
        }

        return [
            'format'      => 'equipment-status-dashboard',
            'version'     => 1,
            'exported_at' => date('c'),
            'sites'       => $data['sites'],
            'devices'     => $devices,
            'firmware'    => $data['firmware'],
            'pcs'         => $data['pcs'] ?? [],
        ];
    }

    /**
     * Header row and rows for a CSV export.
     *
     * @param array<string, mixed> $data
     * @param list<array<string, mixed>> $rows Device rows from EquipmentService::buildRows()
     * @return array{0: list<string>, 1: list<list<string>>}
     */
    public static function table(string $type, array $data, array $rows): array
    {
        $date = static fn (?int $ts) => $ts === null ? '' : date('Y-m-d H:i', $ts);

        switch ($type) {
            case 'sites':
                $summary = EquipmentService::summarise($rows, $data['sites'])['sites'];
                $out = [];
                foreach ($summary as $s) {
                    $site = $s['site'];
                    $out[] = [
                        (string) $site['name'], (string) ($site['code'] ?? ''), (string) ($site['address'] ?? ''),
                        (string) ($site['subnet'] ?? ''), (string) ($site['notes'] ?? ''), dashboard_team($site['team'] ?? ''),
                        (string) $s['total'], (string) $s['online'], (string) $s['offline'],
                    ];
                }
                return [['Name', 'Code', 'Address', 'Subnet', 'Notes', 'Team', 'Devices', 'Online', 'Offline'], $out];

            case 'firmware':
                $out = [];
                foreach ($data['firmware'] as $rule) {
                    $out[] = [(string) ($rule['manufacturer'] ?? ''), (string) $rule['model'], (string) $rule['approved'], (string) ($rule['notes'] ?? '')];
                }
                usort($out, static fn ($a, $b) => strnatcasecmp($a[0], $b[0]));
                return [['Manufacturer', 'Model', 'Latest Firmware', 'Notes'], $out];

            case 'pcs':
                $out = [];
                foreach ($rows as $r) {
                    $out[] = [
                        $r['name'], $r['type'], $r['ip'], $r['os'], $r['location'], $r['checked'], $r['checked_by'], $r['comments'],
                        dashboard_team($r['team']), $r['status'], $date($r['last_checked']), $date($r['last_online']),
                    ];
                }
                return [[
                    'PC Name', 'Type', 'IP Address', 'Operating System', 'Location', 'Last Checked', 'Checked By', 'Comments',
                    'Team', 'Online Status', 'Last Pinged', 'Last Online',
                ], $out];

            default:
                $out = [];
                foreach ($rows as $r) {
                    $out[] = [
                        $r['site'], $r['name'], $r['ip'], $r['type'], $r['model'], $r['firmware'],
                        $r['required_firmware'], $r['compliance'], ucfirst($r['stored_status']), $r['status'],
                        $date($r['last_checked']), $date($r['last_online']), $r['maintained'], $r['notes'],
                        $r['ownership'], Inventory::isStandalone($r) ? dashboard_team($r['team']) : '',
                    ];
                }
                return [[
                    'Location', 'Name', 'IP Address', 'Type', 'Model', 'Current Firmware', 'Latest Firmware', 'Compliance',
                    'Status', 'Dashboard Status', 'Last Checked', 'Last Online', 'Last Maintenance', 'Notes',
                    'Ownership', 'Team',
                ], $out];
        }
    }

    /**
     * Write CSV to a stream, protecting against spreadsheet formula injection.
     *
     * @param resource $out
     * @param list<string> $header
     * @param list<list<string>> $rows
     */
    public static function writeCsv($out, array $header, array $rows): void
    {
        fwrite($out, "\xEF\xBB\xBF"); // BOM so Excel opens the file as UTF-8
        fputcsv($out, $header, ',', '"', '');
        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'safeCell'], $row), ',', '"', '');
        }
    }

    public static function safeCell(string $value): string
    {
        if ($value !== '' && in_array($value[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
            return "'" . $value;
        }
        return $value;
    }
}
