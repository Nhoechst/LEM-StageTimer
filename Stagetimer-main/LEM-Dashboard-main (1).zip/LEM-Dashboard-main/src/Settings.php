<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;

/**
 * Settings edited on the admin Settings page and stored in the `settings` table of the database.
 * They override the defaults in dashboard_config(). Every value is validated
 * here, so a bad entry can't break the dashboard.
 */
class Settings
{
    public const PING_METHODS = ['auto', 'icmp', 'tcp'];
    public const RATE_BUCKETS = ['api', 'write', 'ping', 'login'];

    /** @return list<string> */
    public static function firmwareExemptions(mixed $models): array
    {
        if (!is_array($models) || !array_is_list($models) || count($models) > 1000) {
            throw new InvalidArgumentException('Firmware exemptions must be a list of at most 1000 models.');
        }
        $out = [];
        foreach ($models as $model) {
            if (!is_string($model) || trim($model) === '' || mb_strlen($model) > 200 || preg_match('/[\x00-\x1F\x7F]/', $model)) {
                throw new InvalidArgumentException('Each firmware exemption needs a model name of at most 200 characters.');
            }
            $model = (string) preg_replace('/\s+/u', ' ', trim($model));
            $out[mb_strtolower($model)] = $model;
        }
        return array_values($out);
    }

    public static function setFirmwareExemption(Database $db, string $model, bool $exempt, array $fallback = []): void
    {
        $model = self::firmwareExemptions([$model])[0];
        $db->transaction(static function () use ($db, $model, $exempt, $fallback): void {
            $models = self::firmwareExemptions(self::load($db)['firmware_exemptions'] ?? $fallback);
            $models = array_values(array_filter($models, static fn (string $item): bool => mb_strtolower($item) !== mb_strtolower($model)));
            if ($exempt) {
                $models[] = $model;
            }
            $models = self::firmwareExemptions($models);
            $statement = $db->pdo->prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
            $statement->execute(['firmware_exemptions', json_encode($models, JSON_THROW_ON_ERROR)]);
        });
    }

    /**
     * Stored overrides (empty if nothing was saved yet), from the `settings`
     * table: one row per setting, the value JSON encoded.
     *
     * @return array<string, mixed>
     */
    public static function load(Database $db): array
    {
        $out = [];
        foreach ($db->pdo->query('SELECT key, value FROM settings') as $row) {
            $out[(string) $row['key']] = json_decode((string) $row['value'], true);
        }
        return $out;
    }

    /**
     * Replace the stored overrides.
     *
     * @param array<string, mixed> $overrides
     */
    public static function save(Database $db, array $overrides, bool $preserveFirmwareExemptions = false): void
    {
        $db->transaction(static function () use ($db, $overrides, $preserveFirmwareExemptions): void {
            if ($preserveFirmwareExemptions) {
                $overrides['firmware_exemptions'] = self::load($db)['firmware_exemptions'] ?? $overrides['firmware_exemptions'] ?? [];
            }
            $db->pdo->exec('DELETE FROM settings');
            $insert = $db->pdo->prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
            foreach ($overrides as $key => $value) {
                $insert->execute([(string) $key, (string) json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)]);
            }
        });
    }

    /**
     * The current configuration in the shape used by the Settings form.
     *
     * @param array<string, mixed> $config
     * @return array<string, mixed>
     */
    public static function editable(array $config): array
    {
        $teams = [];
        foreach ((array) ($config['teams'] ?? []) as $key => $name) {
            $teams[] = ['key' => (string) $key, 'name' => (string) $name, 'timezone' => (string) (((array) ($config['team_timezones'] ?? []))[$key] ?? '')];
        }
        $ping = (array) ($config['ping'] ?? []);
        $limits = [];
        foreach (self::RATE_BUCKETS as $bucket) {
            $l = (array) (((array) ($config['rate_limits'] ?? []))[$bucket] ?? [0, 0]);
            $limits[$bucket] = [(int) ($l[0] ?? 0), (int) ($l[1] ?? 0)];
        }
        $header = [];
        foreach ((array) ($config['header_devices'] ?? []) as $d) {
            $header[] = ['name' => (string) ($d['name'] ?? ''), 'ip' => (string) ($d['ip'] ?? ''),
                'has_ssh_password' => !empty($d['ssh_password_encrypted'])] + DiscoveryLog::settings((array) $d);
        }

        return [
            'app_title'                     => (string) ($config['app_title'] ?? ''),
            'app_subtitle'                  => (string) ($config['app_subtitle'] ?? ''),
            'timezone'                      => (string) ($config['timezone'] ?? 'UTC'),
            'teams'                         => $teams,
            'header_devices'                => $header,
            'header_check_seconds'          => (int) ($config['header_check_seconds'] ?? 60),
            'stale_after_hours'             => (float) ($config['stale_after_hours'] ?? 0),
            'online_values'                 => array_values(array_map('strval', (array) ($config['online_values'] ?? []))),
            'corporate_networks'            => array_values(array_map('strval', (array) ($config['corporate_networks'] ?? []))),
            'external_networks'             => array_values(array_map('strval', (array) ($config['external_networks'] ?? []))),
            'maintenance_interval_days'     => (int) ($config['maintenance_interval_days'] ?? 90),
            'firmware_mode'                 => (string) ($config['firmware_mode'] ?? 'minimum'),
            'check_schedule'                => array_values(array_map('strval', (array) ($config['check_schedule'] ?? []))),
            'check_window_minutes'          => (int) ($config['check_window_minutes'] ?? 59),
            'manual_check_cooldown_seconds' => (int) ($config['manual_check_cooldown_seconds'] ?? 60),
            'ping'                          => [
                'method'          => (string) ($ping['method'] ?? 'auto'),
                'timeout_seconds' => (int) ($ping['timeout_seconds'] ?? 2),
                'count'           => (int) ($ping['count'] ?? 1),
                'parallel'        => (int) ($ping['parallel'] ?? 32),
                'tcp_ports'       => array_values(array_map('intval', (array) ($ping['tcp_ports'] ?? []))),
            ],
            'rate_limits'                   => $limits,
            'max_import_mb'                 => round((int) ($config['max_import_bytes'] ?? 0) / 1048576, 1),
            'max_photo_mb'                  => round((int) ($config['max_photo_bytes'] ?? 0) / 1048576, 1),
            'ping_api'                      => (bool) ($config['ping_api'] ?? true),
            'email'                         => self::editableEmail($config, array_column($teams, 'key')),
        ];
    }

    /**
     * Settings → Email: schedule, email service switch, SMTP server and each country's distribution list.
     *
     * @param array<string, mixed> $config
     * @param list<string> $teams
     * @return array<string, mixed>
     */
    private static function editableEmail(array $config, array $teams): array
    {
        $email = OutageMailer::settings($config);
        $recipients = [];
        $languages = [];
        foreach ($teams as $team) {
            $recipients[$team] = array_values(array_map('strval', (array) (((array) $email['recipients'])[$team] ?? [])));
            $languages[$team] = OutageMailer::language($email, $team);
        }
        return [
            'service_enabled' => (bool) $email['service_enabled'],
            'enabled'         => (bool) $email['enabled'],
            'days'            => array_values(array_map('strval', (array) $email['days'])),
            'times'           => array_values(array_map('strval', (array) $email['times'])),
            'window_minutes'  => (int) $email['window_minutes'],
            'from_address'    => (string) $email['from_address'],
            'from_name'       => (string) $email['from_name'],
            'reply_to'        => (string) $email['reply_to'],
            'envelope_sender' => (string) $email['envelope_sender'],
            'subject'         => (string) $email['subject'],
            'dashboard_url'   => (string) $email['dashboard_url'],
            'skip_when_empty' => (bool) $email['skip_when_empty'],
            'smtp_host'       => (string) $email['smtp_host'],
            'smtp_port'       => (int) $email['smtp_port'],
            'smtp_encryption' => (string) $email['smtp_encryption'],
            'smtp_user'       => (string) $email['smtp_user'],
            'has_smtp_password' => (string) $email['smtp_password_encrypted'] !== '', // the password itself never leaves the server
            'smtp_verify_certificate' => (bool) $email['smtp_verify_certificate'],
            'recipients'      => (object) $recipients,
            'languages'       => (object) $languages,
        ];
    }

    /**
     * Validate the Settings form and return the overrides to store.
     *
     * @param array<string, mixed> $in
     * @return array<string, mixed>
     */
    public static function validate(array $in, array $existing = [], ?SshPassword $passwords = null): array
    {
        $out = [];
        $out['app_title'] = self::text($in['app_title'] ?? '', 100);
        if ($out['app_title'] === '') {
            throw new InvalidArgumentException('The title is required.');
        }
        $out['app_subtitle'] = self::text($in['app_subtitle'] ?? '', 200);
        $out['timezone'] = self::timezone($in['timezone'] ?? '', 'Time zone');

        $out['teams'] = [];
        $out['team_timezones'] = [];
        foreach ((array) ($in['teams'] ?? []) as $team) {
            $key = strtolower(self::text(((array) $team)['key'] ?? '', 10));
            $name = self::text(((array) $team)['name'] ?? '', 60);
            if ($key === '' && $name === '') {
                continue;
            }
            if (preg_match('/^[a-z0-9]{1,10}$/', $key) !== 1) {
                throw new InvalidArgumentException('Country codes have 1 to 10 letters or digits (e.g. us, de).');
            }
            if ($name === '') {
                throw new InvalidArgumentException("Country '{$key}' needs a name.");
            }
            if (isset($out['teams'][$key])) {
                throw new InvalidArgumentException("Country code '{$key}' is used twice.");
            }
            $out['teams'][$key] = $name;
            $tz = self::text(((array) $team)['timezone'] ?? '', 64);
            if ($tz !== '') {
                $out['team_timezones'][$key] = self::timezone($tz, "Time zone of {$name}");
            }
        }
        if ($out['teams'] === []) {
            throw new InvalidArgumentException('At least one country is required.');
        }

        $out['header_devices'] = [];
        foreach ((array) ($in['header_devices'] ?? []) as $device) {
            $name = self::text(((array) $device)['name'] ?? '', 60);
            $ip = Inventory::extractHost(self::text(((array) $device)['ip'] ?? '', 253));
            if ($name === '' && $ip === '') {
                continue;
            }
            if ($name === '' || !Inventory::isValidAddress($ip)) {
                throw new InvalidArgumentException("Header status devices need a name and a valid IP address or host name ('{$name}').");
            }
            $entry = ['name' => $name, 'ip' => $ip] + DiscoveryLog::settings((array) $device);
            if ($entry['ssh_auth'] === 'password') {
                $password = $device['ssh_password'] ?? '';
                if (!is_string($password) || strlen($password) > 1024 || preg_match('/[\x00\r\n]/', $password)) {
                    throw new InvalidArgumentException('SSH password must be at most 1024 bytes without NUL or newline characters.');
                }
                if ($password !== '') {
                    if ($passwords === null) {
                        throw new \RuntimeException('SSH password storage is unavailable.');
                    }
                    $entry['ssh_password_encrypted'] = $passwords->encrypt($password, $entry);
                } else {
                    foreach ((array) ($existing['header_devices'] ?? []) as $old) {
                        if (($old['ip'] ?? '') === $ip && ($old['ssh_user'] ?? '') === $entry['ssh_user']
                            && (int) ($old['ssh_port'] ?? 22) === $entry['ssh_port'] && !empty($old['ssh_password_encrypted'])) {
                            $entry['ssh_password_encrypted'] = $old['ssh_password_encrypted'];
                            break;
                        }
                    }
                }
                if ($entry['log_enabled'] && empty($entry['ssh_password_encrypted'])) {
                    throw new InvalidArgumentException('Enter an SSH password for this server, user and port.');
                }
            }
            $out['header_devices'][] = $entry;
        }
        if (count($out['header_devices']) > 10) {
            throw new InvalidArgumentException('At most 10 header status devices.');
        }
        $out['header_check_seconds'] = self::int($in['header_check_seconds'] ?? 60, 30, 3600, 'Header status refresh');

        $out['stale_after_hours'] = self::number($in['stale_after_hours'] ?? 0, 0, 8760, 'Stale after (hours)');
        $out['online_values'] = self::words($in['online_values'] ?? [], 40);
        if ($out['online_values'] === []) {
            throw new InvalidArgumentException('At least one online status value is required.');
        }
        $out['corporate_networks'] = self::networks($in['corporate_networks'] ?? [], 'Corporate network');
        $out['external_networks'] = self::networks($in['external_networks'] ?? [], 'External networks');

        $out['maintenance_interval_days'] = self::int($in['maintenance_interval_days'] ?? 90, 1, 3650, 'Maintenance interval');
        $out['firmware_mode'] = ($in['firmware_mode'] ?? '') === 'exact' ? 'exact' : 'minimum';
        $out['firmware_exemptions'] = self::firmwareExemptions($existing['firmware_exemptions'] ?? []);

        $times = self::words($in['check_schedule'] ?? [], 10);
        $schedule = CheckGuard::normaliseTimes($times);
        if (count($schedule) !== count(array_unique($times)) || $schedule === []) {
            throw new InvalidArgumentException('Check times must be HH:MM (24 hour), e.g. 00:00, 12:00.');
        }
        $out['check_schedule'] = $schedule;
        $out['check_window_minutes'] = self::int($in['check_window_minutes'] ?? 59, 1, 720, 'Check window');
        $out['manual_check_cooldown_seconds'] = self::int($in['manual_check_cooldown_seconds'] ?? 60, 0, 86400, 'Manual check cooldown');

        $ping = (array) ($in['ping'] ?? []);
        $ports = [];
        foreach (self::words($ping['tcp_ports'] ?? [], 6) as $port) {
            $ports[] = self::int($port, 1, 65535, 'TCP port');
        }
        $out['ping'] = [
            'method'          => in_array($ping['method'] ?? '', self::PING_METHODS, true) ? (string) $ping['method'] : 'auto',
            'timeout_seconds' => self::int($ping['timeout_seconds'] ?? 2, 1, 30, 'Ping timeout'),
            'count'           => self::int($ping['count'] ?? 1, 1, 10, 'Pings per check'),
            'parallel'        => self::int($ping['parallel'] ?? 32, 1, 256, 'Parallel pings'),
            'tcp_ports'       => array_values(array_unique($ports)),
        ];
        if ($out['ping']['tcp_ports'] === []) {
            throw new InvalidArgumentException('At least one TCP port is required.');
        }

        $out['rate_limits'] = [];
        foreach (self::RATE_BUCKETS as $bucket) {
            $l = (array) (((array) ($in['rate_limits'] ?? []))[$bucket] ?? [0, 0]);
            $out['rate_limits'][$bucket] = [self::int($l[0] ?? 0, 0, 100000, 'Request limit'), self::int($l[1] ?? 0, 0, 86400, 'Request limit')];
        }
        if ($out['rate_limits']['login'][0] === 0 || $out['rate_limits']['login'][1] === 0) {
            throw new InvalidArgumentException('The login limit can’t be turned off.');
        }

        $out['max_import_bytes'] = (int) round(self::number($in['max_import_mb'] ?? 5, 0.1, 100, 'Largest import file') * 1048576);
        $out['max_photo_bytes'] = (int) round(self::number($in['max_photo_mb'] ?? 5, 0.1, 50, 'Largest photo') * 1048576);
        $out['ping_api'] = filter_var($in['ping_api'] ?? true, FILTER_VALIDATE_BOOL);
        $out['email'] = OutageMailer::validate(
            is_array($in['email'] ?? null) ? $in['email'] : OutageMailer::settings($existing),
            array_map('strval', array_keys($out['teams'])),
            $existing,
            $passwords
        );

        return $out;
    }

    private static function text(mixed $value, int $max): string
    {
        $value = is_scalar($value) ? trim((string) $value) : '';
        $value = (string) preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
        return mb_substr($value, 0, $max);
    }

    private static function timezone(mixed $value, string $label): string
    {
        $tz = self::text($value, 64);
        if (!in_array($tz, timezone_identifiers_list(), true)) {
            throw new InvalidArgumentException("{$label}: '{$tz}' is not a valid time zone (e.g. America/New_York).");
        }
        return $tz;
    }

    private static function int(mixed $value, int $min, int $max, string $label): int
    {
        if (!is_numeric($value) || (int) $value != $value || (int) $value < $min || (int) $value > $max) {
            throw new InvalidArgumentException("{$label} must be a whole number from {$min} to {$max}.");
        }
        return (int) $value;
    }

    private static function number(mixed $value, float $min, float $max, string $label): float
    {
        if (!is_numeric($value) || (float) $value < $min || (float) $value > $max) {
            throw new InvalidArgumentException("{$label} must be a number from {$min} to {$max}.");
        }
        return (float) $value;
    }

    /**
     * A list from an array or a comma / newline separated string.
     *
     * @return list<string>
     */
    private static function words(mixed $value, int $max): array
    {
        $items = is_array($value) ? $value : preg_split('/[\s,;]+/', is_scalar($value) ? (string) $value : '');
        $out = [];
        foreach ((array) $items as $item) {
            $item = self::text($item, $max);
            if ($item !== '' && !in_array($item, $out, true)) {
                $out[] = $item;
            }
        }
        return array_slice($out, 0, 100);
    }

    /**
     * @return list<string>
     */
    private static function networks(mixed $value, string $label): array
    {
        $out = [];
        foreach (self::words($value, 40) as $net) {
            $parts = explode('/', $net, 2);
            $ok = filter_var($parts[0], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
                && (!isset($parts[1]) || (ctype_digit($parts[1]) && (int) $parts[1] <= 32));
            if (!$ok) {
                throw new InvalidArgumentException("{$label}: '{$net}' is not a valid network (e.g. 192.168.0.0/16).");
            }
            $out[] = $net;
        }
        return $out;
    }
}
