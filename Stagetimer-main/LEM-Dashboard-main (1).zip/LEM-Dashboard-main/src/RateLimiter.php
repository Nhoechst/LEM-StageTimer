<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * Per-client request limits (fixed window), stored in the `rate_limits` table
 * of the database. Protects the API and the ping endpoint against floods
 * (scripts, stuck browser tabs, repeated clicks).
 */
class RateLimiter
{
    /** Upper bound on tracked clients, so the table can't grow without limit. */
    private const MAX_ENTRIES = 5000;

    public function __construct(private readonly Database $db)
    {
    }

    /**
     * Count one request of $client in $bucket.
     *
     * @return int 0 if allowed, otherwise the seconds until the client may retry.
     */
    public function hit(string $bucket, string $client, int $limit, int $windowSeconds, ?int $now = null): int
    {
        if ($limit <= 0 || $windowSeconds <= 0) {
            return 0;
        }
        $now ??= time();
        $key = $bucket . ':' . hash('sha256', $client);

        $pdo = $this->db->pdo;
        return $this->db->transaction(static function () use ($pdo, $key, $limit, $windowSeconds, $now): int {
            $pdo->prepare('DELETE FROM rate_limits WHERE reset <= ?')->execute([$now]);
            $stmt = $pdo->prepare('SELECT count, reset FROM rate_limits WHERE key = ?');
            $stmt->execute([$key]);
            $entry = $stmt->fetch();
            if (is_array($entry) && (int) $entry['count'] >= $limit) {
                return max(1, (int) $entry['reset'] - $now);
            }
            if (!is_array($entry)) {
                if ((int) $pdo->query('SELECT COUNT(*) FROM rate_limits')->fetchColumn() >= self::MAX_ENTRIES) {
                    // Table full of distinct clients: treat as a flood.
                    return $windowSeconds;
                }
                $pdo->prepare('INSERT INTO rate_limits (key, count, reset) VALUES (?, 1, ?)')->execute([$key, $now + $windowSeconds]);
            } else {
                $pdo->prepare('UPDATE rate_limits SET count = count + 1 WHERE key = ?')->execute([$key]);
            }
            return 0;
        });
    }
}
