<?php

declare(strict_types=1);

namespace StatusDashboard;

use PDO;
use RuntimeException;
use Throwable;

/**
 * All dashboard data lives in one SQLite database file (data/dashboard.db):
 * locations, devices, latest firmware, PCs, admin accounts, settings, rate
 * limits and the check schedule. Writes run in "BEGIN IMMEDIATE" transactions,
 * so concurrent requests and the ping job are serialised by SQLite itself.
 *
 * Data from older versions (data/*.json) is imported once, automatically.
 */
class Database
{
    private const SCHEMA_VERSION = 8;

    /** @var array<string, self> */
    private static array $open = [];

    private bool $inTransaction = false;

    private function __construct(public readonly PDO $pdo, private readonly string $file)
    {
    }

    /**
     * Open (and create or migrate if needed) the database. One connection per
     * file and request.
     *
     * @param string $legacyInventory Old inventory JSON file imported on first use.
     */
    public static function open(string $file, string $legacyInventory = ''): self
    {
        if (isset(self::$open[$file])) {
            return self::$open[$file];
        }
        if (!extension_loaded('pdo_sqlite')) {
            throw new RuntimeException('The PHP SQLite extension (pdo_sqlite) is required. Install php-sqlite3.');
        }
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new RuntimeException("Cannot create data directory {$dir}.");
        }
        try {
            $pdo = new PDO('sqlite:' . $file, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT            => 15, // wait up to 15 s for another writer
            ]);
            $pdo->exec('PRAGMA busy_timeout = 15000');
            if ((int) $pdo->query('PRAGMA user_version')->fetchColumn() < self::SCHEMA_VERSION) {
                $pdo->exec('PRAGMA journal_mode = WAL');
            }
            $pdo->exec('PRAGMA synchronous = NORMAL');
        } catch (\PDOException $e) {
            throw new RuntimeException("Cannot open the database {$file}. Check that the web server can write to {$dir}.", 0, $e);
        }
        $db = new self($pdo, $file);
        $db->migrate($legacyInventory);
        return self::$open[$file] = $db;
    }

    public function file(): string
    {
        return $this->file;
    }

    /**
     * Run $callback in a write transaction (or in a read transaction with
     * $write = false, for a consistent snapshot). Nested calls join the outer
     * transaction.
     *
     * @template T
     * @param callable(): T $callback
     * @return T
     */
    public function transaction(callable $callback, bool $write = true)
    {
        if ($this->inTransaction) {
            return $callback();
        }
        $this->pdo->exec($write ? 'BEGIN IMMEDIATE' : 'BEGIN');
        $this->inTransaction = true;
        try {
            $result = $callback();
            $this->pdo->exec('COMMIT');
            return $result;
        } catch (Throwable $e) {
            $this->pdo->exec('ROLLBACK');
            throw $e;
        } finally {
            $this->inTransaction = false;
        }
    }

    /**
     * Small state documents (check schedule, top bar status cache).
     *
     * @return array<mixed>
     */
    public function stateRead(string $name): array
    {
        $stmt = $this->pdo->prepare('SELECT data FROM state WHERE name = ?');
        $stmt->execute([$name]);
        $data = json_decode((string) $stmt->fetchColumn(), true);
        return is_array($data) ? $data : [];
    }

    /**
     * Modify a state document inside a write transaction.
     *
     * @template T
     * @param callable(array<mixed>&): T $callback receives the data by reference
     * @return T
     */
    public function stateUpdate(string $name, callable $callback)
    {
        return $this->transaction(function () use ($name, $callback) {
            $data = $this->stateRead($name);
            $result = $callback($data);
            $this->pdo->prepare('INSERT OR REPLACE INTO state (name, data) VALUES (?, ?)')
                ->execute([$name, (string) json_encode($data, JSON_UNESCAPED_SLASHES)]);
            return $result;
        });
    }

    private function migrate(string $legacyInventory): void
    {
        if ((int) $this->pdo->query('PRAGMA user_version')->fetchColumn() >= self::SCHEMA_VERSION) {
            return;
        }
        $dir = dirname($this->file);
        $legacyInventory = $legacyInventory !== '' ? $legacyInventory : $dir . '/inventory.json';
        $imported = [];
        $created = false;

        $this->transaction(function () use ($dir, $legacyInventory, &$imported, &$created): void {
            // Another request may have created the schema meanwhile.
            $version = (int) $this->pdo->query('PRAGMA user_version')->fetchColumn();
            if ($version >= self::SCHEMA_VERSION) {
                return;
            }
            if ($version === 0) {
                $created = true;
                $this->pdo->exec(self::schema());

                // Only a brand-new database imports legacy JSON, never a v1 upgrade.
                $inventory = self::readJson($legacyInventory);
                if ($inventory !== null) {
                    (new Store($this))->update(static function (array &$data) use ($inventory): void {
                        $data = $inventory + Store::emptyData();
                    });
                    $imported[] = $legacyInventory;
                }
                $settings = self::readJson($dir . '/settings.json');
                if ($settings !== null) {
                    Settings::save($this, $settings);
                    $imported[] = $dir . '/settings.json';
                }
                $users = self::readJson($dir . '/users.json');
                if ($users !== null) {
                    $insert = $this->pdo->prepare('INSERT OR IGNORE INTO users (username, password_hash, created) VALUES (?, ?, ?)');
                    foreach ((array) ($users['users'] ?? []) as $u) {
                        if (is_array($u) && ($u['username'] ?? '') !== '' && ($u['hash'] ?? '') !== '') {
                            $insert->execute([(string) $u['username'], (string) $u['hash'], (string) ($u['created'] ?? '')]);
                        }
                    }
                    $imported[] = $dir . '/users.json';
                }
                $checks = self::readJson($dir . '/checks.json');
                if ($checks !== null) {
                    $this->stateUpdate('checks', static function (array &$data) use ($checks): void {
                        $data = $checks;
                    });
                    $imported[] = $dir . '/checks.json';
                }
            }

            if ($version < 2) {
                $this->pdo->exec(<<<'SQL'
                ALTER TABLE devices ADD COLUMN telemetry_version TEXT NOT NULL DEFAULT '';
                UPDATE devices SET telemetry_version = lower(hex(randomblob(16)));
                CREATE TABLE device_samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id INTEGER NOT NULL,
                    site_id INTEGER NOT NULL,
                    checked_at INTEGER NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('online', 'offline')),
                    latency_ms REAL
                );
                CREATE INDEX device_samples_device_time ON device_samples (device_id, checked_at, id);
                CREATE INDEX device_samples_time ON device_samples (checked_at);
                CREATE INDEX device_samples_site_time ON device_samples (site_id, checked_at);
                CREATE TRIGGER devices_telemetry_insert AFTER INSERT ON devices BEGIN
                    UPDATE devices SET telemetry_version = lower(hex(randomblob(16))) WHERE id = NEW.id;
                END;
                CREATE TRIGGER devices_telemetry_update AFTER UPDATE ON devices
                WHEN NEW.telemetry_version = OLD.telemetry_version BEGIN
                    UPDATE devices SET telemetry_version = lower(hex(randomblob(16))) WHERE id = NEW.id;
                END;
                CREATE TRIGGER devices_telemetry_delete AFTER DELETE ON devices BEGIN
                    DELETE FROM device_samples WHERE device_id = OLD.id;
                END;
                CREATE TRIGGER sites_telemetry_delete AFTER DELETE ON sites BEGIN
                    DELETE FROM device_samples WHERE site_id = OLD.id;
                END;
                SQL);
            }
            if ($version < 3) {
                $this->pdo->exec(<<<'SQL'
                    CREATE TABLE device_annual_samples (
                        device_id INTEGER NOT NULL,
                        site_id INTEGER NOT NULL,
                        year INTEGER NOT NULL,
                        checks INTEGER NOT NULL,
                        online INTEGER NOT NULL,
                        offline INTEGER NOT NULL,
                        latency_sum REAL NOT NULL,
                        latency_count INTEGER NOT NULL,
                        first_checked_at INTEGER NOT NULL,
                        last_checked_at INTEGER NOT NULL,
                        PRIMARY KEY (device_id, site_id, year)
                    );
                    CREATE INDEX device_annual_samples_site_year ON device_annual_samples (site_id, year);
                    INSERT INTO device_annual_samples
                        (device_id, site_id, year, checks, online, offline, latency_sum, latency_count,
                         first_checked_at, last_checked_at)
                    SELECT device_id, site_id, CAST(strftime('%Y', checked_at, 'unixepoch') AS INTEGER),
                           COUNT(*), SUM(status = 'online'), SUM(status = 'offline'),
                           COALESCE(SUM(CASE WHEN status = 'online' THEN latency_ms END), 0),
                           COUNT(CASE WHEN status = 'online' THEN latency_ms END),
                           MIN(checked_at), MAX(checked_at)
                    FROM device_samples
                    WHERE CAST(strftime('%Y', checked_at, 'unixepoch') AS INTEGER)
                          >= CAST(strftime('%Y', 'now') AS INTEGER) - 5
                    GROUP BY device_id, site_id, CAST(strftime('%Y', checked_at, 'unixepoch') AS INTEGER);
                    CREATE TRIGGER devices_annual_samples_delete AFTER DELETE ON devices BEGIN
                        DELETE FROM device_annual_samples WHERE device_id = OLD.id;
                    END;
                    CREATE TRIGGER sites_annual_samples_delete AFTER DELETE ON sites BEGIN
                        DELETE FROM device_annual_samples WHERE site_id = OLD.id;
                    END;
                    SQL);
            }
            if ($version < 4) {
                $this->pdo->exec(<<<'SQL'
                    CREATE TABLE user_profiles (
                        username TEXT PRIMARY KEY COLLATE NOCASE REFERENCES users(username) ON DELETE CASCADE,
                        photo BLOB,
                        photo_mime TEXT NOT NULL DEFAULT '',
                        photo_version TEXT NOT NULL DEFAULT ''
                    );
                    SQL);
            }
            if ($version < 5) {
                $this->pdo->exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'admin'");
            }
            if ($version < 6) {
                $this->pdo->exec("ALTER TABLE user_profiles ADD COLUMN theme TEXT NOT NULL DEFAULT 'main'");
            }
            if ($version < 7) {
                $this->pdo->exec('ALTER TABLE users ADD COLUMN last_login INTEGER');
            }
            if ($version < 8) {
                $this->pdo->exec('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0');
            }
            $this->pdo->exec('PRAGMA user_version = ' . self::SCHEMA_VERSION);
        });

        // Keep the old files, renamed, so they aren't imported again.
        foreach ($imported as $file) {
            @rename($file, $file . '.migrated');
        }
        if ($created) {
            foreach (['header_status.json', 'ratelimit.json', 'inventory.json.lock'] as $cache) {
                @unlink($dir . '/' . $cache);
            }
        }
    }

    /**
     * @return array<mixed>|null
     */
    private static function readJson(string $file): ?array
    {
        if (!is_file($file)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($file), true);
        if (!is_array($data)) {
            throw new RuntimeException("Cannot import {$file}: it is not valid JSON.");
        }
        return $data;
    }

    private static function schema(): string
    {
        return <<<'SQL'
            CREATE TABLE IF NOT EXISTS meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sites (
                id      INTEGER PRIMARY KEY,
                name    TEXT,
                code    TEXT,
                address TEXT,
                subnet  TEXT,
                notes   TEXT,
                team    TEXT,
                extra   TEXT
            );
            CREATE TABLE IF NOT EXISTS devices (
                id           INTEGER PRIMARY KEY,
                site_id      INTEGER,
                name         TEXT,
                ip           TEXT,
                type         TEXT,
                model        TEXT,
                firmware     TEXT,
                notes        TEXT,
                maintained   TEXT,
                status       TEXT,
                last_checked TEXT,
                last_online  TEXT,
                latency_ms   REAL,
                photo        TEXT,
                extra        TEXT
            );
            CREATE INDEX IF NOT EXISTS devices_site ON devices (site_id);
            CREATE TABLE IF NOT EXISTS firmware (
                id           INTEGER PRIMARY KEY,
                manufacturer TEXT,
                model        TEXT,
                approved     TEXT,
                notes        TEXT,
                extra        TEXT
            );
            CREATE TABLE IF NOT EXISTS pcs (
                id           INTEGER PRIMARY KEY,
                name         TEXT,
                ip           TEXT,
                type         TEXT,
                location     TEXT,
                os           TEXT,
                checked      TEXT,
                checked_by   TEXT,
                comments     TEXT,
                team         TEXT,
                status       TEXT,
                last_checked TEXT,
                last_online  TEXT,
                latency_ms   REAL,
                photo        TEXT,
                extra        TEXT
            );
            CREATE TABLE IF NOT EXISTS users (
                username      TEXT PRIMARY KEY COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created       TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS rate_limits (
                key   TEXT PRIMARY KEY,
                count INTEGER NOT NULL,
                reset INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS rate_limits_reset ON rate_limits (reset);
            CREATE TABLE IF NOT EXISTS state (
                name TEXT PRIMARY KEY,
                data TEXT NOT NULL
            );
            SQL;
    }
}
