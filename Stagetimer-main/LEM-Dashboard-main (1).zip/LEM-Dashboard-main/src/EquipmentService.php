<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * Turns the stored inventory into dashboard rows (effective status and
 * firmware compliance) and builds summary statistics.
 */
class EquipmentService
{
    public const STATUS_ONLINE = 'online';
    public const STATUS_OFFLINE = 'offline';
    public const STATUS_EXTERNAL = 'external';
    public const STATUS_STALE = 'stale';
    public const STATUS_UNKNOWN = 'unknown';

    /** Index used by the status-N CSS classes. */
    public const STATUS_INDEX = [
        self::STATUS_ONLINE  => 0,
        self::STATUS_OFFLINE => 1,
        self::STATUS_STALE   => 2,
        self::STATUS_UNKNOWN => 3,
    ];

    public const FW_COMPLIANT = 'compliant';
    public const FW_NON_COMPLIANT = 'non_compliant';
    public const FW_UNKNOWN = 'unknown';

    /** @var array<string, mixed> */
    private array $config;

    /**
     * @param array<string, mixed> $config Full application configuration.
     */
    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * True if $ip is an IPv4 address inside one of the CIDR networks
     * (e.g. '192.0.0.0/8'; a bare address means /32). Host names never match.
     *
     * @param array<mixed> $networks
     */
    public static function isExternalIp(string $ip, array $networks): bool
    {
        $addr = ip2long(trim($ip));
        if ($addr === false || filter_var(trim($ip), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
            return false;
        }
        foreach ($networks as $network) {
            $parts = explode('/', trim((string) $network), 2);
            $base = ip2long($parts[0]);
            $bits = isset($parts[1]) ? (int) $parts[1] : 32;
            if ($base === false || $bits < 0 || $bits > 32 || (isset($parts[1]) && !ctype_digit($parts[1]))) {
                continue;
            }
            $mask = $bits === 0 ? 0 : (~0 << (32 - $bits)) & 0xFFFFFFFF;
            if (($addr & $mask) === ($base & $mask)) {
                return true;
            }
        }

        return false;
    }

    /**
     * True if $ip is outside the corporate network: inside one of `external_networks`,
     * or an IPv4 address outside every `corporate_networks` range (when any are set).
     * Such devices are shown as External Network and never pinged. Host names never match.
     *
     * @param array<string, mixed> $config
     */
    public static function isExternalAddress(string $ip, array $config): bool
    {
        if (Inventory::isUndefinedAddress($ip)) {
            return false;
        }
        if (self::isExternalIp($ip, (array) ($config['external_networks'] ?? []))) {
            return true;
        }
        $corporate = (array) ($config['corporate_networks'] ?? []);
        return $corporate !== []
            && filter_var(trim($ip), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false
            && !self::isExternalIp($ip, $corporate);
    }

    /**
     * Whether the equipment type identifies a Dante endpoint, regardless of its address.
     *
     * @param array<string, mixed> $device
     */
    public static function isDante(array $device): bool
    {
        return preg_match('/\bdante\b/i', (string) ($device['type'] ?? '')) === 1;
    }

    public static function isExternalRecord(array $record, array $config): bool
    {
        if (Inventory::isUndefinedAddress((string) ($record['ip'] ?? ''))) {
            return false;
        }
        // Standalone Dante endpoints live on isolated audio networks, not location CIDRs.
        return ($record['status'] ?? '') === Inventory::STATUS_EXTERNAL
            || (!Inventory::isStandalone($record) && self::isExternalAddress((string) ($record['ip'] ?? ''), $config));
    }

    /**
     * Build one row per device, sorted by site and name.
     *
     * @param array<string, mixed> $data Inventory data (see Store::emptyData()).
     * @return list<array<string, mixed>>
     */
    public function buildRows(array $data, ?int $now = null): array
    {
        $now ??= time();
        $staleSeconds = (int) round(((float) ($this->config['stale_after_hours'] ?? 0)) * 3600);

        $sites = [];
        foreach ($data['sites'] ?? [] as $site) {
            $sites[(int) $site['id']] = (string) $site['name'];
        }
        $rules = [];
        foreach ($data['firmware'] ?? [] as $rule) {
            $rules[self::key((string) $rule['model'])] = (string) $rule['approved'];
        }
        $exemptions = array_fill_keys(array_map([self::class, 'key'], (array) ($this->config['firmware_exemptions'] ?? [])), true);

        $rows = [];
        foreach ($data['devices'] ?? [] as $device) {
            $stored = (string) ($device['status'] ?? '');
            $lastChecked = self::timestamp((string) ($device['last_checked'] ?? ''));
            $status = self::effectiveStatus($device, $this->config, $staleSeconds, $now);

            $required = $rules[self::key((string) ($device['model'] ?? ''))] ?? null;
            $firmware = (string) ($device['firmware'] ?? '');
            $exempt = isset($exemptions[self::key((string) ($device['model'] ?? ''))]);

            $rows[] = [
                'id'                => (int) $device['id'],
                'site_id'           => (int) $device['site_id'],
                'site'              => Inventory::isStandalone($device) ? '' : ($sites[(int) $device['site_id']] ?? 'Unassigned'),
                'ownership'         => Inventory::isStandalone($device) ? 'standalone' : 'location',
                'team'              => (string) ($device['team'] ?? ''),
                'name'              => (string) ($device['name'] ?? ''),
                'ip'                => (string) ($device['ip'] ?? ''),
                'web_url'           => (string) ($device['web_url'] ?? ''),
                'type'              => (string) ($device['type'] ?? ''),
                'model'             => (string) ($device['model'] ?? ''),
                'firmware'          => $firmware,
                'notes'             => (string) ($device['notes'] ?? ''),
                'maintained'        => (string) ($device['maintained'] ?? ''),
                'photo'             => (string) ($device['photo'] ?? ''),
                'dante'             => self::isDante($device),
                'required_firmware' => $required ?? '',
                'firmware_exempt'   => $exempt,
                'compliance'        => $exempt ? self::FW_COMPLIANT : $this->compliance($firmware, $required),
                'stored_status'     => $stored,
                'status'            => $status,
                'last_checked'      => $lastChecked,
                'latency_ms'        => isset($device['latency_ms']) && $stored === Inventory::STATUS_ONLINE ? (float) $device['latency_ms'] : null,
                'last_online'       => self::timestamp((string) ($device['last_online'] ?? '')),
            ];
        }

        usort($rows, static fn ($a, $b) => strnatcasecmp($a['site'] . "\0" . $a['name'], $b['site'] . "\0" . $b['name']));

        return $rows;
    }

    /**
     * Rows for the PC Maintenance page (its own list of PCs, see Inventory::savePc()).
     *
     * @param array<string, mixed> $data
     * @return list<array<string, mixed>>
     */
    public function buildPcRows(array $data, ?int $now = null): array
    {
        $now ??= time();
        $staleSeconds = (int) round(((float) ($this->config['stale_after_hours'] ?? 0)) * 3600);
        $rows = [];
        foreach ($data['pcs'] ?? [] as $pc) {
            $stored = (string) ($pc['status'] ?? '');
            $row = ['id' => (int) $pc['id'], 'kind' => 'pc'];
            foreach (Inventory::PC_FIELDS as $field) {
                $row[$field] = (string) ($pc[$field] ?? '');
            }
            $row['web_url'] = (string) ($pc['web_url'] ?? '');
            $rows[] = $row + [
                'photo'         => (string) ($pc['photo'] ?? ''),
                'stored_status' => $stored,
                'status'        => self::effectiveStatus($pc, $this->config, $staleSeconds, $now),
                'last_checked'  => self::timestamp((string) ($pc['last_checked'] ?? '')),
                'latency_ms'    => isset($pc['latency_ms']) && $stored === Inventory::STATUS_ONLINE ? (float) $pc['latency_ms'] : null,
                'last_online'   => self::timestamp((string) ($pc['last_online'] ?? '')),
            ];
        }
        usort($rows, static fn ($a, $b) => strnatcasecmp($a['name'], $b['name']));

        return $rows;
    }

    /**
     * Status shown on the dashboard: external, unknown, stale, online or offline.
     *
     * @param array<string, mixed> $record a device or PC
     * @param array<string, mixed> $config
     */
    private static function effectiveStatus(array $record, array $config, int $staleSeconds, int $now): string
    {
        if (Inventory::isUndefinedAddress((string) ($record['ip'] ?? ''))) {
            return self::STATUS_UNKNOWN;
        }
        $stored = (string) ($record['status'] ?? '');
        $lastChecked = self::timestamp((string) ($record['last_checked'] ?? ''));
        if (self::isExternalRecord($record, $config)) {
            return self::STATUS_EXTERNAL;
        }
        if ($stored === '') {
            return self::STATUS_UNKNOWN;
        }
        if ($staleSeconds > 0 && ($lastChecked === null || $now - $lastChecked > $staleSeconds)) {
            return self::STATUS_STALE;
        }
        return $stored === Inventory::STATUS_ONLINE ? self::STATUS_ONLINE : self::STATUS_OFFLINE;
    }

    /**
     * Determine the firmware compliance of a device.
     */
    public function compliance(string $firmware, ?string $required): string
    {
        if ($required === null || trim($required) === '' || trim($firmware) === '') {
            return self::FW_UNKNOWN;
        }

        $current = self::normaliseVersion($firmware);
        $approved = preg_split('/[,;|]/', $required) ?: [];
        $mode = strtolower((string) ($this->config['firmware_mode'] ?? 'minimum'));
        $comparable = $current !== null;
        foreach ($approved as $rawVersion) {
            if (strcasecmp(trim($firmware), trim($rawVersion)) === 0 && trim($rawVersion) !== '') {
                return self::FW_COMPLIANT;
            }
            $version = self::normaliseVersion($rawVersion);
            if ($version === null) {
                $comparable = false;
                continue;
            }
            if ($current !== null && version_compare($current, $version, $mode === 'minimum' ? '>=' : '==')) {
                return self::FW_COMPLIANT;
            }
        }

        return $comparable ? self::FW_NON_COMPLIANT : self::FW_UNKNOWN;
    }

    /**
     * Build totals and per-site statistics. Every site is included, even
     * those without devices.
     *
     * @param list<array<string, mixed>> $rows
     * @param list<array<string, mixed>> $sites
     * @return array{total: array<string, int>, sites: array<int, array<string, mixed>>}
     */
    public static function summarise(array $rows, array $sites = []): array
    {
        $blank = [
            'total' => 0,
            self::STATUS_ONLINE => 0,
            self::STATUS_OFFLINE => 0,
            self::STATUS_STALE => 0,
            self::STATUS_UNKNOWN => 0,
            'fw_' . self::FW_COMPLIANT => 0,
            'fw_' . self::FW_NON_COMPLIANT => 0,
            'fw_' . self::FW_UNKNOWN => 0,
        ];

        $total = $blank;
        $bySite = [];
        foreach ($sites as $site) {
            $bySite[(int) $site['id']] = ['site' => $site] + $blank;
        }
        foreach ($rows as $row) {
            foreach (['total', $row['status'], 'fw_' . $row['compliance']] as $counter) {
                $total[$counter] = ($total[$counter] ?? 0) + 1;
            }
            if (Inventory::isStandalone($row)) {
                continue;
            }
            $id = (int) $row['site_id'];
            $bySite[$id] ??= ['site' => ['id' => $id, 'name' => $row['site']]] + $blank;
            foreach (['total', $row['status'], 'fw_' . $row['compliance']] as $counter) {
                $bySite[$id][$counter] = ($bySite[$id][$counter] ?? 0) + 1;
            }
        }
        uasort($bySite, static fn ($a, $b) => strnatcasecmp((string) $a['site']['name'], (string) $b['site']['name']));

        return ['total' => $total, 'sites' => $bySite];
    }

    private static function timestamp(string $value): ?int
    {
        if (trim($value) === '') {
            return null;
        }
        $ts = strtotime($value);
        return $ts === false ? null : $ts;
    }

    private static function key(string $model): string
    {
        return mb_strtolower((string) preg_replace('/\s+/u', ' ', trim($model)));
    }

    private static function normaliseVersion(string $version): ?string
    {
        $version = trim($version);
        if (preg_match('/^[vV]?\s*(\d+)$/D', $version, $single) === 1) {
            return ltrim($single[1], '0') ?: '0';
        }
        preg_match_all('/(?<![\w.])v?(\d+(?:[._]\d+)+)((?:-[\w.-]+)|(?:\s?(?:dev|alpha|beta|rc|a|b)[\w.]*))?(?![\w.])/i', $version, $matches, PREG_SET_ORDER);
        if (count($matches) !== 1) {
            return null;
        }
        $suffix = trim($matches[0][2] ?? '');
        if ($suffix !== '') {
            if (preg_match('/^-?(dev|alpha|beta|rc|a|b)\.?(\d*)$/iD', $suffix, $prerelease) !== 1) {
                return null;
            }
            $suffix = '-' . strtolower($prerelease[1]) . ($prerelease[2] !== '' ? (ltrim($prerelease[2], '0') ?: '0') : '');
        }
        $parts = array_map(static fn (string $part): string => ltrim($part, '0') ?: '0', preg_split('/[._]/', $matches[0][1]));
        while (count($parts) > 1 && end($parts) === '0') {
            array_pop($parts);
        }
        return implode('.', $parts) . $suffix;
    }
}
