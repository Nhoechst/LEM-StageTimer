<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;

/**
 * Add / edit / delete operations on the inventory data array.
 *
 * All methods work on the plain data array (see Store::emptyData()) so they
 * can be used inside Store::update() and tested without touching the disk.
 * Invalid input throws InvalidArgumentException with a user friendly message.
 */
class Inventory
{
    public const STATUS_ONLINE = 'online';
    public const STATUS_OFFLINE = 'offline';
    /** On an external network: not pinged by status checks, set manually or imported. */
    public const STATUS_EXTERNAL = 'external';

    public const SITE_FIELDS = ['name', 'code', 'address', 'subnet', 'notes', 'team'];
    public const DEVICE_FIELDS = ['name', 'ip', 'type', 'model', 'firmware', 'notes', 'maintained'];
    /** 'approved' holds the latest firmware version for the model. */
    public const FIRMWARE_FIELDS = ['manufacturer', 'model', 'approved', 'notes'];
    /**
     * PC Maintenance keeps its own list of PCs, separate from the Device Status
     * locations and devices. 'checked' is the date of the last maintenance check.
     */
    public const PC_FIELDS = ['name', 'ip', 'type', 'location', 'os', 'checked', 'checked_by', 'comments', 'team'];

    private const MAX_LENGTH = 500;

    public static function isStandalone(array $device): bool
    {
        return ($device['ownership'] ?? '') === 'standalone' && (int) ($device['site_id'] ?? 0) === 0;
    }

    /**
     * Create (no id) or update (with id) a site.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $input
     */
    public static function saveSite(array &$data, array $input): int
    {
        $id = (int) ($input['id'] ?? 0);
        $site = self::clean($input, self::SITE_FIELDS);
        if ($site['name'] === '') {
            throw new InvalidArgumentException('Location name is required.');
        }
        $existing = self::findSiteByName($data, $site['name']);
        if ($existing !== null && (int) $existing['id'] !== $id) {
            throw new InvalidArgumentException("A location named '{$site['name']}' already exists.");
        }
        if ($site['team'] === '') {
            unset($site['team']); // keep the current team (shown as the default team if none)
        }

        return self::upsert($data, 'sites', $id, $site);
    }

    /**
     * Delete a site and every device assigned to it.
     *
     * @param array<string, mixed> $data
     */
    public static function deleteSite(array &$data, int $id): void
    {
        self::requireRecord($data, 'sites', $id);
        $data['sites'] = array_values(array_filter($data['sites'], static fn ($s) => (int) $s['id'] !== $id));
        $data['devices'] = array_values(array_filter($data['devices'], static fn ($d) => (int) $d['site_id'] !== $id));
    }

    /**
     * Create or update a device.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $input
     * @param list<string> $onlineValues
     */
    public static function saveDevice(array &$data, array $input, array $onlineValues = ['online'], ?string $now = null): int
    {
        $id = (int) ($input['id'] ?? 0);
        $device = self::clean($input, self::DEVICE_FIELDS);
        $device['site_id'] = (int) ($input['site_id'] ?? 0);
        $previous = $id > 0 ? self::requireRecord($data, 'devices', $id) : [];
        $ownership = (string) ($input['ownership'] ?? $previous['ownership'] ?? 'location');
        if (!in_array($ownership, ['location', 'standalone'], true)) {
            throw new InvalidArgumentException('Invalid device ownership.');
        }
        $device['ownership'] = $ownership;
        if ($id > 0 && self::isStandalone($previous) !== self::isStandalone($device)) {
            throw new InvalidArgumentException('Device ownership cannot be changed.');
        }
        if ($ownership === 'standalone') {
            if ($device['site_id'] !== 0 || !EquipmentService::isDante($device)) {
                throw new InvalidArgumentException('Standalone devices must have type Dante and no location.');
            }
            $device['team'] = self::clean($input + ['team' => $previous['team'] ?? ''], ['team'])['team'];
        }
        $address = $device['ip'];
        $device['ip'] = self::extractHost($device['ip']);
        $webUrl = self::webUrl($address, $device['ip']);
        if ($webUrl === '' && is_scalar($input['web_url'] ?? null)) {
            $webUrl = self::webUrl(self::clean(['url' => $input['web_url']], ['url'])['url'], $device['ip']);
        }
        $device['web_url'] = $webUrl;
        $device['maintained'] = self::normaliseDate($device['maintained']);

        if ($device['name'] === '') {
            throw new InvalidArgumentException('Device name is required.');
        }
        if ($ownership !== 'standalone' && self::findRecord($data, 'sites', $device['site_id']) === null) {
            throw new InvalidArgumentException('Please choose a valid location for the device.');
        }
        if ($device['ip'] !== '' && !self::isValidAddress($device['ip'])) {
            throw new InvalidArgumentException("'{$device['ip']}' is not a valid IP address or host name.");
        }
        if ($device['ip'] !== '') {
            foreach ($data['devices'] as $other) {
                if ((int) $other['id'] !== $id && (int) $other['site_id'] === $device['site_id']
                    && ($ownership !== 'standalone' || (string) ($other['team'] ?? '') === $device['team'])
                    && strcasecmp((string) $other['ip'], $device['ip']) === 0) {
                    throw new InvalidArgumentException($ownership === 'standalone'
                        ? "Another standalone device in this team already uses {$device['ip']}."
                        : "Another device at this location already uses {$device['ip']}.");
                }
            }
        }

        $sameAddress = $ownership !== 'standalone' || strcasecmp((string) ($previous['ip'] ?? ''), $device['ip']) === 0;
        $device += [
            'status'       => $sameAddress ? (string) ($previous['status'] ?? '') : '',
            'last_checked' => $sameAddress ? (string) ($previous['last_checked'] ?? '') : '',
            'last_online'  => $sameAddress ? (string) ($previous['last_online'] ?? '') : '',
            'latency_ms'   => $sameAddress ? ($previous['latency_ms'] ?? null) : null,
            'photo'        => (string) ($previous['photo'] ?? ''), // changed only by setPhoto()
        ];

        if (array_key_exists('status', $input)) {
            $status = self::normaliseStatus((string) $input['status'], $onlineValues);
            if ($status !== $device['status']) {
                self::applyStatus($device, $status, $now ?? date('c'));
            }
        }

        return self::upsert($data, 'devices', $id, $device);
    }

    /**
     * Record a status result on a device (used by manual edits, imports and the ping job).
     *
     * @param array<string, mixed> $device
     */
    public static function applyStatus(array &$device, string $status, string $checkedAt, ?float $latencyMs = null): void
    {
        $device['status'] = $status;
        $device['latency_ms'] = $status === self::STATUS_ONLINE ? $latencyMs : null;
        $device['last_checked'] = $status === '' ? '' : $checkedAt;
        if ($status === self::STATUS_ONLINE) {
            $device['last_online'] = $checkedAt;
        }
    }

    /**
     * Set (or clear with '') the photo file name of a device (or of a PC with
     * $collection = 'pcs'). Returns the previous one.
     *
     * @param array<string, mixed> $data
     */
    public static function setPhoto(array &$data, int $id, string $photo, string $collection = 'devices'): string
    {
        self::requireRecord($data, $collection, $id);
        foreach ($data[$collection] as &$device) {
            if ((int) $device['id'] === $id) {
                $previous = (string) ($device['photo'] ?? '');
                $device['photo'] = $photo;
                return $previous;
            }
        }
        return '';
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function deleteDevice(array &$data, int $id): void
    {
        self::requireRecord($data, 'devices', $id);
        $data['devices'] = array_values(array_filter($data['devices'], static fn ($d) => (int) $d['id'] !== $id));
    }

    /**
     * Create or update a PC on the PC Maintenance list.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $input
     */
    public static function savePc(array &$data, array $input): int
    {
        $id = (int) ($input['id'] ?? 0);
        $pc = self::clean($input, self::PC_FIELDS);
        $address = $pc['ip'];
        $pc['ip'] = self::extractHost($pc['ip']);
        $webUrl = self::webUrl($address, $pc['ip']);
        if ($webUrl === '' && is_scalar($input['web_url'] ?? null)) {
            $webUrl = self::webUrl(self::clean(['url' => $input['web_url']], ['url'])['url'], $pc['ip']);
        }
        $pc['web_url'] = $webUrl;
        $pc['checked'] = self::normaliseDate($pc['checked']);

        if ($pc['name'] === '') {
            throw new InvalidArgumentException('PC name is required.');
        }
        if ($pc['ip'] !== '' && !self::isValidAddress($pc['ip'])) {
            throw new InvalidArgumentException("'{$pc['ip']}' is not a valid IP address or host name.");
        }
        $previous = $id > 0 ? self::requireRecord($data, 'pcs', $id) : [];
        if ($pc['team'] === '') {
            $pc['team'] = (string) ($previous['team'] ?? '');
        }
        foreach ($data['pcs'] as $other) {
            if ((int) $other['id'] === $id || (string) ($other['team'] ?? '') !== $pc['team']) {
                continue;
            }
            if (strcasecmp(trim((string) $other['name']), $pc['name']) === 0) {
                throw new InvalidArgumentException("A PC named '{$pc['name']}' already exists.");
            }
            if ($pc['ip'] !== '' && strcasecmp((string) ($other['ip'] ?? ''), $pc['ip']) === 0) {
                throw new InvalidArgumentException("Another PC already uses {$pc['ip']}.");
            }
        }

        // A new address has not been checked yet.
        $sameIp = strcasecmp((string) ($previous['ip'] ?? ''), $pc['ip']) === 0;
        $pc += [
            'status'       => $sameIp ? (string) ($previous['status'] ?? '') : '',
            'last_checked' => $sameIp ? (string) ($previous['last_checked'] ?? '') : '',
            'last_online'  => $sameIp ? (string) ($previous['last_online'] ?? '') : '',
            'latency_ms'   => $sameIp ? ($previous['latency_ms'] ?? null) : null,
            'photo'        => (string) ($previous['photo'] ?? ''), // changed only by setPhoto()
        ];

        return self::upsert($data, 'pcs', $id, $pc);
    }

    /**
     * Record a completed maintenance check on a PC (date, who checked it and comments).
     *
     * @param array<string, mixed> $data
     */
    public static function completePcCheck(array &$data, int $id, string $checkedBy, string $comments, string $date): void
    {
        $pc = self::requireRecord($data, 'pcs', $id);
        $input = self::clean(['checked_by' => $checkedBy, 'comments' => $comments], ['checked_by', 'comments']);
        if ($input['checked_by'] === '') {
            throw new InvalidArgumentException('Please enter who checked the PC.');
        }
        self::savePc($data, ['checked' => $date] + $input + $pc);
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function deletePc(array &$data, int $id): void
    {
        self::requireRecord($data, 'pcs', $id);
        $data['pcs'] = array_values(array_filter($data['pcs'], static fn ($p) => (int) $p['id'] !== $id));
    }

    /**
     * Create or update the latest firmware version of a device model.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $input
     */
    public static function saveFirmware(array &$data, array $input): int
    {
        $id = (int) ($input['id'] ?? 0);
        $rule = self::clean($input, self::FIRMWARE_FIELDS);
        if ($rule['model'] === '' || $rule['approved'] === '') {
            throw new InvalidArgumentException('Model and latest firmware are required.');
        }
        foreach ($data['firmware'] as $other) {
            if ((int) $other['id'] !== $id && strcasecmp(trim((string) $other['model']), $rule['model']) === 0) {
                throw new InvalidArgumentException("The latest firmware for '{$rule['model']}' is already listed.");
            }
        }

        return self::upsert($data, 'firmware', $id, $rule);
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function deleteFirmware(array &$data, int $id): void
    {
        self::requireRecord($data, 'firmware', $id);
        $data['firmware'] = array_values(array_filter($data['firmware'], static fn ($f) => (int) $f['id'] !== $id));
    }

    /**
     * Convert a free text status to 'online', 'offline', 'external' or '' (unknown).
     *
     * @param list<string> $onlineValues
     */
    public static function normaliseStatus(string $value, array $onlineValues = ['online']): string
    {
        $value = strtolower(trim($value));
        if ($value === '' || in_array($value, ['unknown', 'n/a', 'na', '-', 'pending'], true)) {
            return '';
        }
        if (str_contains($value, 'external')) {
            return self::STATUS_EXTERNAL;
        }
        $online = array_map(static fn ($v) => strtolower(trim((string) $v)), $onlineValues);
        $online[] = self::STATUS_ONLINE;
        return in_array($value, $online, true) ? self::STATUS_ONLINE : self::STATUS_OFFLINE;
    }

    /**
     * Last maintenance date as YYYY-MM-DD ('' when empty).
     */
    public static function normaliseDate(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        // Excel date serial number (days since 1899-12-30), e.g. from an .xlsx import.
        if (preg_match('/^\d{5}(\.\d+)?$/', $value)) {
            return gmdate('Y-m-d', ((int) $value - 25569) * 86400);
        }
        $ts = preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? strtotime($value . ' 12:00') : strtotime($value);
        if ($ts === false) {
            throw new InvalidArgumentException("'{$value}' is not a valid maintenance date.");
        }
        return date('Y-m-d', $ts);
    }

    /**
     * Get the host from an address that may be stored as a URL, e.g.
     * 'http://10.1.2.3:8080/index.html' -> '10.1.2.3' (as the Status-Check flows do).
     */
    public static function extractHost(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $value)) {
            $host = parse_url($value, PHP_URL_HOST);
            return is_string($host) ? trim($host, '[]') : $value;
        }
        if (preg_match('/^\[([0-9a-f:.]+)\](?::\d+)?(?:\/.*)?$/i', $value, $m)) {
            return $m[1];
        }
        if (filter_var($value, FILTER_VALIDATE_IP) !== false) {
            return $value;
        }
        // host:port/path without a scheme
        return (string) preg_replace('#(?::\d+)?(?:/.*)?$#', '', $value);
    }

    public static function webUrl(string $value, string $host): string
    {
        $parts = parse_url(trim($value));
        if (!is_array($parts)
            || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)
            || !isset($parts['host'])
            || isset($parts['user'])
            || isset($parts['pass'])) {
            return '';
        }
        $urlHost = trim((string) $parts['host'], '[]');
        return self::isValidAddress($urlHost) && strcasecmp($urlHost, $host) === 0 ? trim($value) : '';
    }

    public static function isUndefinedAddress(string $value): bool
    {
        return trim($value) === '0.0.0.0';
    }

    public static function isValidAddress(string $value): bool
    {
        if (filter_var($value, FILTER_VALIDATE_IP) !== false) {
            return true;
        }
        return strlen($value) <= 253
            && preg_match('/^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/', $value) === 1;
    }

    /**
     * Check whether a host is listed in the managed inventory or an additional
     * trusted host list.
     *
     * @param array<string, mixed> $data
     * @param list<mixed> $additionalHosts
     */
    public static function isPingTargetAllowed(array $data, string $host, array $additionalHosts = []): bool
    {
        $host = self::extractHost($host);
        if (self::isUndefinedAddress($host) || !self::isValidAddress($host)) {
            return false;
        }
        foreach (['devices', 'pcs'] as $collection) {
            foreach ((array) ($data[$collection] ?? []) as $record) {
                if (is_array($record) && self::sameAddress($host, (string) ($record['ip'] ?? ''))) {
                    return true;
                }
            }
        }
        foreach ($additionalHosts as $candidate) {
            if (is_scalar($candidate) && self::sameAddress($host, (string) $candidate)) {
                return true;
            }
        }
        return false;
    }

    private static function sameAddress(string $host, string $candidate): bool
    {
        $candidate = self::extractHost($candidate);
        return self::isValidAddress($candidate) && strcasecmp($host, $candidate) === 0;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>|null
     */
    public static function findSiteByName(array $data, string $name): ?array
    {
        $name = trim($name);
        foreach ($data['sites'] as $site) {
            if (strcasecmp(trim((string) $site['name']), $name) === 0
                || ($site['code'] ?? '') !== '' && strcasecmp(trim((string) $site['code']), $name) === 0) {
                return $site;
            }
        }
        return null;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>|null
     */
    public static function findRecord(array $data, string $collection, int $id): ?array
    {
        foreach ($data[$collection] as $record) {
            if ((int) $record['id'] === $id) {
                return $record;
            }
        }
        return null;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private static function requireRecord(array $data, string $collection, int $id): array
    {
        $record = self::findRecord($data, $collection, $id);
        if ($record === null) {
            throw new InvalidArgumentException('The record no longer exists.');
        }
        return $record;
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, mixed> $record
     */
    private static function upsert(array &$data, string $collection, int $id, array $record): int
    {
        if ($id > 0) {
            foreach ($data[$collection] as $i => $existing) {
                if ((int) $existing['id'] === $id) {
                    $data[$collection][$i] = ['id' => $id] + $record + $existing;
                    return $id;
                }
            }
            throw new InvalidArgumentException('The record no longer exists.');
        }

        $id = max(1, (int) ($data['next_id'] ?? 1));
        $data['next_id'] = $id + 1;
        $data[$collection][] = ['id' => $id] + $record;
        return $id;
    }

    /**
     * @param array<string, mixed> $input
     * @param list<string> $fields
     * @return array<string, string>
     */
    private static function clean(array $input, array $fields): array
    {
        $out = [];
        foreach ($fields as $field) {
            $value = $input[$field] ?? '';
            $value = is_scalar($value) ? trim((string) $value) : '';
            // Strip control characters (except newlines in notes).
            $value = (string) preg_replace('/[\x00-\x09\x0B-\x1F\x7F]/u', '', $value);
            if (function_exists('mb_substr')) {
                $value = mb_substr($value, 0, self::MAX_LENGTH);
            } else {
                $value = substr($value, 0, self::MAX_LENGTH);
            }
            $out[$field] = $value;
        }
        return $out;
    }
}
