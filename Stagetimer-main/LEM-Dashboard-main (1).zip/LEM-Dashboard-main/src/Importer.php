<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;

/**
 * Imports sites, devices, latest firmware versions and PCs (PC Maintenance) from exported lists (Excel .xlsx, CSV from
 * Excel / SharePoint / other tools, JSON arrays) and restores JSON backups
 * created by the export page.
 */
class Importer
{
    public const TYPES = ['devices', 'sites', 'firmware', 'pcs'];

    /** Accepted column names (lower case, letters and digits only) per field. */
    public const ALIASES = [
        'devices' => [
            'name'         => ['name', 'title', 'device', 'devicename', 'hostname', 'host'],
            'ip'           => ['ip', 'ipaddress', 'ipaddr', 'ipv4', 'ipv4address', 'address', 'managementip'],
            'site'         => ['site', 'sitename', 'location', 'locationname', 'branch', 'sitecode'],
            'type'         => ['type', 'devicetype', 'category', 'role'],
            'ownership'    => ['ownership'],
            'team'         => ['team', 'country', 'region'],
            'model'        => ['model', 'devicemodel', 'modelnumber'],
            'firmware'     => ['firmware', 'currentfirmware', 'currentversion', 'currentfw', 'firmwareversion', 'fw', 'fwversion', 'version', 'softwareversion', 'osversion'],
            'status'       => ['status', 'pingstatus', 'ping', 'pingresult', 'state', 'reachable'],
            'last_checked' => ['lastchecked', 'lastping', 'lastpinged', 'checked', 'checkedat', 'lastcheck', 'pinged'],
            'last_online'  => ['lastonline', 'lastseen', 'lastup', 'lastresponse'],
            'notes'        => ['notes', 'note', 'comments', 'comment', 'description'],
            'maintained'   => ['lastmaintenance', 'maintenance', 'maintained', 'lastmaintained', 'maintenancedate',
                'lastserviced', 'serviced', 'lastservice'],
        ],
        'sites' => [
            'name'    => ['name', 'site', 'sitename', 'title', 'location', 'locationname'],
            'code'    => ['code', 'sitecode', 'shortname', 'abbreviation'],
            'address' => ['address', 'streetaddress', 'street', 'physicaladdress'],
            'subnet'  => ['subnet', 'subnets', 'network', 'iprange', 'cidr', 'vlan'],
            'notes'   => ['notes', 'note', 'comments', 'comment', 'description'],
            'team'    => ['team', 'country', 'region'],
        ],
        'firmware' => [
            'manufacturer' => ['manufacturer', 'make', 'vendor', 'brand', 'mfr', 'mfg', 'oem'],
            'model'    => ['model', 'title', 'devicemodel', 'modelnumber', 'name'],
            'approved' => ['latestfirmware', 'latest', 'latestversion', 'latestfirmwareversion', 'approved', 'approvedfirmware',
                'approvedversion', 'required', 'requiredfirmware', 'baseline', 'firmware', 'firmwareversion', 'version',
                'minimumfirmware', 'targetfirmware'],
            'notes'    => ['notes', 'note', 'comments', 'comment', 'description'],
        ],
        'pcs' => [
            'name'       => ['pcname', 'name', 'computername', 'computer', 'hostname', 'devicename', 'device', 'pc', 'title', 'serialnumber', 'serial'],
            'ip'         => ['ip', 'ipaddress', 'ipaddr', 'ipv4', 'ipv4address', 'address'],
            'type'       => ['type', 'pctype', 'devicetype', 'formfactor', 'category'],
            'location'   => ['location', 'room', 'site', 'area', 'building'],
            'os'         => ['os', 'operatingsystem', 'osversion', 'windowsversion', 'windows', 'version'],
            'checked_by' => ['checkedby', 'technician', 'tech', 'by', 'initials', 'maintainedby'],
            'checked'    => ['lastchecked', 'checked', 'checkdate', 'checkeddate', 'lastcheck', 'lastmaintenance', 'maintained', 'maintenancedate', 'date'],
            'comments'   => ['comments', 'comment', 'notes', 'note', 'description'],
            'team'       => ['team', 'country', 'region'],
        ],
    ];

    private const MAX_ERRORS = 50;

    /** @var list<string> */
    private array $onlineValues;

    /** Team of imported PCs without a team column. */
    private string $team = '';

    /**
     * @param list<string> $onlineValues
     */
    public function __construct(array $onlineValues = ['online'])
    {
        $this->onlineValues = $onlineValues;
    }

    /**
     * Import an uploaded file. JSON backups (with "sites"/"devices"/"firmware"
     * keys) are restored completely; everything else is imported as rows of
     * the given type.
     *
     * With $siteOnly every row is imported into $defaultSiteId (any site column
     * is ignored), 'replace' only removes that site's devices and backups are
     * refused - used by the import on a site's page.
     *
     * @param array<string, mixed> $data
     * PCs are imported into $team unless the file has a team column.
     *
     * @return array{created: int, updated: int, skipped: int, sites_created: int, errors: list<string>, restored: bool}
     */
    public function import(array &$data, string $content, string $type, string $mode = 'merge', int $defaultSiteId = 0, ?string $now = null, bool $siteOnly = false, string $team = ''): array
    {
        $this->team = $team;
        if (!in_array($type, self::TYPES, true)) {
            throw new InvalidArgumentException('Unknown import type.');
        }
        if ($siteOnly && ($type !== 'devices' || Inventory::findRecord($data, 'sites', $defaultSiteId) === null)) {
            throw new InvalidArgumentException('Unknown location.');
        }
        $now ??= date('c');
        if (XlsxReader::isXlsx($content)) {
            return $this->importRows($data, XlsxReader::rows($content), $type, $mode, $defaultSiteId, $now, $siteOnly);
        }
        $content = self::toUtf8($content);
        if (trim($content) === '') {
            throw new InvalidArgumentException('The file is empty.');
        }

        $trimmed = ltrim($content);
        if ($trimmed[0] === '{' || $trimmed[0] === '[') {
            $json = json_decode($content, true);
            if (!is_array($json)) {
                throw new InvalidArgumentException('The file looks like JSON but could not be read.');
            }
            if (isset($json['sites']) || isset($json['devices']) || isset($json['firmware']) || isset($json['pcs'])) {
                if ($siteOnly) {
                    throw new InvalidArgumentException('This is a full backup. Restore it from the Device Status page.');
                }
                return $this->restore($data, $json, $now);
            }
            $rows = $json['value'] ?? $json['d']['results'] ?? $json;
            if (!is_array($rows) || !array_is_list($rows)) {
                throw new InvalidArgumentException('The JSON file must contain a list of records or a dashboard backup.');
            }
            $rows = array_values(array_filter($rows, 'is_array'));
        } else {
            $rows = self::parseCsv($content);
        }

        return $this->importRows($data, $rows, $type, $mode, $defaultSiteId, $now, $siteOnly);
    }

    /**
     * @param array<string, mixed> $data
     * @param list<array<string, mixed>> $rows
     * @return array{created: int, updated: int, skipped: int, sites_created: int, errors: list<string>, restored: bool}
     */
    public function importRows(array &$data, array $rows, string $type, string $mode, int $defaultSiteId, string $now, bool $siteOnly = false): array
    {
        $result = ['created' => 0, 'updated' => 0, 'skipped' => 0, 'sites_created' => 0, 'errors' => [], 'restored' => false];
        if ($rows === []) {
            throw new InvalidArgumentException('No records were found in the file.');
        }

        $mapping = self::mapColumns(array_keys($rows[0]), $type);
        $required = $type === 'firmware' ? 'model' : 'name';
        if (!isset($mapping[$required])) {
            throw new InvalidArgumentException('Could not find a "' . $required . '" column. Columns found: ' . implode(', ', array_keys($rows[0])) . '.');
        }

        if ($siteOnly) {
            unset($mapping['site'], $mapping['ownership'], $mapping['team']);
        }
        if ($mode === 'replace' && $type === 'devices' && $siteOnly) {
            $data['devices'] = array_values(array_filter($data['devices'], static fn ($d) => (int) $d['site_id'] !== $defaultSiteId));
        } elseif ($mode === 'replace' && $type === 'devices') {
            $data['devices'] = [];
        } elseif ($mode === 'replace' && $type === 'firmware') {
            $data['firmware'] = [];
        } elseif ($mode === 'replace' && $type === 'pcs') {
            $team = $this->team;
            $data['pcs'] = array_values(array_filter($data['pcs'], static fn ($p) => (string) ($p['team'] ?? '') !== $team));
        }

        foreach ($rows as $index => $row) {
            $line = $index + 2; // header is line 1
            $record = [];
            foreach ($mapping as $field => $column) {
                $value = $row[$column] ?? '';
                $value = is_array($value) ? (string) ($value['Title'] ?? $value['Label'] ?? '') : trim((string) $value);
                // Undo the formula-injection protection added by the CSV export.
                if (preg_match('/^\'[=+\-@]/', $value) === 1) {
                    $value = substr($value, 1);
                }
                $record[$field] = $value;
            }
            if (implode('', $record) === '') {
                continue;
            }

            try {
                switch ($type) {
                    case 'sites':
                        $this->importSite($data, $record, $result);
                        break;
                    case 'firmware':
                        $this->importFirmware($data, $record, $result);
                        break;
                    case 'pcs':
                        $this->importPc($data, $record, $result);
                        break;
                    default:
                        $this->importDevice($data, $record, $defaultSiteId, $now, $result);
                }
            } catch (InvalidArgumentException $e) {
                $result['skipped']++;
                if (count($result['errors']) < self::MAX_ERRORS) {
                    $result['errors'][] = "Row {$line}: " . $e->getMessage();
                }
            }
        }

        return $result;
    }

    /**
     * Restore a JSON backup created by the export page. Existing data is replaced.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $backup
     * @return array{created: int, updated: int, skipped: int, sites_created: int, errors: list<string>, restored: bool}
     */
    public function restore(array &$data, array $backup, string $now): array
    {
        $result = ['created' => 0, 'updated' => 0, 'skipped' => 0, 'sites_created' => 0, 'errors' => [], 'restored' => true];
        $new = Store::emptyData();
        $siteIds = [];

        foreach ((array) ($backup['sites'] ?? []) as $i => $site) {
            try {
                $id = Inventory::saveSite($new, ['id' => 0] + (array) $site);
                $siteIds[(int) ($site['id'] ?? 0)] = $id;
                $result['sites_created']++;
            } catch (InvalidArgumentException $e) {
                $this->addError($result, 'Location ' . ($i + 1) . ': ' . $e->getMessage());
            }
        }

        foreach ((array) ($backup['devices'] ?? []) as $i => $device) {
            $device = (array) $device;
            $siteId = $siteIds[(int) ($device['site_id'] ?? 0)] ?? 0;
            if ($siteId === 0 && !empty($device['site'])) {
                $siteId = (int) (Inventory::findSiteByName($new, (string) $device['site'])['id'] ?? 0);
            }
            try {
                $input = ['id' => 0, 'site_id' => $siteId] + $device;
                unset($input['status']);
                $id = Inventory::saveDevice($new, $input, $this->onlineValues, $now);
                $this->setStatusFields($new, $id, $device, $now);
                if (is_string($device['photo'] ?? null) && preg_match('/^\d+-[a-f0-9]{16}\.(jpg|png|gif|webp)$/', $device['photo'])) {
                    Inventory::setPhoto($new, $id, $device['photo']); // file is kept if it still exists
                }
                $result['created']++;
            } catch (InvalidArgumentException $e) {
                $this->addError($result, 'Device ' . ($i + 1) . ': ' . $e->getMessage());
            }
        }

        foreach ((array) ($backup['firmware'] ?? []) as $i => $rule) {
            try {
                Inventory::saveFirmware($new, ['id' => 0] + (array) $rule);
                $result['created']++;
            } catch (InvalidArgumentException $e) {
                $this->addError($result, 'Firmware ' . ($i + 1) . ': ' . $e->getMessage());
            }
        }

        foreach ((array) ($backup['pcs'] ?? []) as $i => $pc) {
            $pc = (array) $pc;
            try {
                $id = Inventory::savePc($new, ['id' => 0] + $pc);
                foreach ($new['pcs'] as $j => $saved) {
                    if ((int) $saved['id'] === $id) {
                        foreach (['status', 'last_checked', 'last_online', 'latency_ms'] as $field) {
                            $new['pcs'][$j][$field] = $pc[$field] ?? $saved[$field];
                        }
                    }
                }
                if (is_string($pc['photo'] ?? null) && preg_match('/^\d+-[a-f0-9]{16}\.(jpg|png|gif|webp)$/', $pc['photo'])) {
                    Inventory::setPhoto($new, $id, $pc['photo'], 'pcs');
                }
                $result['created']++;
            } catch (InvalidArgumentException $e) {
                $this->addError($result, 'PC ' . ($i + 1) . ': ' . $e->getMessage());
            }
        }

        if ($new['sites'] === [] && $new['devices'] === [] && $new['firmware'] === [] && $new['pcs'] === [] && $result['errors'] !== []) {
            throw new InvalidArgumentException('Nothing could be restored from the backup: ' . $result['errors'][0]);
        }

        $data = $new;
        return $result;
    }

    /**
     * Parse CSV / TSV text into associative rows keyed by the header row.
     *
     * @return list<array<string, string>>
     */
    public static function parseCsv(string $content): array
    {
        $content = self::toUtf8($content);
        $firstLine = strtok($content, "\r\n") ?: '';
        $delimiter = ',';
        $best = 0;
        foreach ([',', ';', "\t", '|'] as $candidate) {
            $count = substr_count($firstLine, $candidate);
            if ($count > $best) {
                $best = $count;
                $delimiter = $candidate;
            }
        }

        $handle = fopen('php://temp', 'r+');
        fwrite($handle, $content);
        rewind($handle);

        $header = null;
        $rows = [];
        while (($fields = fgetcsv($handle, 0, $delimiter, '"', '')) !== false) {
            if ($fields === [null] || $fields === ['']) {
                continue;
            }
            $fields = array_map(static fn ($v) => trim((string) $v), $fields);
            if ($header === null) {
                $header = [];
                foreach ($fields as $i => $name) {
                    $name = $name === '' ? 'Column ' . ($i + 1) : $name;
                    while (in_array($name, $header, true)) {
                        $name .= ' ';
                    }
                    $header[] = $name;
                }
                continue;
            }
            $row = [];
            foreach ($header as $i => $name) {
                $row[$name] = $fields[$i] ?? '';
            }
            $rows[] = $row;
        }
        fclose($handle);

        return $rows;
    }

    /**
     * Map dashboard fields to the matching column names of a file.
     *
     * @param list<string|int> $columns
     * @return array<string, string> field => column
     */
    public static function mapColumns(array $columns, string $type): array
    {
        $normalised = [];
        foreach ($columns as $column) {
            $normalised[self::normaliseHeader((string) $column)] ??= (string) $column;
        }

        $mapping = [];
        $used = [];
        foreach (self::ALIASES[$type] as $field => $aliases) {
            foreach ($aliases as $alias) {
                if (isset($normalised[$alias]) && !isset($used[$normalised[$alias]])) {
                    $mapping[$field] = $normalised[$alias];
                    $used[$normalised[$alias]] = true;
                    break;
                }
            }
        }
        return $mapping;
    }

    public static function normaliseHeader(string $header): string
    {
        // SharePoint encodes spaces in internal names as _x0020_.
        $header = str_ireplace('_x0020_', '', $header);
        return (string) preg_replace('/[^a-z0-9]/', '', strtolower($header));
    }

    /**
     * Convert file contents to UTF-8 (handles BOMs, UTF-16 "Unicode text" from
     * Excel and Windows-1252 encoded CSV files).
     */
    public static function toUtf8(string $content): string
    {
        if (strncmp($content, "\xEF\xBB\xBF", 3) === 0) {
            return substr($content, 3);
        }
        if (strncmp($content, "\xFF\xFE", 2) === 0) {
            return (string) mb_convert_encoding(substr($content, 2), 'UTF-8', 'UTF-16LE');
        }
        if (strncmp($content, "\xFE\xFF", 2) === 0) {
            return (string) mb_convert_encoding(substr($content, 2), 'UTF-8', 'UTF-16BE');
        }
        if (!mb_check_encoding($content, 'UTF-8')) {
            return (string) mb_convert_encoding($content, 'UTF-8', 'Windows-1252');
        }
        return $content;
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $record
     * @param array<string, mixed> $result
     */
    private function importSite(array &$data, array $record, array &$result): void
    {
        $existing = Inventory::findSiteByName($data, $record['name'] ?? '');
        if ($existing !== null) {
            Inventory::saveSite($data, array_merge($existing, self::nonEmpty($record)));
            $result['updated']++;
        } else {
            Inventory::saveSite($data, $record);
            $result['created']++;
        }
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $record
     * @param array<string, mixed> $result
     */
    private function importFirmware(array &$data, array $record, array &$result): void
    {
        foreach ($data['firmware'] as $rule) {
            if (strcasecmp(trim((string) $rule['model']), $record['model'] ?? '') === 0) {
                Inventory::saveFirmware($data, array_merge($rule, self::nonEmpty($record)));
                $result['updated']++;
                return;
            }
        }
        Inventory::saveFirmware($data, $record);
        $result['created']++;
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, string> $record
     * @param array<string, mixed> $result
     */
    private function importDevice(array &$data, array $record, int $defaultSiteId, string $now, array &$result): void
    {
        $recordIp = Inventory::extractHost((string) ($record['ip'] ?? ''));
        $siteName = $record['site'] ?? '';
        $standalone = ($record['ownership'] ?? '') === 'standalone';
        $team = dashboard_team(($record['team'] ?? '') !== '' ? $record['team'] : $this->team);
        if ($standalone) {
            if ($siteName !== '' || $defaultSiteId > 0) {
                throw new InvalidArgumentException('Standalone devices cannot have a location.');
            }
            $siteId = 0;
        } elseif ($siteName !== '') {
            $site = Inventory::findSiteByName($data, $siteName);
            if ($site === null) {
                $siteId = Inventory::saveSite($data, ['name' => $siteName]);
                $result['sites_created']++;
            } else {
                $siteId = (int) $site['id'];
            }
        } else {
            $siteId = $defaultSiteId;
        }
        if (!$standalone && Inventory::findRecord($data, 'sites', $siteId) === null) {
            throw new InvalidArgumentException('No location given. Add a Location column or import on the location’s page.');
        }

        $existing = null;
        foreach ($data['devices'] as $device) {
            if ((int) $device['site_id'] !== $siteId) {
                continue;
            }
            if ($standalone && (!Inventory::isStandalone($device) || dashboard_team($device['team'] ?? '') !== $team)) {
                continue;
            }
            $sameIp = $recordIp !== '' && strcasecmp((string) $device['ip'], $recordIp) === 0;
            $sameName = $recordIp === '' && strcasecmp((string) $device['name'], $record['name'] ?? '') === 0;
            if ($sameIp || $sameName) {
                $existing = $device;
                break;
            }
        }

        $fields = array_intersect_key($record, array_flip(Inventory::DEVICE_FIELDS));
        $input = ['site_id' => $siteId] + ($existing === null ? $fields : array_merge($existing, self::nonEmpty($fields)));
        if ($standalone) {
            $input['ownership'] = 'standalone';
            $input['team'] = $team;
        }
        $input['id'] = $existing['id'] ?? 0;
        unset($input['status']);

        $id = Inventory::saveDevice($data, $input, $this->onlineValues, $now);
        $this->setStatusFields($data, $id, $record, $now);
        $result[$existing === null ? 'created' : 'updated']++;
    }

    /**
     * Add or update a PC (matched by name within its team).
     *
     * @param array<string, mixed> $data
     * @param array<string, string> $record
     * @param array<string, mixed> $result
     */
    private function importPc(array &$data, array $record, array &$result): void
    {
        $record['team'] = ($record['team'] ?? '') !== '' && function_exists('dashboard_team') ? dashboard_team($record['team']) : $this->team;
        $existing = null;
        foreach ($data['pcs'] as $pc) {
            if ((string) ($pc['team'] ?? '') === $record['team'] && strcasecmp(trim((string) $pc['name']), $record['name'] ?? '') === 0) {
                $existing = $pc;
                break;
            }
        }
        Inventory::savePc($data, $existing === null ? $record : array_merge($existing, self::nonEmpty($record)));
        $result[$existing === null ? 'created' : 'updated']++;
    }

    /**
     * Copy status / last_checked / last_online from an imported record.
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed> $record
     */
    private function setStatusFields(array &$data, int $id, array $record, string $now): void
    {
        if (trim((string) ($record['status'] ?? '')) === '') {
            return;
        }
        foreach ($data['devices'] as $i => $device) {
            if ((int) $device['id'] !== $id) {
                continue;
            }
            $status = Inventory::normaliseStatus((string) $record['status'], $this->onlineValues);
            $checked = self::isoDate((string) ($record['last_checked'] ?? '')) ?? $now;
            Inventory::applyStatus($device, $status, $checked);
            $lastOnline = self::isoDate((string) ($record['last_online'] ?? ''));
            if ($lastOnline !== null) {
                $device['last_online'] = $lastOnline;
            }
            $data['devices'][$i] = $device;
            return;
        }
    }

    private static function isoDate(string $value): ?string
    {
        if (trim($value) === '') {
            return null;
        }
        $ts = strtotime($value);
        return $ts === false ? null : date('c', $ts);
    }

    /**
     * @param array<string, string> $record
     * @return array<string, string>
     */
    private static function nonEmpty(array $record): array
    {
        return array_filter($record, static fn ($v) => $v !== '');
    }

    /**
     * @param array<string, mixed> $result
     */
    private function addError(array &$result, string $message): void
    {
        $result['skipped']++;
        if (count($result['errors']) < self::MAX_ERRORS) {
            $result['errors'][] = $message;
        }
    }
}
