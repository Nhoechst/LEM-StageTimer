<?php

declare(strict_types=1);

namespace StatusDashboard;

use RuntimeException;

/** Encrypt SSH passwords with a local key that is never included in API responses. */
class SshPassword
{
    public function __construct(private string $keyFile)
    {
    }

    public function encrypt(string $password, array $device): string
    {
        $nonce = random_bytes(12);
        $key = $this->key(true);
        $ciphertext = openssl_encrypt($password, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag, self::context($device));
        if ($ciphertext === false) {
            throw new RuntimeException('Could not encrypt the SSH password.');
        }
        return base64_encode($nonce . $tag . $ciphertext);
    }

    public function decrypt(string $value, array $device): string
    {
        $data = base64_decode($value, true);
        if ($data === false || strlen($data) < 29) {
            throw new RuntimeException('SSH password is unavailable. Re-enter it in Discovery Server settings.');
        }
        $key = $this->key(false);
        $password = openssl_decrypt(substr($data, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA,
            substr($data, 0, 12), substr($data, 12, 16), self::context($device));
        if ($password === false) {
            throw new RuntimeException('Could not decrypt the SSH password. Re-enter it in Discovery Server settings.');
        }
        return $password;
    }

    private static function context(array $device): string
    {
        return json_encode([(string) $device['ip'], (string) $device['ssh_user'], (int) $device['ssh_port']], JSON_THROW_ON_ERROR);
    }

    private function key(bool $create): string
    {
        if (!extension_loaded('openssl')) {
            throw new RuntimeException('SSH password storage requires the PHP OpenSSL extension.');
        }
        if (!$create && !is_file($this->keyFile)) {
            throw new RuntimeException('SSH password encryption key is missing. Re-enter the password in Discovery Server settings.');
        }
        $directory = dirname($this->keyFile);
        if ($create && !is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new RuntimeException('Cannot create the SSH password key directory.');
        }
        $mask = umask(0077);
        try {
            $file = @fopen($this->keyFile, $create ? 'c+b' : 'rb');
        } finally {
            umask($mask);
        }
        if ($file === false) {
            throw new RuntimeException('Cannot open the SSH password encryption key.');
        }
        try {
            if (!flock($file, $create ? LOCK_EX : LOCK_SH)) {
                throw new RuntimeException('Cannot lock the SSH password encryption key.');
            }
            $key = stream_get_contents($file, 33);
            if ($key === '' && $create) {
                $key = random_bytes(32);
                if (fwrite($file, $key) !== 32 || !fflush($file)) {
                    throw new RuntimeException('Cannot save the SSH password encryption key.');
                }
            }
            if (!is_string($key) || strlen($key) !== 32) {
                throw new RuntimeException('Invalid SSH password encryption key.');
            }
            return $key;
        } finally {
            fclose($file);
        }
    }
}
