<?php

declare(strict_types=1);

namespace StatusDashboard;

use RuntimeException;

/**
 * Controls when status checks may run:
 *  - only one check at a time (lock file),
 *  - manual checks (buttons) have a global cooldown; individual device checks
 *    have separate per-device cooldowns;
 *    "Check all" checks one location per request, so the requests of one run
 *    (same run id, each location once) count as a single check,
 *  - automatic checks run once per scheduled slot (e.g. 00:00 and 12:00),
 *    separately for each team in the team's own time zone.
 */
class CheckGuard
{
    /** Max. seconds between two requests of the same "Check all" run. */
    private const RUN_GAP_SECONDS = 120;

    private Database $db;
    private string $lockFile;
    private int $cooldown;

    /** @var resource|null */
    private $lock = null;

    public function __construct(Database $db, string $dataDir, int $cooldownSeconds)
    {
        $this->db = $db;
        $this->lockFile = $dataDir . '/check.lock';
        $this->cooldown = max(0, $cooldownSeconds);
    }

    public function cooldownSeconds(): int
    {
        return $this->cooldown;
    }

    /**
     * Take the "check running" lock. With $wait = false a CheckBusy is thrown
     * if another check holds it.
     */
    public function acquire(bool $wait): void
    {
        $dir = dirname($this->lockFile);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $handle = @fopen($this->lockFile, 'c');
        if ($handle === false) {
            throw new RuntimeException('Cannot create the check lock file. Check that the web server can write to the data folder.');
        }
        if (!flock($handle, $wait ? LOCK_EX : LOCK_EX | LOCK_NB)) {
            fclose($handle);
            throw new CheckBusy('A status check is already running. Try again when it has finished.');
        }
        $this->lock = $handle;
    }

    public function release(): void
    {
        if ($this->lock !== null) {
            flock($this->lock, LOCK_UN);
            fclose($this->lock);
            $this->lock = null;
        }
    }

    public function isRunning(): bool
    {
        $handle = @fopen($this->lockFile, 'c');
        if ($handle === false) {
            return false;
        }
        $free = flock($handle, LOCK_EX | LOCK_NB);
        if ($free) {
            flock($handle, LOCK_UN);
        }
        fclose($handle);
        return !$free;
    }

    /**
     * Register a manual check request.
     *
     * @param string   $run    Random id the browser sends for one "Check all"/"Check" click.
     * @param int|null $siteId   Location being checked (null = everything in one request).
     * @param int|null $now      Current time, injectable for tests.
     * @param int|null $deviceId Individual device being checked (null = global cooldown).
     * @return int 0 if the check may run, otherwise the seconds to wait.
     */
    public function beginManual(string $run, ?int $siteId, ?int $now = null, ?int $deviceId = null): int
    {
        $now ??= time();
        $run = preg_match('/^[A-Za-z0-9-]{16,64}$/', $run) === 1 ? $run : '';
        $cooldown = $this->cooldown;

        return $this->db->stateUpdate('checks', static function (array &$state) use ($run, $siteId, $now, $cooldown, $deviceId): int {
            $m = (array) ($state['manual'] ?? []);
            if ($deviceId !== null) {
                $deviceLast = (array) ($m['device_last'] ?? []);
                $last = (int) ($deviceLast[(string) $deviceId] ?? 0);
                if ($now - $last < $cooldown) {
                    return $cooldown - ($now - $last);
                }
                $deviceLast[(string) $deviceId] = $now;
                $m['device_last'] = $deviceLast;
                $state['manual'] = $m;
                return 0;
            }

            $last = (int) ($m['last'] ?? 0);
            $continues = $run !== '' && $siteId !== null
                && ($m['run'] ?? '') === $run
                && empty($m['all'])
                && $now - $last <= self::RUN_GAP_SECONDS
                && !in_array($siteId, (array) ($m['sites'] ?? []), true);

            if ($continues) {
                $m['sites'][] = $siteId;
                $m['last'] = $now;
            } elseif ($now - $last < $cooldown) {
                return $cooldown - ($now - $last);
            } else {
                $deviceLast = (array) ($m['device_last'] ?? []);
                $m = ['run' => $run, 'last' => $now, 'sites' => $siteId !== null ? [$siteId] : [], 'all' => $siteId === null];
                if ($deviceLast !== []) {
                    $m['device_last'] = $deviceLast;
                }
            }
            $state['manual'] = $m;
            return 0;
        });
    }

    /**
     * Mark the end of a manual check request: the cooldown counts from here.
     */
    public function finishManual(?int $now = null, ?int $deviceId = null): void
    {
        $now ??= time();
        $this->db->stateUpdate('checks', static function (array &$state) use ($now, $deviceId): void {
            if ($deviceId !== null) {
                $state['manual']['device_last'][(string) $deviceId] = $now;
                return;
            }
            $state['manual']['last'] = $now;
        });
    }

    /**
     * Seconds until a new manual check may start (0 = now).
     */
    public function cooldownRemaining(?int $now = null): int
    {
        $now ??= time();
        $last = (int) ($this->db->stateRead('checks')['manual']['last'] ?? 0);
        return max(0, $this->cooldown - ($now - $last));
    }

    /**
     * Claim the scheduled slot that is due now, so it runs only once even if
     * cron fires more often or several schedulers run.
     *
     * @param list<string> $times    Local times "HH:MM", e.g. ['00:00', '12:00'].
     * @param string       $team     Team key; each team has its own slots.
     * @param string       $timezone Time zone of $times, e.g. 'Europe/Berlin'.
     * @return int|null The slot's timestamp, or null if no automatic check is due.
     */
    public function claimDueSlot(array $times, int $windowMinutes, string $team, string $timezone, ?int $now = null): ?int
    {
        $now ??= time();
        $due = null;
        foreach (self::slots($times, $timezone, $now - 86400, 2) as $slot) {
            if ($slot <= $now && $now < $slot + $windowMinutes * 60) {
                $due = $slot;
            }
        }
        if ($due === null) {
            return null;
        }
        return $this->db->stateUpdate('checks', static function (array &$state) use ($due, $now, $team): ?int {
            if ((int) ($state['scheduled_teams'][$team]['slot'] ?? 0) >= $due) {
                return null;
            }
            $state['scheduled_teams'][$team] = ['slot' => $due, 'started' => $now]
                + (array) ($state['scheduled_teams'][$team] ?? []);
            return $due;
        });
    }

    public function finishScheduled(string $team, ?int $now = null): void
    {
        $now ??= time();
        $this->db->stateUpdate('checks', static function (array &$state) use ($now, $team): void {
            $state['scheduled_teams'][$team]['finished'] = $now;
        });
    }

    /**
     * When each team's last automatic check finished.
     *
     * @return array<string, int>
     */
    public function lastScheduled(): array
    {
        $out = [];
        foreach ((array) ($this->db->stateRead('checks')['scheduled_teams'] ?? []) as $team => $s) {
            if (isset($s['finished'])) {
                $out[(string) $team] = (int) $s['finished'];
            }
        }
        return $out;
    }

    /**
     * @param list<string> $times
     */
    public static function nextSlot(array $times, string $timezone, ?int $now = null): ?int
    {
        $now ??= time();
        foreach (self::slots($times, $timezone, $now, 2) as $slot) {
            if ($slot > $now) {
                return $slot;
            }
        }
        return null;
    }

    /**
     * Valid "HH:MM" times from the configuration.
     *
     * @param array<mixed> $times
     * @return list<string>
     */
    public static function normaliseTimes(array $times): array
    {
        $out = [];
        foreach ($times as $t) {
            if (is_string($t) && preg_match('/^([01]?\d|2[0-3]):([0-5]\d)$/', trim($t), $m)) {
                $out[] = sprintf('%02d:%02d', (int) $m[1], (int) $m[2]);
            }
        }
        $out = array_values(array_unique($out));
        sort($out);
        return $out;
    }

    /**
     * Slot timestamps ($times in $timezone) for $days days starting with the day of $from, ascending.
     *
     * @param list<string> $times
     * @return list<int>
     */
    private static function slots(array $times, string $timezone, int $from, int $days): array
    {
        $slots = [];
        $day = (new \DateTimeImmutable('@' . $from))->setTimezone(new \DateTimeZone($timezone))->setTime(0, 0);
        for ($d = 0; $d <= $days; $d++) {
            foreach (self::normaliseTimes($times) as $t) {
                [$h, $i] = array_map('intval', explode(':', $t));
                $slots[] = $day->modify("+{$d} days")->setTime($h, $i)->getTimestamp();
            }
        }
        sort($slots);
        return $slots;
    }
}
