<?php

declare(strict_types=1);

namespace StatusDashboard;

use RuntimeException;

/**
 * Minimal SMTP client for the outage emails, for servers without a sendmail
 * program (e.g. Docker / Pelican containers). Supports STARTTLS, implicit TLS
 * ("ssl", port 465) and plain connections, AUTH PLAIN / LOGIN, and verifies
 * the server's TLS certificate unless told not to. Errors are thrown as
 * RuntimeException with the server's reply.
 */
class SmtpClient
{
    public const ENCRYPTIONS = ['starttls', 'ssl', 'none'];

    /** @var resource|null */
    private $socket = null;

    public function __construct(
        private readonly string $host,
        private readonly int $port,
        private readonly string $encryption = 'starttls',
        private readonly string $user = '',
        private readonly string $password = '',
        private readonly bool $verifyCertificate = true,
        private readonly int $timeout = 15,
    ) {
    }

    /**
     * Send one message.
     *
     * @param string $from    Envelope sender (MAIL FROM)
     * @param string $to      Recipient (RCPT TO)
     * @param string $message Complete message: headers, empty line, body (CRLF line ends)
     */
    public function send(string $from, string $to, string $message): void
    {
        foreach ([$from, $to] as $address) {
            if (preg_match('/[\r\n<>]/', $address) || filter_var($address, FILTER_VALIDATE_EMAIL) === false) {
                throw new RuntimeException("SMTP: '{$address}' is not a valid email address.");
            }
        }
        try {
            $this->connect();
            $this->command('MAIL FROM:<' . $from . '>', [250]);
            $this->command('RCPT TO:<' . $to . '>', [250, 251]);
            $this->command('DATA', [354]);
            // Normalise line ends and dot-stuff lines starting with "." (RFC 5321 4.5.2).
            $data = preg_replace('/\r\n|\r|\n/', "\r\n", rtrim($message, "\r\n"));
            $data = preg_replace('/^\./m', '..', (string) $data);
            $this->write($data . "\r\n.\r\n");
            $this->expect([250]);
            $this->command('QUIT', [221], false);
        } finally {
            $this->close();
        }
    }

    private function connect(): void
    {
        $context = stream_context_create(['ssl' => [
            'verify_peer'       => $this->verifyCertificate,
            'verify_peer_name'  => $this->verifyCertificate,
            'allow_self_signed' => !$this->verifyCertificate,
            'peer_name'         => $this->host,
            'SNI_enabled'       => true,
        ]]);
        $scheme = $this->encryption === 'ssl' ? 'ssl' : 'tcp';
        $errno = 0;
        $errstr = '';
        $socket = @stream_socket_client("{$scheme}://{$this->host}:{$this->port}", $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT, $context);
        if ($socket === false) {
            throw new RuntimeException("Cannot connect to the SMTP server {$this->host}:{$this->port}"
                . ($errstr !== '' ? " ({$errstr})" : '') . '. Check the host, port, encryption and firewall.');
        }
        stream_set_timeout($socket, $this->timeout);
        $this->socket = $socket;

        $this->expect([220]);
        $features = $this->ehlo();
        if ($this->encryption === 'starttls') {
            if (!preg_match('/^STARTTLS\b/mi', $features)) {
                throw new RuntimeException('The SMTP server does not offer STARTTLS. Choose SSL/TLS or no encryption.');
            }
            $this->command('STARTTLS', [220]);
            $method = STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT : 0);
            if (@stream_socket_enable_crypto($this->socket, true, $method) !== true) {
                throw new RuntimeException('TLS with the SMTP server failed'
                    . ($this->verifyCertificate ? ' (is the certificate valid for this host name?)' : '') . '.');
            }
            $features = $this->ehlo();
        }
        if ($this->user !== '') {
            if ($this->encryption === 'none') {
                throw new RuntimeException('SMTP login needs STARTTLS or SSL/TLS, so the password is not sent unencrypted.');
            }
            $this->login($features);
        }
    }

    private function ehlo(): string
    {
        $name = preg_replace('/[^A-Za-z0-9.-]/', '', (string) gethostname());
        return $this->command('EHLO ' . ($name !== '' && $name !== null ? $name : 'localhost'), [250]);
    }

    private function login(string $features): void
    {
        $auth = preg_match('/^AUTH[ =](.*)$/mi', $features, $m) ? strtoupper($m[1]) : '';
        if (str_contains($auth, 'PLAIN')) {
            $this->command('AUTH PLAIN ' . base64_encode("\0" . $this->user . "\0" . $this->password), [235], true, true);
        } elseif (str_contains($auth, 'LOGIN')) {
            $this->command('AUTH LOGIN', [334]);
            $this->command(base64_encode($this->user), [334], true, true);
            $this->command(base64_encode($this->password), [235], true, true);
        } else {
            throw new RuntimeException('The SMTP server offers no supported login method (PLAIN or LOGIN).');
        }
    }

    /**
     * @param list<int> $codes
     */
    private function command(string $line, array $codes, bool $strict = true, bool $secret = false): string
    {
        $this->write($line . "\r\n");
        try {
            return $this->expect($codes);
        } catch (RuntimeException $e) {
            if (!$strict) {
                return '';
            }
            if ($secret) {
                throw new RuntimeException('SMTP login failed: ' . $e->getMessage() . ' Check the SMTP user name and password.');
            }
            throw $e;
        }
    }

    private function write(string $data): void
    {
        if ($this->socket === null || @fwrite($this->socket, $data) === false) {
            throw new RuntimeException('The connection to the SMTP server was lost.');
        }
    }

    /**
     * Read a (multi-line) reply and check its code.
     *
     * @param list<int> $codes
     */
    private function expect(array $codes): string
    {
        $reply = '';
        while ($this->socket !== null && ($line = fgets($this->socket, 1024)) !== false) {
            $reply .= substr($line, 4);
            if (strlen($line) < 4 || $line[3] !== '-') {
                $code = (int) substr($line, 0, 3);
                if (!in_array($code, $codes, true)) {
                    $text = trim(substr($line, 0, 3) . ' ' . preg_replace('/\s+/', ' ', $reply));
                    throw new RuntimeException('The SMTP server answered: ' . rtrim($text, '.') . '.');
                }
                return $reply;
            }
        }
        $meta = $this->socket !== null ? stream_get_meta_data($this->socket) : [];
        throw new RuntimeException(!empty($meta['timed_out']) ? 'The SMTP server did not answer in time.' : 'The SMTP server closed the connection.');
    }

    private function close(): void
    {
        if ($this->socket !== null) {
            @fclose($this->socket);
            $this->socket = null;
        }
    }
}
