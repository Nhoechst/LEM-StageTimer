<?php

declare(strict_types=1);

namespace StatusDashboard;

use RuntimeException;

/**
 * Thrown when a status check is requested while another one is running.
 */
class CheckBusy extends RuntimeException
{
}
