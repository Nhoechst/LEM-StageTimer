<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;

/**
 * Equipment photos, stored as data/photos/<device id>-<random>.<ext>.
 * Only JPEG, PNG, GIF and WebP images are accepted (checked by content, not by name).
 */
final class Photos
{
    private const TYPES = [
        IMAGETYPE_JPEG => ['jpg', 'image/jpeg'],
        IMAGETYPE_PNG  => ['png', 'image/png'],
        IMAGETYPE_GIF  => ['gif', 'image/gif'],
        IMAGETYPE_WEBP => ['webp', 'image/webp'],
    ];
    private const NAME = '/^\d+-[a-f0-9]{16}\.(jpg|png|gif|webp)$/';

    public function __construct(private readonly string $dir, private readonly int $maxBytes)
    {
    }

    /**
     * Validate an uploaded image and store it for a device. Returns the new file name.
     */
    public function store(int $deviceId, string $tmpFile): string
    {
        $size = (int) @filesize($tmpFile);
        if ($size <= 0) {
            throw new InvalidArgumentException('Please choose a photo to upload.');
        }
        if ($size > $this->maxBytes) {
            throw new InvalidArgumentException('The photo is too large.');
        }
        $info = @getimagesize($tmpFile);
        if ($info === false || !isset(self::TYPES[$info[2]]) || $info[0] < 1 || $info[1] < 1) {
            throw new InvalidArgumentException('The photo must be a JPEG, PNG, GIF or WebP image.');
        }
        if (!is_dir($this->dir) && !@mkdir($this->dir, 0775, true) && !is_dir($this->dir)) {
            throw new \RuntimeException('Cannot create the photo folder.');
        }
        $name = $deviceId . '-' . bin2hex(random_bytes(8)) . '.' . self::TYPES[$info[2]][0];
        if (!@copy($tmpFile, $this->dir . '/' . $name)) {
            throw new \RuntimeException('Cannot save the photo.');
        }
        return $name;
    }

    /**
     * Full path and MIME type of a stored photo, or null if the name is invalid or missing.
     *
     * @return array{0: string, 1: string}|null
     */
    public function file(string $name): ?array
    {
        if (!preg_match(self::NAME, $name, $m)) {
            return null;
        }
        $path = $this->dir . '/' . $name;
        if (!is_file($path)) {
            return null;
        }
        foreach (self::TYPES as [$ext, $mime]) {
            if ($ext === $m[1]) {
                return [$path, $mime];
            }
        }
        return null;
    }

    /**
     * Delete stored photos that no device or PC refers to any more. Files from the last
     * minute are kept: an upload may not be saved in the inventory yet.
     *
     * @param array<string, mixed> $data
     */
    public function prune(array $data): void
    {
        if (!is_dir($this->dir)) {
            return;
        }
        $used = [];
        foreach ([...($data['devices'] ?? []), ...($data['pcs'] ?? [])] as $record) {
            $used[(string) ($record['photo'] ?? '')] = true;
        }
        $recent = time() - 60;
        foreach (scandir($this->dir) ?: [] as $file) {
            if (preg_match(self::NAME, $file) && !isset($used[$file])
                && (int) @filemtime($this->dir . '/' . $file) < $recent) {
                @unlink($this->dir . '/' . $file);
            }
        }
    }
}
