<?php

declare(strict_types=1);

namespace StatusDashboard;

use InvalidArgumentException;
use SimpleXMLElement;

/**
 * Minimal reader for Excel .xlsx workbooks: returns the rows of the sheet that
 * was open when the file was saved (or else the first sheet with data) as
 * associative arrays keyed by the header row.
 *
 * Works without the zip extension (only zlib + SimpleXML, which are part of
 * every standard PHP build, including the official Docker images).
 */
class XlsxReader
{
    /** Largest uncompressed part that will be read (protects against zip bombs). */
    private const MAX_PART_BYTES = 64 * 1024 * 1024;

    public static function isXlsx(string $content): bool
    {
        return strncmp($content, "PK\x03\x04", 4) === 0;
    }

    /**
     * @return list<array<string, string>>
     */
    public static function rows(string $content): array
    {
        $files = self::zipEntries($content);
        if (!isset($files['xl/workbook.xml'])) {
            throw new InvalidArgumentException('The file is not an Excel workbook (.xlsx). Save it as .xlsx or CSV.');
        }

        $strings = [];
        if (isset($files['xl/sharedStrings.xml'])) {
            foreach (self::xml(self::extract($content, $files['xl/sharedStrings.xml']))->si as $si) {
                $strings[] = self::text($si);
            }
        }

        foreach (self::sheetPaths($content, $files) as $sheet) {
            $rows = self::sheetRows(self::extract($content, $files[$sheet]), $strings);
            if ($rows !== []) {
                return $rows;
            }
        }
        return [];
    }

    /**
     * @param list<string> $strings shared strings
     * @return list<array<string, string>>
     */
    private static function sheetRows(string $xml, array $strings): array
    {
        $grid = [];
        foreach (self::xml($xml)->sheetData->row ?? [] as $row) {
            $cells = [];
            $next = 0;
            foreach ($row->c as $c) {
                $ref = (string) $c['r'];
                $col = $ref !== '' ? self::columnIndex($ref) : $next;
                $next = $col + 1;
                $type = (string) $c['t'];
                if ($type === 's') {
                    $value = $strings[(int) $c->v] ?? '';
                } elseif ($type === 'inlineStr') {
                    $value = self::text($c->is);
                } else {
                    $value = (string) $c->v;
                }
                $cells[$col] = trim($value);
            }
            if ($cells !== [] && implode('', $cells) !== '') {
                $grid[] = $cells;
            }
        }
        if ($grid === []) {
            return [];
        }

        $headerCells = array_shift($grid);
        $width = max(array_keys($headerCells)) + 1;
        $header = [];
        for ($i = 0; $i < $width; $i++) {
            $name = ($headerCells[$i] ?? '') === '' ? 'Column ' . ($i + 1) : $headerCells[$i];
            while (in_array($name, $header, true)) {
                $name .= ' ';
            }
            $header[$i] = $name;
        }

        $rows = [];
        foreach ($grid as $cells) {
            $row = [];
            foreach ($header as $i => $name) {
                $row[$name] = $cells[$i] ?? '';
            }
            $rows[] = $row;
        }
        return $rows;
    }

    /**
     * Worksheet paths: the active sheet first, then the others in workbook order.
     *
     * @param array<string, array{offset: int, method: int, csize: int, size: int}> $files
     * @return list<string>
     */
    private static function sheetPaths(string $zip, array $files): array
    {
        $paths = [];
        if (isset($files['xl/_rels/workbook.xml.rels'])) {
            $targets = [];
            foreach (self::xml(self::extract($zip, $files['xl/_rels/workbook.xml.rels']))->Relationship as $rel) {
                $target = ltrim((string) $rel['Target'], '/');
                $targets[(string) $rel['Id']] = str_starts_with($target, 'xl/') ? $target : 'xl/' . $target;
            }
            $workbook = self::xml(self::extract($zip, $files['xl/workbook.xml']));
            foreach ($workbook->sheets->sheet ?? [] as $sheet) {
                $rid = (string) ($sheet->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'] ?? '');
                if (isset($targets[$rid], $files[$targets[$rid]])) {
                    $paths[] = $targets[$rid];
                }
            }
            $active = (int) ($workbook->bookViews->workbookView['activeTab'] ?? 0);
            if (isset($paths[$active])) {
                array_unshift($paths, $paths[$active]);
            }
        }
        $others = array_filter(array_keys($files), static fn ($f) => preg_match('#^xl/worksheets/[^/]+\.xml$#', $f) === 1);
        natsort($others);
        $paths = array_values(array_unique([...$paths, ...$others]));
        if ($paths === []) {
            throw new InvalidArgumentException('The workbook has no worksheets.');
        }
        return $paths;
    }

    private static function columnIndex(string $ref): int
    {
        $letters = strtoupper((string) preg_replace('/[^A-Za-z]/', '', $ref));
        $n = 0;
        foreach (str_split($letters) as $ch) {
            $n = $n * 26 + (ord($ch) - 64);
        }
        return max(0, $n - 1);
    }

    /** Text of a shared/inline string (plain <t> or rich text runs <r><t>). */
    private static function text(?SimpleXMLElement $node): string
    {
        if ($node === null) {
            return '';
        }
        if (isset($node->t)) {
            return (string) $node->t;
        }
        $text = '';
        foreach ($node->r ?? [] as $run) {
            $text .= (string) $run->t;
        }
        return $text;
    }

    private static function xml(string $xml): SimpleXMLElement
    {
        $previous = libxml_use_internal_errors(true);
        $doc = simplexml_load_string($xml, SimpleXMLElement::class, LIBXML_NONET | LIBXML_COMPACT);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if ($doc === false) {
            throw new InvalidArgumentException('The Excel file could not be read.');
        }
        return $doc;
    }

    /**
     * Read the zip central directory.
     *
     * @return array<string, array{offset: int, method: int, csize: int, size: int}>
     */
    private static function zipEntries(string $zip): array
    {
        $eocd = strlen($zip) >= 22 ? strrpos($zip, "PK\x05\x06", -18) : false;
        if ($eocd === false || strlen($zip) - $eocd > 22 + 65535) {
            throw new InvalidArgumentException('The Excel file is damaged or not an .xlsx file.');
        }
        $end = unpack('vdisk/vcdDisk/ventriesHere/ventries/Vsize/Voffset', substr($zip, $eocd + 4, 16));
        $pos = (int) $end['offset'];
        $files = [];
        for ($i = 0; $i < (int) $end['entries']; $i++) {
            if (substr($zip, $pos, 4) !== "PK\x01\x02") {
                throw new InvalidArgumentException('The Excel file is damaged.');
            }
            $h = unpack('vmethod/Vtime/Vcrc/Vcsize/Vsize/vnameLen/vextraLen/vcommentLen/vdisk/vintAttr/VextAttr/Voffset', substr($zip, $pos + 10, 36));
            $name = substr($zip, $pos + 46, (int) $h['nameLen']);
            $files[$name] = ['offset' => (int) $h['offset'], 'method' => (int) $h['method'], 'csize' => (int) $h['csize'], 'size' => (int) $h['size']];
            $pos += 46 + (int) $h['nameLen'] + (int) $h['extraLen'] + (int) $h['commentLen'];
        }
        return $files;
    }

    /**
     * @param array{offset: int, method: int, csize: int, size: int} $entry
     */
    private static function extract(string $zip, array $entry): string
    {
        $pos = $entry['offset'];
        if (substr($zip, $pos, 4) !== "PK\x03\x04" || $entry['size'] > self::MAX_PART_BYTES) {
            throw new InvalidArgumentException('The Excel file is damaged or too large.');
        }
        $h = unpack('vnameLen/vextraLen', substr($zip, $pos + 26, 4));
        $data = substr($zip, $pos + 30 + (int) $h['nameLen'] + (int) $h['extraLen'], $entry['csize']);
        if ($entry['method'] === 0) {
            return $data;
        }
        if ($entry['method'] !== 8) {
            throw new InvalidArgumentException('The Excel file uses an unsupported compression method.');
        }
        $out = @gzinflate($data, self::MAX_PART_BYTES);
        if ($out === false) {
            throw new InvalidArgumentException('The Excel file is damaged.');
        }
        return $out;
    }
}
