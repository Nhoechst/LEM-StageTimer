<?php

declare(strict_types=1);

namespace StatusDashboard;

/**
 * Translates the API's messages (errors, import results) into German. The
 * messages are written in English in the code; each pattern below rewrites one
 * of them (placeholders are regex groups), so no call site needs to change.
 */
class Lang
{
    public const LANGUAGES = ['en', 'de'];

    /**
     * Language for this request: the X-Lang header sent by the dashboard (the
     * user's choice at the bottom of the page), otherwise the browser's
     * Accept-Language, otherwise English.
     */
    public static function detect(?string $header, ?string $acceptLanguage): string
    {
        $header = strtolower(substr(trim((string) $header), 0, 2));
        if (in_array($header, self::LANGUAGES, true)) {
            return $header;
        }
        foreach (explode(',', (string) $acceptLanguage) as $part) {
            $code = strtolower(substr(trim($part), 0, 2));
            if (in_array($code, self::LANGUAGES, true)) {
                return $code;
            }
        }
        return 'en';
    }

    public static function translate(string $text, string $lang): string
    {
        if ($lang !== 'de' || $text === '') {
            return $text;
        }
        // "Row 3: <message>" etc.: translate the prefix and the message separately.
        if (preg_match('/^((?:Row|Location|Device|Firmware|PC) \d+: |Nothing could be restored from the backup: |Something went wrong: )(.+)$/s', $text, $m)) {
            return self::replace(self::PREFIXES, $m[1]) . self::translate($m[2], $lang);
        }
        return self::replace(self::GERMAN, $text);
    }

    /**
     * @param array<string, string> $patterns
     */
    private static function replace(array $patterns, string $text): string
    {
        foreach ($patterns as $pattern => $replacement) {
            $text = (string) preg_replace($pattern, $replacement, $text);
        }
        return $text;
    }

    /**
     * @param list<string> $texts
     * @return list<string>
     */
    public static function translateAll(array $texts, string $lang): array
    {
        return array_map(static fn ($t): string => self::translate((string) $t, $lang), $texts);
    }

    /** Prefixes of import / restore row errors. */
    private const PREFIXES = [
        '/^Row (\d+): /' => 'Zeile $1: ',
        '/^Location (\d+): /' => 'Standort $1: ',
        '/^Device (\d+): /' => 'Gerät $1: ',
        '/^Firmware (\d+): /' => 'Firmware $1: ',
        '/^PC (\d+): /' => 'PC $1: ',
        '/^Nothing could be restored from the backup: /' => 'Aus der Sicherung konnte nichts wiederhergestellt werden: ',
        '/^Something went wrong: /' => 'Ein Fehler ist aufgetreten: ',
    ];

    /** English pattern => German replacement, applied in order. */
    private const GERMAN = [
        // api.php
        '/^Timed out waiting for the discovery server log refresh\.$/' => 'Zeitüberschreitung beim Warten auf die Aktualisierung des Discovery-Server-Protokolls.',
        '/^You must change your temporary password before continuing\.$/' => 'Sie müssen Ihr temporäres Passwort ändern, bevor Sie fortfahren können.',
        '/^Choose a different password from your temporary password\.$/' => 'Wählen Sie ein anderes Passwort als Ihr temporäres Passwort.',
        '/^Location added\.$/' => 'Standort hinzugefügt.',
        '/^Location updated\.$/' => 'Standort aktualisiert.',
        '/^Location and its devices deleted\.$/' => 'Standort und zugehörige Geräte gelöscht.',
        '/^Device added\.$/' => 'Gerät hinzugefügt.',
        '/^Device updated\.$/' => 'Gerät aktualisiert.',
        '/^Device deleted\.$/' => 'Gerät gelöscht.',
        '/^PC added\.$/' => 'PC hinzugefügt.',
        '/^PC updated\.$/' => 'PC aktualisiert.',
        '/^PC deleted\.$/' => 'PC gelöscht.',
        '/^Check completed for (.+)\.$/' => 'Prüfung für $1 abgeschlossen.',
        '/^Checked (\d+) PC\(s\): (\d+) online, (\d+) offline\.$/' => '$1 PC(s) geprüft: $2 online, $3 offline.',
        '/^Photo saved\.$/' => 'Foto gespeichert.',
        '/^Photo removed\.$/' => 'Foto entfernt.',
        '/^Profile photo saved\.$/' => 'Profilbild gespeichert.',
        '/^Profile photo removed\.$/' => 'Profilbild entfernt.',
        '/^Please choose a photo to upload\.$/' => 'Bitte wählen Sie ein Foto zum Hochladen.',
        '/^The photo is too large\.$/' => 'Das Foto ist zu groß.',
        '/^The photo must be a JPEG, PNG, GIF or WebP image\.$/' => 'Das Foto muss ein JPEG-, PNG-, GIF- oder WebP-Bild sein.',
        '/^Unknown device\.$/' => 'Unbekanntes Gerät.',
        '/^No photo for this device\.$/' => 'Für dieses Gerät gibt es kein Foto.',
        '/^Cannot create the photo folder\.$/' => 'Der Fotoordner kann nicht angelegt werden.',
        '/^Cannot save the photo\.$/' => 'Das Foto kann nicht gespeichert werden.',
        '/^Cannot read the uploaded photo\.$/' => 'Das hochgeladene Foto kann nicht gelesen werden.',
        '/^Please log in to view your account photo\.$/' => 'Bitte anmelden, um das Profilbild zu sehen.',
        '/^No account photo is set\.$/' => 'Es ist kein Profilbild festgelegt.',
        '/^Latest firmware added\.$/' => 'Neueste Firmware hinzugefügt.',
        '/^Latest firmware updated\.$/' => 'Neueste Firmware aktualisiert.',
        '/^Latest firmware deleted\.$/' => 'Neueste Firmware gelöscht.',
        '/^Please choose a file to import\.$/' => 'Bitte eine Datei zum Importieren auswählen.',
        '/^The file is too large \(server limit: (.+)\)\.$/' => 'Die Datei ist zu groß (Server-Limit: $1).',
        '/^The file is too large\.$/' => 'Die Datei ist zu groß.',
        '/^The file could not be uploaded \(error (\d+)\)\.$/' => 'Die Datei konnte nicht hochgeladen werden (Fehler $1).',
        '/^Backup restored: (\d+) locations and (\d+) devices\/latest firmware versions\.$/' => 'Sicherung wiederhergestellt: $1 Standorte und $2 Geräte/neueste Firmware-Versionen.',
        '/^Import finished: (\d+) added, (\d+) updated, (\d+) skipped\./' => 'Import abgeschlossen: $1 hinzugefügt, $2 aktualisiert, $3 übersprungen.',
        '/ (\d+) new location\(s\) created\.$/' => ' $1 neue(r) Standort(e) angelegt.',
        '/^Checked all locations: /' => 'Alle Standorte geprüft: ',
        '/^Checked (.+): (\d+) device\(s\), (\d+) online, (\d+) offline\.$/' => '$1 geprüft: $2 Gerät(e), $3 online, $4 offline.',
        '/^Alle Standorte geprüft: (\d+) device\(s\), (\d+) online, (\d+) offline\.$/' => 'Alle Standorte geprüft: $1 Gerät(e), $2 online, $3 offline.',
        '/^Please wait (\d+) seconds before running another check\.$/' => 'Bitte $1 Sekunden warten, bevor die nächste Prüfung gestartet werden kann.',
        '/^A status check is already running\. Try again when it has finished\.$/' => 'Es läuft bereits eine Statusprüfung. Bitte erneut versuchen, wenn sie beendet ist.',
        '/^Too many requests\. Try again in (\d+) seconds\.$/' => 'Zu viele Anfragen. Bitte in $1 Sekunden erneut versuchen.',
        '/^Invalid JSON body\.$/' => 'Ungültige JSON-Daten.',
        '/^Unknown export type\.$/' => 'Unbekannter Exporttyp.',
        '/^Unknown location\.$/' => 'Unbekannter Standort.',
        '/^Method not allowed\.$/' => 'Methode nicht erlaubt.',
        '/^Unknown action\.$/' => 'Unbekannte Aktion.',
        '/^Your session has expired or the upload was too large\. Reload the page and try again\.$/' => 'Die Sitzung ist abgelaufen oder der Upload war zu groß. Bitte die Seite neu laden und erneut versuchen.',

        // Inventory
        '/^Location name is required\.$/' => 'Ein Standortname ist erforderlich.',
        "/^A location named '(.+)' already exists\.$/" => "Ein Standort mit dem Namen '$1' existiert bereits.",
        '/^Device name is required\.$/' => 'Ein Gerätename ist erforderlich.',
        '/^Please choose a valid location for the device\.$/' => 'Bitte einen gültigen Standort für das Gerät auswählen.',
        "/^'(.+)' is not a valid IP address or host name\.$/" => "'$1' ist keine gültige IP-Adresse und kein gültiger Hostname.",
        '/^Another device at this location already uses (.+)\.$/' => 'Ein anderes Gerät an diesem Standort verwendet bereits $1.',
        '/^PC name is required\.$/' => 'Ein PC-Name ist erforderlich.',
        "/^A PC named '(.+)' already exists\.$/" => "Ein PC mit dem Namen '$1' existiert bereits.",
        '/^Another PC already uses (.+)\.$/' => 'Ein anderer PC verwendet bereits $1.',
        '/^Please enter who checked the PC\.$/' => 'Bitte angeben, wer den PC geprüft hat.',
        '/^Model and latest firmware are required\.$/' => 'Modell und neueste Firmware sind erforderlich.',
        "/^The latest firmware for '(.+)' is already listed\.$/" => "Die neueste Firmware für '$1' ist bereits eingetragen.",
        "/^'(.+)' is not a valid maintenance date\.$/" => "'$1' ist kein gültiges Wartungsdatum.",
        '/^The record no longer exists\.$/' => 'Der Eintrag existiert nicht mehr.',

        // Admin backend (Users, Settings)
        '/^Administrator account created\. You are logged in\.$/' => 'Administratorkonto angelegt. Sie sind angemeldet.',
        '/^An administrator account already exists\. Please log in\.$/' => 'Es gibt bereits ein Administratorkonto. Bitte anmelden.',
        '/^Wrong user name or password\.$/' => 'Falscher Benutzername oder falsches Passwort.',
        '/^Logged in as (.+)\.$/' => 'Angemeldet als $1.',
        '/^Logged out\.$/' => 'Abgemeldet.',
        '/^Please log in to change the settings\.$/' => 'Bitte anmelden, um die Einstellungen zu ändern.',
        '/^Please log in to export data\.$/' => 'Bitte anmelden, um Daten zu exportieren.',
        '/^Please log in to make changes\.$/' => 'Bitte anmelden, um Änderungen vorzunehmen.',
        '/^Settings saved\.$/' => 'Einstellungen gespeichert.',
        '/^User added\.$/' => 'Benutzer hinzugefügt.',
        '/^User deleted\.$/' => 'Benutzer gelöscht.',
        '/^Password changed\.$/' => 'Passwort geändert.',
        '/^The current password is wrong\.$/' => 'Das aktuelle Passwort ist falsch.',
        '/^You can’t delete your own account\.$/' => 'Das eigene Konto kann nicht gelöscht werden.',
        '/^The last user can’t be deleted\.$/' => 'Der letzte Benutzer kann nicht gelöscht werden.',
        '/^Unknown user\.$/' => 'Unbekannter Benutzer.',
        "/^A user named '(.+)' already exists\.$/" => "Ein Benutzer mit dem Namen '$1' existiert bereits.",
        '/^User names have 2 to 64 letters, digits or \. _ @ -$/' => 'Benutzernamen haben 2 bis 64 Buchstaben, Ziffern oder . _ @ -',
        '/^Passwords need at least (\d+) characters\.$/' => 'Passwörter brauchen mindestens $1 Zeichen.',
        '/^The title is required\.$/' => 'Ein Titel ist erforderlich.',
        "/^(.+): '(.*)' is not a valid time zone \(e\.g\. America\/New_York\)\.$/" => "$1: '$2' ist keine gültige Zeitzone (z. B. Europe/Berlin).",
        '/^Country codes have 1 to 10 letters or digits \(e\.g\. us, de\)\.$/' => 'Länderkürzel haben 1 bis 10 Buchstaben oder Ziffern (z. B. us, de).',
        "/^Country '(.+)' needs a name\.$/" => "Land '$1' braucht einen Namen.",
        "/^Country code '(.+)' is used twice\.$/" => "Länderkürzel '$1' ist doppelt vergeben.",
        '/^At least one country is required\.$/' => 'Mindestens ein Land ist erforderlich.',
        "/^Header status devices need a name and a valid IP address or host name \('(.*)'\)\.$/" => "Statusgeräte in der Kopfzeile brauchen einen Namen und eine gültige IP-Adresse oder einen Hostnamen ('$1').",
        '/^At most 10 header status devices\.$/' => 'Höchstens 10 Statusgeräte in der Kopfzeile.',
        '/^At least one online status value is required\.$/' => 'Mindestens ein Online-Statuswert ist erforderlich.',
        "/^(.+): '(.+)' is not a valid network \(e\.g\. 192\.168\.0\.0\/16\)\.$/" => "$1: '$2' ist kein gültiges Netz (z. B. 192.168.0.0/16).",
        '/^Check times must be HH:MM \(24 hour\), e\.g\. 00:00, 12:00\.$/' => 'Prüfzeiten im Format HH:MM (24 Stunden), z. B. 00:00, 12:00.',
        '/^At least one TCP port is required\.$/' => 'Mindestens ein TCP-Port ist erforderlich.',
        '/^The login limit can’t be turned off\.$/' => 'Das Anmeldelimit kann nicht abgeschaltet werden.',
        '/^(.+) must be a whole number from (-?\d+) to (\d+)\.$/' => '$1 muss eine ganze Zahl von $2 bis $3 sein.',
        '/^(.+) must be a number from (.+) to (.+)\.$/' => '$1 muss eine Zahl von $2 bis $3 sein.',

        // Outage emails
        "/^(.+): '(.*)' is not a valid email address\.$/" => "$1: '$2' ist keine gültige E-Mail-Adresse.",
        "/^'(.*)' is not a valid email address\.$/" => "'$1' ist keine gültige E-Mail-Adresse.",
        '/^Email times must be HH:MM \(24 hour\), e\.g\. 08:00\.$/' => 'E-Mail-Zeiten im Format HH:MM (24 Stunden), z. B. 08:00.',
        '/^Choose at least one day and one time for the outage emails\.$/' => 'Mindestens einen Tag und eine Uhrzeit für die Ausfallmeldungen wählen.',
        '/^Enter a From address for the outage emails\.$/' => 'Eine Absenderadresse für die Ausfallmeldungen eingeben.',
        '/^Dashboard link must be an http:\/\/ or https:\/\/ address\.$/' => 'Der Dashboard-Link muss eine http://- oder https://-Adresse sein.',
        '/^At most (\d+) recipients per country\.$/' => 'Höchstens $1 Empfänger pro Land.',
        '/^The distribution list of (.+) is empty\.$/' => 'Der Verteiler für $1 ist leer.',
        '/^Unknown country\.$/' => 'Unbekanntes Land.',
        '/^Nothing needs attention, so no email was sent \(Only send when devices need attention\)\.$/' => 'Kein Handlungsbedarf, daher wurde keine E-Mail gesendet (Nur senden, wenn Geräte Handlungsbedarf haben).',
        '/^Outage email sent to (\d+) of (\d+) recipient\(s\)\.\s*/' => 'Ausfallmeldung an $1 von $2 Empfänger(n) gesendet. ',
        '/^Outage email sent to (\d+) recipient\(s\)\.$/' => 'Ausfallmeldung an $1 Empfänger gesendet.',
        '/^Email is turned off for this dashboard\. Turn on Email service in Settings → Email and save\.$/' => 'E-Mail ist für dieses Dashboard ausgeschaltet. Unter Einstellungen → E-Mail den E-Mail-Dienst einschalten und speichern.',
        '/No SMTP server is set\. Enter it in Settings → Email\.$/' => 'Es ist kein SMTP-Server eingestellt. Bitte unter Einstellungen → E-Mail eingeben.',
        '/Cannot connect to the SMTP server (.+?)( \(.*\))?\. Check the host, port, encryption and firewall\.$/s' => 'Keine Verbindung zum SMTP-Server $1$2. Server, Port, Verschlüsselung und Firewall prüfen.',
        '/The SMTP server does not offer STARTTLS\. Choose SSL\/TLS or no encryption\.$/' => 'Der SMTP-Server bietet kein STARTTLS an. SSL/TLS oder keine Verschlüsselung wählen.',
        '/TLS with the SMTP server failed( \(is the certificate valid for this host name\?\))?\.$/' => 'TLS mit dem SMTP-Server fehlgeschlagen (ist das Zertifikat für diesen Hostnamen gültig?).',
        '/SMTP login failed: (.*) Check the SMTP user name and password\.$/s' => 'SMTP-Anmeldung fehlgeschlagen: $1 SMTP-Benutzer und Passwort prüfen.',
        '/The SMTP server offers no supported login method \(PLAIN or LOGIN\)\.$/' => 'Der SMTP-Server bietet kein unterstütztes Anmeldeverfahren (PLAIN oder LOGIN) an.',
        '/The SMTP server answered: /' => 'Der SMTP-Server antwortete: ',
        '/The SMTP server did not answer in time\.$/' => 'Der SMTP-Server hat nicht rechtzeitig geantwortet.',
        '/The SMTP server closed the connection\.$/' => 'Der SMTP-Server hat die Verbindung geschlossen.',
        '/The connection to the SMTP server was lost\.$/' => 'Die Verbindung zum SMTP-Server wurde unterbrochen.',
        '/The saved SMTP password can’t be read\. Enter it again in Settings → Email\.$/' => 'Das gespeicherte SMTP-Passwort kann nicht gelesen werden. Bitte unter Einstellungen → E-Mail erneut eingeben.',
        '/^SMTP login needs STARTTLS or SSL\/TLS, so the password is not sent unencrypted\.$/' => 'Die SMTP-Anmeldung erfordert STARTTLS oder SSL/TLS, damit das Passwort nicht unverschlüsselt gesendet wird.',
        "/^SMTP server: '(.*)' is not a valid host name or IP address\.$/" => "SMTP-Server: '$1' ist kein gültiger Hostname und keine gültige IP-Adresse.",
        '/^Enter the SMTP server\.$/' => 'Den SMTP-Server eingeben.',
        '/^SMTP port must be a whole number from 1 to 65535\.$/' => 'Der SMTP-Port muss eine ganze Zahl von 1 bis 65535 sein.',
        '/^SMTP password must be at most 1024 bytes without NUL or newline characters\.$/' => 'Das SMTP-Passwort darf höchstens 1024 Bytes ohne NUL- oder Zeilenumbruchzeichen haben.',
        '/^Enter the SMTP password for this server, port and user\.$/' => 'Das SMTP-Passwort für diesen Server, Port und Benutzer eingeben.',
        '/^Test email sent\.$/' => 'Test-E-Mail gesendet.',

        // Importer / XlsxReader
        '/^Unknown import type\.$/' => 'Unbekannter Importtyp.',
        '/^The file is empty\.$/' => 'Die Datei ist leer.',
        '/^The file looks like JSON but could not be read\.$/' => 'Die Datei sieht wie JSON aus, konnte aber nicht gelesen werden.',
        '/^This is a full backup\. Restore it from the Device Status page\.$/' => 'Dies ist eine vollständige Sicherung. Bitte auf der Seite Gerätestatus wiederherstellen.',
        '/^The JSON file must contain a list of records or a dashboard backup\.$/' => 'Die JSON-Datei muss eine Liste von Einträgen oder eine Dashboard-Sicherung enthalten.',
        '/^No records were found in the file\.$/' => 'In der Datei wurden keine Einträge gefunden.',
        '/^Could not find a "(.+)" column\. Columns found: (.*)\.$/' => 'Keine Spalte "$1" gefunden. Gefundene Spalten: $2.',
        '/^No location given\. Add a Location column or import on the location’s page\.$/' => 'Kein Standort angegeben. Eine Spalte „Location“ hinzufügen oder auf der Seite des Standorts importieren.',
        '/^The file is not an Excel workbook \(\.xlsx\)\. Save it as \.xlsx or CSV\.$/' => 'Die Datei ist keine Excel-Arbeitsmappe (.xlsx). Bitte als .xlsx oder CSV speichern.',
        '/^The workbook has no worksheets\.$/' => 'Die Arbeitsmappe enthält keine Tabellenblätter.',
        '/^The Excel file could not be read\.$/' => 'Die Excel-Datei konnte nicht gelesen werden.',
        '/^The Excel file is damaged or not an \.xlsx file\.$/' => 'Die Excel-Datei ist beschädigt oder keine .xlsx-Datei.',
        '/^The Excel file is damaged or too large\.$/' => 'Die Excel-Datei ist beschädigt oder zu groß.',
        '/^The Excel file is damaged\.$/' => 'Die Excel-Datei ist beschädigt.',
        '/^The Excel file uses an unsupported compression method\.$/' => 'Die Excel-Datei verwendet ein nicht unterstütztes Komprimierungsverfahren.',
    ];
}
