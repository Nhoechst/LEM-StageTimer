<?php

declare(strict_types=1);

use StatusDashboard\CheckGuard;
use StatusDashboard\Database;
use StatusDashboard\EquipmentService;
use StatusDashboard\Inventory;
use StatusDashboard\Lang;
use StatusDashboard\NetworkUsage;
use StatusDashboard\OutageMailer;
use StatusDashboard\Photos;
use StatusDashboard\Pinger;
use StatusDashboard\RateLimiter;
use StatusDashboard\Settings;
use StatusDashboard\SshPassword;
use StatusDashboard\Store;
use StatusDashboard\Telemetry;
use StatusDashboard\Users;

spl_autoload_register(static function (string $class): void {
    $prefix = 'StatusDashboard\\';
    if (strncmp($class, $prefix, strlen($prefix)) === 0) {
        $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

/**
 * Load the configuration: the defaults below, overridden by the admin Settings
 * page (settings table of data/dashboard.db, see Settings). An old config/config.php is still
 * read (before the saved settings) so existing installations keep working.
 * $reload re-reads it after the settings were saved.
 *
 * @return array<string, mixed>
 */
function dashboard_config(bool $reload = false): array
{
    static $config = null;
    if ($config === null || $reload) {
        $root = dirname(__DIR__);
        $config = [
            // Title and subtitle shown at the top of the dashboard.
            'app_title'    => 'Equipment Status',
            'app_subtitle' => 'Locations, devices and firmware compliance',

            // Teams (key => name). Every location belongs to one team; the header
            // switches between them. The first team is the default for locations
            // without a team.
            'teams' => ['us' => 'United States', 'de' => 'Germany'],

            // Time zone of each team. Automatic checks (check_schedule) run at each
            // team's local time and check only that team's locations. Teams not
            // listed use `timezone`.
            'team_timezones' => ['us' => 'America/Chicago', 'de' => 'Europe/Berlin'],

            // Local timezone used to display dates and for the check schedule,
            // e.g. 'America/Chicago'. Default: the TZ environment variable, then
            // PHP's date.timezone, then UTC.
            'timezone' => getenv('TZ') ?: (ini_get('date.timezone') ?: 'UTC'),

            // SQLite database with all data (inventory, accounts, settings); the web
            // server user needs write access to its folder.
            'database' => $root . '/data/dashboard.db',

            // Crucial equipment whose status is always shown in the top bar.
            // Pinged at most once every header_check_seconds (shared by all users).
            'header_devices'       => [['name' => 'Discovery Server', 'ip' => '10.126.5.12']],
            'header_check_seconds' => 60,

            // Status values (case-insensitive) that mean a device is online.
            'online_values' => ['online', 'up', 'yes', 'true', '1', 'success', 'reachable', 'ok'],

            // Hours after which a device's last check is shown as "Stale" (0 = off).
            'stale_after_hours' => 36,

            // Corporate network identifier (CIDR). IPv4 addresses outside these ranges
            // are shown as "External Network" and never pinged. [] = don't use it.
            'corporate_networks' => ['10.0.0.0/8'],

            // Networks outside the corporate network (CIDR). Devices with an IP
            // address in one of them are shown as "External Network" and never pinged.
            'external_networks' => ['192.0.0.0/8'],

            // PC Maintenance: a PC is due when its last maintenance is older than this.
            'maintenance_interval_days' => 90,

            // 'minimum' (version >= approved) or 'exact' (must match an approved version).
            'firmware_mode' => 'minimum',

            // Maximum size of an uploaded import file in bytes.
            'max_import_bytes' => 5 * 1024 * 1024,

            // Largest equipment photo accepted (photos are resized in the browser first).
            'max_photo_bytes' => 5 * 1024 * 1024,

            // Ping settings for "Check now", bin/check.php and ping.php.
            'ping' => [
                'timeout_seconds' => 2,   // per ping (Status-Check ping_api.py used 2)
                'count'           => 1,
                'parallel'        => 32,  // devices pinged at the same time
                // 'auto' = system ping if it works (plus a TCP retry for devices that
                // don't answer ping), otherwise TCP, then an OSC /info query
                // on UDP 10023 for X32/M32 consoles. 'icmp' = system ping only.
                // 'tcp' = TCP connect only (no ping package or privileges needed,
                // e.g. in Pelican / Docker containers).
                'method'          => 'auto',
                // Ports tried by the TCP check. A device that accepts or refuses a
                // connection on any of them is online.
                'tcp_ports'       => [80, 443, 22, 23, 554, 8080, 135, 139, 445, 3389],
            ],

            // Automatic checks (bin/check.php from cron or --loop) run only at these
            // local times (per team, see team_timezones), once each. A slot still runs if the scheduler starts it
            // up to `check_window_minutes` late.
            'check_schedule'       => ['00:00', '12:00'],
            'check_window_minutes' => 59,

            // Seconds after a manual check ("Check all" / "Check" buttons) before
            // the next one may be started.
            'manual_check_cooldown_seconds' => 60,

            // Flood protection per client IP: [requests, per seconds]. Over the limit
            // the API answers HTTP 429 with a Retry-After header. [0, 0] = off.
            'rate_limits' => [
                'api'   => [120, 60],  // all api.php requests
                'write' => [30, 60],   // saves, deletes and imports
                'ping'  => [60, 60],   // GET /ping?ip=...
                'login' => [10, 300],  // login attempts
            ],

            // GET /ping?ip=... JSON endpoint (same response as Status-Check's ping_api.py).
            // Set to false to disable it.
            'ping_api' => true,

            // Outage notification emails (Settings → Email): a snapshot of each country's
            // "Needs attention" list sent through the SMTP server to that country's distribution
            // list on these week days / times (country time zone). Default: Wednesday 08:00, off.
            'email' => OutageMailer::DEFAULTS,
        ];
        if (is_file($root . '/config/config.php')) {
            $legacy = (array) require $root . '/config/config.php';
            $config = array_replace($config, $legacy);
            if (isset($legacy['data_file']) && !isset($legacy['database'])) {
                // Old setting: keep the data in the same folder.
                $config['database'] = dirname((string) $legacy['data_file']) . '/dashboard.db';
            }
        }
        $config = array_replace($config, Settings::load(Database::open(
            (string) $config['database'],
            (string) ($config['data_file'] ?? '') // old JSON inventory, imported once
        )));
        $tz = (string) ($config['timezone'] ?? 'UTC');
        if (!in_array($tz, timezone_identifiers_list(), true) || !date_default_timezone_set($tz)) {
            date_default_timezone_set('UTC');
        }
    }
    return $config;
}

function dashboard_db(): Database
{
    $config = dashboard_config();
    return Database::open((string) $config['database'], (string) ($config['data_file'] ?? ''));
}

function dashboard_store(): Store
{
    return new Store(dashboard_db());
}

function dashboard_telemetry(): Telemetry
{
    return new Telemetry(dashboard_db());
}

function dashboard_pinger(): Pinger
{
    $ping = (array) (dashboard_config()['ping'] ?? []);
    return new Pinger(
        (int) ($ping['timeout_seconds'] ?? 2),
        (int) ($ping['count'] ?? 1),
        (int) ($ping['parallel'] ?? 32),
        (string) ($ping['method'] ?? 'auto'),
        array_values((array) ($ping['tcp_ports'] ?? [80, 443, 22, 23, 554, 8080, 135, 139, 445, 3389])),
    );
}

function dashboard_track_traffic(): void
{
    $responseBytes = 0;
    ob_start(static function (string $output) use (&$responseBytes): string {
        $responseBytes += strlen($output);
        return $output;
    }, 8192);
    register_shutdown_function(static function () use (&$responseBytes): void {
        try {
            if (ob_get_level() > 0) {
                ob_end_flush();
            }
            NetworkUsage::recordHttp(dashboard_db(), $_SERVER, $responseBytes, headers_list());
        } catch (\Throwable $e) {
            error_log('Equipment dashboard: traffic monitoring: ' . $e->getMessage());
        }
    });
}

/**
 * Team key for a stored/imported value: a team key or name (case-insensitive,
 * e.g. "DE", "Germany"); anything else is the first (default) team.
 */
function dashboard_team(mixed $value): string
{
    $teams = (array) (dashboard_config()['teams'] ?? []);
    $value = strtolower(trim(is_scalar($value) ? (string) $value : ''));
    foreach ($teams as $key => $name) {
        if ($value === strtolower((string) $key) || $value === strtolower((string) $name)) {
            return (string) $key;
        }
    }
    return (string) (array_key_first($teams) ?? '');
}

/**
 * Display name of a team.
 */
function dashboard_team_name(string $team): string
{
    return (string) (((array) (dashboard_config()['teams'] ?? []))[$team] ?? $team);
}

/**
 * Time zone of a team (team_timezones), falling back to `timezone`.
 */
function dashboard_team_timezone(string $team): string
{
    $tz = (string) (((array) (dashboard_config()['team_timezones'] ?? []))[$team] ?? '');
    return in_array($tz, timezone_identifiers_list(), true) ? $tz : date_default_timezone_get();
}

/**
 * @return list<string> Team keys in configuration order.
 */
function dashboard_team_keys(): array
{
    $keys = array_map('strval', array_keys((array) (dashboard_config()['teams'] ?? [])));
    return $keys !== [] ? $keys : [''];
}

/**
 * Language of the current request ('en' or 'de'), see Lang::detect().
 */
function dashboard_lang(): string
{
    return Lang::detect($_SERVER['HTTP_X_LANG'] ?? null, $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? null);
}

function dashboard_data_dir(): string
{
    return dirname((string) dashboard_config()['database']);
}

function dashboard_photos(): Photos
{
    return new Photos(dashboard_data_dir() . '/photos', (int) (dashboard_config()['max_photo_bytes'] ?? 5242880));
}

function dashboard_users(): Users
{
    return new Users(dashboard_db());
}

/**
 * Status of the header devices (top bar). Pings them when the last result is
 * older than header_check_seconds; a lock file makes concurrent requests wait
 * for one ping instead of pinging again, so the devices are pinged at most once
 * per interval however many users are open. Results are cached in the
 * database (state "header_status").
 *
 * @return list<array{name: string, ip: string, status: string, latency_ms: float|null, checked: int|null}>
 */
function dashboard_header_status(bool $refresh): array
{
    $config = dashboard_config();
    $devices = array_values(array_filter((array) ($config['header_devices'] ?? []), 'is_array'));
    $db = dashboard_db();
    $max = max(30, (int) ($config['header_check_seconds'] ?? 60));
    $now = time();
    $due = static function (array $cache) use ($devices, $now, $max): array {
        $hosts = [];
        foreach ($devices as $d) {
            $ip = (string) ($d['ip'] ?? '');
            if ($ip !== '' && $now - (int) ($cache[$ip]['checked'] ?? 0) >= $max) {
                $hosts[] = $ip;
            }
        }
        return array_values(array_unique($hosts));
    };

    $cache = $db->stateRead('header_status');
    if ($refresh && $devices !== [] && $due($cache) !== []) {
        // Ping outside the database transaction so other requests aren't blocked.
        $lock = @fopen(dashboard_data_dir() . '/header_status.lock', 'c');
        try {
            if ($lock !== false && flock($lock, LOCK_EX)) {
                $cache = $db->stateRead('header_status');
                $hosts = $due($cache); // another request may have pinged them meanwhile
                if ($hosts !== []) {
                    $pinger = dashboard_pinger();
                    $method = $pinger->effectiveMethod();
                    $results = $pinger->pingMany($hosts);
                    NetworkUsage::record($db, $results, $config, $method);
                    $cache = $db->stateUpdate('header_status', static function (array &$data) use ($hosts, $results, $devices): array {
                        foreach ($hosts as $ip) {
                            $data[$ip] = ['online' => (bool) $results[$ip]['online'], 'latency_ms' => $results[$ip]['latency_ms'], 'checked' => time()];
                        }
                        $keep = array_flip(array_map(static fn ($d) => (string) ($d['ip'] ?? ''), $devices));
                        $data = array_intersect_key($data, $keep);
                        return $data;
                    });
                }
            }
        } catch (\Throwable $e) {
            error_log('Equipment dashboard: header status: ' . $e->getMessage());
        } finally {
            if ($lock !== false) {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        }
    }

    $out = [];
    foreach ($devices as $d) {
        $ip = (string) ($d['ip'] ?? '');
        $r = $cache[$ip] ?? null;
        $out[] = [
            'name'       => (string) ($d['name'] ?? $ip),
            'ip'         => $ip,
            'log_enabled' => (bool) ($d['log_enabled'] ?? false),
            'status'     => $r === null ? 'unknown' : ($r['online'] ? 'online' : 'offline'),
            'latency_ms' => $r !== null && $r['online'] && $r['latency_ms'] !== null ? (float) $r['latency_ms'] : null,
            'checked'    => $r !== null ? (int) $r['checked'] : null,
        ];
    }
    return $out;
}

function dashboard_check_guard(): CheckGuard
{
    return new CheckGuard(dashboard_db(), dashboard_data_dir(), (int) (dashboard_config()['manual_check_cooldown_seconds'] ?? 60));
}

/**
 * @return list<string>
 */
function dashboard_check_schedule(): array
{
    return CheckGuard::normaliseTimes((array) (dashboard_config()['check_schedule'] ?? []));
}

/**
 * Flood protection: count a request of the current client in $bucket and stop
 * with HTTP 429 when the client is over the limit.
 */
function enforce_rate_limit(string $bucket): void
{
    $limit = (array) ((dashboard_config()['rate_limits'] ?? [])[$bucket] ?? []);
    $max = (int) ($limit[0] ?? 0);
    $window = (int) ($limit[1] ?? 0);
    if ($max <= 0 || $window <= 0) {
        return;
    }
    try {
        $wait = (new RateLimiter(dashboard_db()))
            ->hit($bucket, (string) ($_SERVER['REMOTE_ADDR'] ?? 'cli'), $max, $window);
    } catch (\Throwable $e) {
        return; // never lock everyone out because the limiter can't be written
    }
    if ($wait > 0) {
        http_response_code(429);
        header('Retry-After: ' . $wait);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode([
            'ok' => false,
            'error' => Lang::translate("Too many requests. Try again in {$wait} seconds.", dashboard_lang()),
            'retry_after' => $wait,
        ]);
        exit;
    }
}

/**
 * Ping all devices (or the devices of one site) and save Online/Offline,
 * skipping devices marked as External Network or in `external_networks`,
 * the check time and the latency - the equivalent of the Status-Check flows.
 * With $wait = false a CheckBusy is thrown when another check is running;
 * $team limits the check to one team's locations, standalone Dante devices and PCs.
 *
 * $target: 'devices' (Device Status), 'device' (one location device), 'pcs'
 * (PC Maintenance's own PC list), 'standalone' (location-free Dante only), or
 * 'all' (used by scheduled checks).
 * A site check is devices only; location network exclusions do not apply to standalone Dante.
 *
 * @param (callable(array<string, mixed>, array<string, mixed>): void)|null $onResult
 * @return array{checked: int, online: int, offline: int}
 */
function run_status_check(?int $siteId = null, ?callable $onResult = null, bool $wait = false, ?string $team = null, string $target = 'all', ?int $deviceId = null): array
{
    $guard = dashboard_check_guard();
    $guard->acquire($wait); // only one check at a time; throws CheckBusy
    try {
        return run_status_check_locked($siteId, $onResult, $team, $siteId !== null && $target !== 'device' ? 'devices' : $target, $deviceId);
    } finally {
        $guard->release();
    }
}

/**
 * @param (callable(array<string, mixed>, array<string, mixed>): void)|null $onResult
 * @return array{checked: int, online: int, offline: int}
 */
function run_status_check_locked(?int $siteId, ?callable $onResult, ?string $team = null, string $target = 'all', ?int $deviceId = null): array
{
    $config = dashboard_config();
    $store = dashboard_store();
    $telemetry = dashboard_telemetry();
    [$data, $versions] = dashboard_db()->transaction(
        static fn (): array => [$store->load(), $telemetry->deviceVersions()],
        false
    );

    // Only the locations of one team (automatic checks run per team).
    $teamSites = null;
    if ($team !== null) {
        $teamSites = [];
        foreach ($data['sites'] as $site) {
            if (dashboard_team($site['team'] ?? '') === $team) {
                $teamSites[(int) $site['id']] = true;
            }
        }
    }

    $pingable = static fn (array $r): bool => trim((string) ($r['ip'] ?? '')) !== ''
        && !Inventory::isUndefinedAddress((string) $r['ip'])
        && !EquipmentService::isExternalRecord($r, $config);

    // Keyed by collection and id (devices and PCs are separate lists).
    $devices = [];
    if ($target !== 'pcs') {
        foreach ($data['devices'] as $device) {
            if (($siteId === null || (int) $device['site_id'] === $siteId)
                && ($target !== 'device' || (int) $device['id'] === $deviceId)
                && ($target !== 'standalone' || Inventory::isStandalone($device))
                && ($teamSites === null || (Inventory::isStandalone($device)
                    ? dashboard_team($device['team'] ?? '') === $team
                    : isset($teamSites[(int) $device['site_id']]))) && $pingable($device)) {
                $devices['devices:' . (int) $device['id']] = $device;
            }
        }
    }
    if (!in_array($target, ['devices', 'device', 'standalone'], true)) {
        foreach ($data['pcs'] as $pc) {
            if (($team === null || dashboard_team($pc['team'] ?? '') === $team) && $pingable($pc)) {
                $devices['pcs:' . (int) $pc['id']] = $pc;
            }
        }
    }

    // Ping outside the lock so the dashboard stays usable while checks run.
    $pinger = dashboard_pinger();
    $effectiveMethod = $pinger->effectiveMethod();
    $pings = $pinger->pingMany(array_values(array_unique(array_map(
        static fn (array $d): string => trim((string) $d['ip']),
        $devices
    ))));
    NetworkUsage::record(dashboard_db(), $pings, $config, $effectiveMethod);
    $checkedTimestamp = time();
    $checkedAt = date('c', $checkedTimestamp);

    $results = [];
    foreach ($devices as $id => $device) {
        $results[$id] = $pings[trim((string) $device['ip'])];
        if ($onResult !== null) {
            $onResult($device, $results[$id]);
        }
    }

    $store->update(static function (array &$d) use ($results, $checkedAt, $checkedTimestamp, $devices, $versions, $telemetry, $pingable): void {
        $telemetry->prune();
        $currentConfig = dashboard_config(true);
        foreach (['devices', 'pcs'] as $collection) {
            foreach ($d[$collection] as $i => $record) {
                $key = $collection . ':' . (int) $record['id'];
                $r = $results[$key] ?? null;
                if ($r !== null && $record == $devices[$key] && $pingable($record)
                    && !EquipmentService::isExternalRecord($record, $currentConfig)) {
                    if ($collection === 'devices'
                        && !$telemetry->record($record, $versions[(int) $record['id']] ?? '', $r, $checkedTimestamp)) {
                        continue;
                    }
                    $status = $r['online'] ? Inventory::STATUS_ONLINE : Inventory::STATUS_OFFLINE;
                    Inventory::applyStatus($d[$collection][$i], $status, $checkedAt, $r['latency_ms']);
                }
            }
        }
    });
    NetworkUsage::record(dashboard_db(), $pings, $config, $effectiveMethod, $checkedTimestamp);

    $online = count(array_filter($results, static fn (array $r): bool => $r['online']));
    return ['checked' => count($results), 'online' => $online, 'offline' => count($results) - $online];
}

function dashboard_mailer(): OutageMailer
{
    return new OutageMailer(dashboard_config(), new SshPassword(dashboard_data_dir() . '/ssh/password.key'));
}

/**
 * Send the outage notification of one country to its distribution list now.
 *
 * @return array{sent: int, failed: list<string>, skipped: bool, attention: int, error: string}
 */
function dashboard_send_report(string $team): array
{
    $mailer = dashboard_mailer();
    $tz = dashboard_team_timezone($team);
    $snapshot = $mailer->snapshot(dashboard_store()->load(), $team, 'dashboard_team');
    $result = $mailer->sendReport($team, dashboard_team_name($team), $tz, $snapshot);
    OutageMailer::record(dashboard_db(), $team, $result);
    return $result;
}

/**
 * Send every country's outage notification whose slot (`email.days` at
 * `email.times`, country time zone) is due and hasn't been sent yet.
 *
 * @return array<string, array{sent: int, failed: list<string>, skipped: bool, attention: int, error: string}|string>
 *         Result (or error message) per country that was due.
 */
function dashboard_send_due_reports(): array
{
    $mailer = dashboard_mailer();
    $email = OutageMailer::settings(dashboard_config());
    $out = [];
    foreach (dashboard_team_keys() as $team) {
        if (OutageMailer::recipients($email, $team) === []) {
            continue;
        }
        if ($mailer->claimDueSlot(dashboard_db(), $team, dashboard_team_timezone($team)) === null) {
            continue;
        }
        try {
            $out[$team] = dashboard_send_report($team);
        } catch (\Throwable $e) {
            error_log('Equipment dashboard: outage email for ' . $team . ': ' . $e->getMessage());
            $out[$team] = $e->getMessage();
        }
    }
    return $out;
}

/**
 * Outage email status per country for Settings → Email.
 *
 * @return array<string, mixed>
 */
function dashboard_email_status(): array
{
    $mailer = dashboard_mailer();
    $state = (array) (dashboard_db()->stateRead('email')['teams'] ?? []);
    $teams = [];
    foreach (dashboard_team_keys() as $team) {
        $tz = dashboard_team_timezone($team);
        $s = (array) ($state[$team] ?? []);
        $teams[$team] = [
            'timezone'    => $tz,
            'next'        => $mailer->nextSlot($tz),
            'last_sent'   => isset($s['last_sent']) ? (int) $s['last_sent'] : null,
            'last_run'    => isset($s['last_run']) ? (int) $s['last_run'] : null,
            'last_result' => is_array($s['last_result'] ?? null)
                ? ['error' => Lang::translate((string) ($s['last_result']['error'] ?? ''), dashboard_lang())] + $s['last_result'] : null,
        ];
    }
    return ['teams' => $teams];
}

function start_session(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_name('equipment_dashboard');
        session_start([
            'cookie_httponly' => true,
            'cookie_secure' => filter_var($_SERVER['HTTPS'] ?? false, FILTER_VALIDATE_BOOL),
            'cookie_samesite' => 'Strict',
            'use_strict_mode' => true,
        ]);
    }
}

/**
 * User name of the signed-in admin, or null. Sessions end after 12 hours
 * without activity.
 */
function current_user(): ?string
{
    start_session();
    $user = $_SESSION['user'] ?? null;
    if (!is_string($user)) {
        return null;
    }
    if (time() - (int) ($_SESSION['seen'] ?? 0) > 43200 || !dashboard_users()->exists($user)) {
        unset($_SESSION['user'], $_SESSION['seen']);
        return null;
    }
    $_SESSION['seen'] = time();
    return $user;
}

/**
 * Sign in (or out with null). A new session id prevents session fixation.
 */
function set_current_user(?string $user): void
{
    start_session();
    session_regenerate_id(true);
    if ($user === null) {
        unset($_SESSION['user'], $_SESSION['seen']);
    } else {
        $_SESSION['user'] = $user;
        $_SESSION['seen'] = time();
    }
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf'];
}

function csrf_valid(mixed $token): bool
{
    start_session();
    return is_string($token) && !empty($_SESSION['csrf']) && hash_equals((string) $_SESSION['csrf'], $token);
}
