<?php

declare(strict_types=1);

/**
 * GET /ping?ip=<hostname-or-ip>
 *
 * Same JSON as Status-Check's ping_api.py:
 *   {"ip": "10.1.2.3", "online": true, "latency_ms": 1.23}
 *   {"ip": "10.1.2.3", "online": false, "latency_ms": null, "error": "..."}
 *
 * The ip value may also be a URL such as http://10.1.2.3:8080/ (the IP is extracted).
 */

require __DIR__ . '/src/bootstrap.php';

use StatusDashboard\Inventory;

dashboard_track_traffic();
header('Content-Type: application/json');
header('Cache-Control: no-store');

enforce_rate_limit('ping');

if (!(dashboard_config()['ping_api'] ?? true)) {
    http_response_code(404);
    echo json_encode(['error' => 'The ping API is disabled.']);
    exit;
}

$ip = $_GET['ip'] ?? null;
if (!is_string($ip) || trim($ip) === '') {
    http_response_code(422);
    echo json_encode(['error' => "Missing query parameter 'ip'."]);
    exit;
}

$host = Inventory::extractHost($ip);
if (!Inventory::isValidAddress($host)) {
    echo json_encode(['ip' => $ip, 'online' => false, 'latency_ms' => null, 'error' => 'Invalid IP address or host name']);
    exit;
}

$data = dashboard_store()->load();
$configuredHosts = array_map(
    static fn (array $device): string => (string) ($device['ip'] ?? ''),
    array_filter((array) (dashboard_config()['header_devices'] ?? []), 'is_array')
);
if (!Inventory::isPingTargetAllowed($data, $host, $configuredHosts)) {
    http_response_code(403);
    echo json_encode(['error' => 'The requested host is not in the configured inventory.']);
    exit;
}

$pinger = dashboard_pinger();
$result = $pinger->ping($host);
NetworkUsage::record(dashboard_db(), [$host => $result], dashboard_config(), $pinger->effectiveMethod());
echo json_encode($result, JSON_PRESERVE_ZERO_FRACTION);
