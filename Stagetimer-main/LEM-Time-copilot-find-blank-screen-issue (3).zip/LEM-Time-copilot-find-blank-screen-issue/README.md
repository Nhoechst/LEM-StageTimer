# LEM-Time

## Run locally

Use Node.js 22.13+ (includes the built-in SQLite module; no database package or
separate SQLite installation is needed).

```sh
npm ci
npm run server
```

In a second terminal:

```sh
npm start
```

Open the local URL printed by Vite. Vite forwards `/api` requests to the backend
at `127.0.0.1:3001`. Keep both terminals running. The frontend shows connection
errors with a retry button if the backend is unavailable.

## Production

```sh
npm run build
npm run server
```

Open `http://127.0.0.1:3001`. The backend serves the built `dist/` directory and
the SQLite API from the same origin. Static-only hosting is no longer sufficient:
the Node process needs persistent, writable storage. `npm run preview` can still
preview a build while the backend runs separately.

Built asset URLs are relative, so the same `dist/` can be hosted at the domain
root or in a subdirectory such as `/LEM-Time/`. With a reverse proxy, route
`/api/` to the backend as well as serving the frontend.

## Database and migration

Shows, cues (including their order), branding, display options, messages, and
the configured show-lock PIN are stored in `lem-time.db` beside `server.mjs`.
The PIN is a local UI lock, **not authentication**; do not expose this service
directly to an untrusted network. Protect the database and backups as sensitive
files. The server listens only on loopback by default.

On the first connection to an uninitialized database, the browser imports its
existing `bayer-mock-shows` and `bayer-mock-pin` localStorage values. Invalid show
entries are excluded, valid entries retained, and an intentionally empty list
remains empty. If there are no usable saved shows, demo shows initialize the
database. Original browser values are retained unchanged for recovery; subsequent
connections always use the database, not another browser's localStorage.

Autosaves are serialized and use a database revision to prevent one window from
silently overwriting another. A conflict requires reloading saved data; download
unsaved changes first if needed. Connection/save failures keep the current edits
in memory, show an error, and provide retry/download actions. Wait for “Saved to
database” before closing. Timers advance while the frontend is open, as before;
this is not a server-side timer engine or real-time multi-device synchronization.

## Backups and configuration

The backend keeps a rolling `lem-time.db.bak` snapshot of the previous committed
database before replacing data. Backups must succeed before a save is accepted.
Database files and backups are ignored by Git and are not served over HTTP.
Keep separate periodic copies for longer-term history.

To restore, stop the backend, preserve the current database for diagnosis, replace
`lem-time.db` with a copy of `lem-time.db.bak`, then restart. Never replace a live
database file.

Environment variables for the backend:

- `DB_PATH`: path to the database file (default: repository `lem-time.db`).
- `PORT`: HTTP port (default: `3001`; update the Vite proxy if changed).
- `HOST`: listen address (default: `127.0.0.1`). Use a trusted authenticated reverse
  proxy and TLS before allowing remote access.
- `APP_ORIGIN`: exact trusted browser origin when using that proxy, for example
  `https://timers.example.com` (no path or trailing slash). Set this explicitly;
  other remote origins are rejected.

Run the backend regression suite with `npm test`. It covers validation, atomic
writes, database restarts, backups and backup failures, concurrent revisions,
origin checks, request limits, and private-file protection.

## Startup troubleshooting

If “Loading LEM-Time…” remains visible, check the browser Network tab for failed
JavaScript requests and verify that the backend serves the built `dist/` folder.
The source HTML cannot run directly as a static site.

If “Loading saved shows…” fails, start the backend, check its logs, and confirm
that its data directory is writable. Do not delete browser data to troubleshoot
a connection error. Unexpected render failures show a reload message instead of
a white screen.