import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { constants, lstatSync, openSync, closeSync, readFileSync, renameSync, rmSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { isStatePayload } from './lib/schema.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MAX_BODY = 10 * 1024 * 1024;
const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.webmanifest': 'application/manifest+json',
};

class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

export function createStore(dbPath = process.env.DB_PATH || path.join(ROOT, 'lem-time.db')) {
  const filename = path.resolve(dbPath);
  const db = new DatabaseSync(filename);
  try {
    db.exec(`
      PRAGMA busy_timeout = 5000;
      PRAGMA foreign_keys = ON;
      PRAGMA synchronous = FULL;
      CREATE TABLE IF NOT EXISTS meta (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        revision INTEGER NOT NULL, initialized INTEGER NOT NULL
      );
      INSERT OR IGNORE INTO meta VALUES (1, 0, 0);
      CREATE TABLE IF NOT EXISTS shows (
        id TEXT PRIMARY KEY, position INTEGER NOT NULL, metadata TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS cues (
        show_id TEXT NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
        id TEXT NOT NULL, position INTEGER NOT NULL, data TEXT NOT NULL,
        PRIMARY KEY (show_id, id)
      );
      CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK (id = 1), pin TEXT NOT NULL);
      INSERT OR IGNORE INTO settings VALUES (1, '');
    `);
  } catch (error) {
    db.close();
    throw error;
  }
  const read = () => {
    const meta = db.prepare('SELECT revision, initialized FROM meta WHERE id = 1').get();
    if (!meta.initialized) return { initialized: false, revision: meta.revision };
    const shows = db.prepare('SELECT id, metadata FROM shows ORDER BY position').all().map(row => ({
      ...JSON.parse(row.metadata),
      cues: db.prepare('SELECT data FROM cues WHERE show_id = ? ORDER BY position').all(row.id)
        .map(cue => JSON.parse(cue.data)),
    }));
    return {
      initialized: true, revision: meta.revision, shows,
      settings: { pin: db.prepare('SELECT pin FROM settings WHERE id = 1').get().pin },
    };
  };
  return {
    filename,
    getState() {
      db.exec('BEGIN');
      try {
        const state = read();
        db.exec('COMMIT');
        return state;
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
    saveState(payload) {
      if (!isStatePayload(payload)) throw new HttpError(400, 'Invalid state payload.');
      db.exec('BEGIN IMMEDIATE');
      try {
        const { revision } = db.prepare('SELECT revision FROM meta WHERE id = 1').get();
        if (payload.revision !== revision) {
          throw new HttpError(409, 'State changed. Reload before saving.', { revision });
        }
        if (revision === Number.MAX_SAFE_INTEGER) throw new HttpError(409, 'Revision limit reached.');
        // A separate read connection snapshots the committed state while this writer holds its lock.
        const staging = `${filename}.bak-next`;
        let backupDb;
        try {
          rmSync(staging, { force: true });
          backupDb = new DatabaseSync(filename, { readOnly: true });
          backupDb.prepare('VACUUM INTO ?').run(staging);
          backupDb.close();
          backupDb = undefined;
          renameSync(staging, `${filename}.bak`);
        } finally {
          backupDb?.close();
          rmSync(staging, { force: true });
        }
        db.exec('DELETE FROM cues; DELETE FROM shows;');
        const insertShow = db.prepare('INSERT INTO shows (id, position, metadata) VALUES (?, ?, ?)');
        const insertCue = db.prepare('INSERT INTO cues (show_id, id, position, data) VALUES (?, ?, ?, ?)');
        payload.shows.forEach(({ cues, ...metadata }, position) => {
          insertShow.run(metadata.id, position, JSON.stringify(metadata));
          cues.forEach((cue, cuePosition) => {
            insertCue.run(metadata.id, cue.id, cuePosition, JSON.stringify(cue));
          });
        });
        db.prepare('UPDATE settings SET pin = ? WHERE id = 1').run(payload.settings.pin);
        db.prepare('UPDATE meta SET revision = ?, initialized = 1 WHERE id = 1').run(revision + 1);
        const state = read();
        db.exec('COMMIT');
        return state;
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
    close() { db.close(); },
  };
}

function json(res, status, body, headers = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', 'Content-Length': Buffer.byteLength(data), ...headers,
  });
  res.end(data);
}

function parseAppOrigin(value) {
  if (value === undefined) return null;
  try {
    const origin = new URL(value);
    if (['http:', 'https:'].includes(origin.protocol) && value === origin.origin) return origin;
  } catch {}
  throw new Error('APP_ORIGIN must be an exact normalized http(s) origin.');
}

function allowedOrigin(req, host, appOrigin) {
  try {
    const target = new URL(`http://${req.headers.host}`);
    const publicHost = appOrigin &&
      new URL(`${appOrigin.protocol}//${req.headers.host}`).host === appOrigin.host;
    if (!LOOPBACK.has(target.hostname) && target.hostname !== host && !publicHost) return false;
    if (!req.headers.origin) return null;
    const origin = new URL(req.headers.origin);
    if (req.headers.origin === appOrigin?.origin && (publicHost || LOOPBACK.has(target.hostname))) {
      return origin.origin;
    }
    if (publicHost && !LOOPBACK.has(target.hostname)) return false;
    if (origin.origin !== req.headers.origin || origin.protocol !== 'http:') return false;
    if (origin.host === target.host) return origin.origin;
    if (LOOPBACK.has(origin.hostname) && LOOPBACK.has(target.hostname) &&
        ['5173', '4173'].includes(origin.port)) return origin.origin;
  } catch {}
  return false;
}

function readPayload(req) {
  if (req.headers['content-type']?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new HttpError(415, 'Content-Type must be application/json.');
  }
  if (Number(req.headers['content-length']) > MAX_BODY) {
    req.resume();
    throw new HttpError(413, 'Payload too large.');
  }
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    const cleanup = () => {
      req.off('data', onData);
      req.off('end', onEnd);
      req.off('error', onError);
      req.off('aborted', onAborted);
    };
    const fail = error => { cleanup(); req.resume(); reject(error); };
    const onError = () => fail(new HttpError(400, 'Unable to read request.'));
    const onAborted = () => fail(new HttpError(400, 'Request aborted.'));
    const onData = chunk => {
      size += chunk.length;
      if (size > MAX_BODY) return fail(new HttpError(413, 'Payload too large.'));
      chunks.push(chunk);
    };
    const onEnd = () => {
      cleanup();
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch {
        reject(new HttpError(400, 'Malformed JSON.'));
      }
    };
    req.on('data', onData);
    req.on('end', onEnd);
    req.on('error', onError);
    req.on('aborted', onAborted);
  });
}

function staticFile(req, res, distDir, dbFilename) {
  let pathname;
  try {
    pathname = decodeURIComponent(req.url.split('?', 1)[0]);
  } catch {
    throw new HttpError(400, 'Invalid path.');
  }
  const segments = pathname.split('/').filter(Boolean);
  if (pathname.includes('\\') || pathname.includes('\0') ||
      segments.some(segment => segment.startsWith('.'))) throw new HttpError(404, 'Not found.');
  const root = path.resolve(distDir);
  const inspect = parts => {
    let file = root;
    if (!lstatSync(root).isDirectory() || lstatSync(root).isSymbolicLink()) return null;
    for (const part of parts) {
      file = path.join(file, part);
      if (lstatSync(file).isSymbolicLink()) return null;
    }
    if (!lstatSync(file).isFile() || !MIME[path.extname(file).toLowerCase()]) return null;
    if ([dbFilename, `${dbFilename}.bak`, `${dbFilename}.bak-next`].includes(file)) return null;
    return file;
  };
  let file;
  try { file = inspect(segments.length ? segments : ['index.html']); } catch (error) {
    if (!['ENOENT', 'ENOTDIR'].includes(error.code)) throw error;
  }
  if (!file && !path.extname(pathname) && (req.headers.accept || '').includes('text/html')) {
    try { file = inspect(['index.html']); } catch (error) {
      if (!['ENOENT', 'ENOTDIR'].includes(error.code)) throw error;
    }
  }
  if (!file) throw new HttpError(404, 'Not found.');
  const fd = openSync(file, constants.O_RDONLY | constants.O_NOFOLLOW);
  let data;
  try { data = readFileSync(fd); } finally { closeSync(fd); }
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(file).toLowerCase()],
    'Content-Length': data.length, 'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-cache',
  });
  res.end(req.method === 'HEAD' ? undefined : data);
}

export function createServer({
  dbPath = process.env.DB_PATH || path.join(ROOT, 'lem-time.db'),
  distDir = path.join(ROOT, 'dist'),
  host = process.env.HOST || '127.0.0.1',
  appOrigin = process.env.APP_ORIGIN,
  store,
} = {}) {
  const publicOrigin = parseAppOrigin(appOrigin);
  store ??= createStore(dbPath);
  const server = http.createServer(async (req, res) => {
    req.on('error', () => {});
    try {
      let pathname;
      try { pathname = decodeURIComponent(req.url.split('?', 1)[0]); } catch {
        throw new HttpError(400, 'Invalid path.');
      }
      if (pathname === '/api' || pathname.startsWith('/api/')) {
        const origin = allowedOrigin(req, host, publicOrigin);
        if (origin === false) throw new HttpError(403, 'Origin not allowed.');
        if (origin) {
          res.setHeader('Access-Control-Allow-Origin', origin);
          res.setHeader('Vary', 'Origin');
        }
        if (pathname !== '/api/state') throw new HttpError(404, 'API endpoint not found.');
        if (req.method === 'OPTIONS') {
          res.writeHead(204, {
            'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type', 'Cache-Control': 'no-store',
          });
          res.end();
        } else if (req.method === 'GET') {
          json(res, 200, store.getState());
        } else if (req.method === 'PUT') {
          json(res, 200, store.saveState(await readPayload(req)));
        } else {
          json(res, 405, { error: 'Method not allowed.' }, { Allow: 'GET, PUT, OPTIONS' });
        }
      } else {
        if (!['GET', 'HEAD'].includes(req.method)) {
          throw new HttpError(405, 'Method not allowed.');
        }
        staticFile(req, res, distDir, store.filename);
      }
    } catch (error) {
      if (!res.headersSent && !res.destroyed) {
        json(res, error instanceof HttpError ? error.status : 500, {
          error: error instanceof HttpError ? error.message : 'Unable to complete request.',
          ...(error instanceof HttpError ? error.extra : {}),
        });
      } else if (!res.destroyed) res.end();
    }
  });
  server.on('close', () => store.close());
  server.store = store;
  return server;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const host = process.env.HOST || '127.0.0.1';
  const port = Number(process.env.PORT || 3001);
  try {
    if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid port');
    const server = createServer({ host });
    server.on('error', () => {
      console.error('Unable to start LEM-Time backend.');
      server.store.close();
      process.exitCode = 1;
    });
    server.listen(port, host, () => {
      console.log(`LEM-Time backend listening on http://${host}:${server.address().port}`);
    });
    for (const signal of ['SIGINT', 'SIGTERM']) {
      process.once(signal, () => server.close());
    }
  } catch {
    console.error('Unable to start LEM-Time backend.');
    process.exitCode = 1;
  }
}
