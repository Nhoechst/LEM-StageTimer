import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  server: {
    proxy: { '/api': 'http://127.0.0.1:3001' },
    fs: { deny: ['.env', '.env.*', '*.{crt,pem}', '**/.git/**', '**/*.db', '**/*.db-*', '**/*.db.*'] },
  },
  preview: {
    proxy: { '/api': 'http://127.0.0.1:3001' },
  },
});
