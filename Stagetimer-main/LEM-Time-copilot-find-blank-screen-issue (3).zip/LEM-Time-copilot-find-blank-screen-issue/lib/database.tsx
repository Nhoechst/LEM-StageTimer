import { createContext, useContext, useEffect, useRef, useState } from 'react';
import type { Dispatch, ReactNode, SetStateAction } from 'react';
import type { Show } from '../data';
import { INITIAL_SHOWS } from '../data';
import { readShows } from './shows';
import { isStatePayload } from './schema.js';

type Data = { shows: Show[]; settings: { pin: string } };
type DatabaseContextValue = {
  shows: Show[];
  setShows: Dispatch<SetStateAction<Show[]>>;
  pin: string;
  setPin: Dispatch<SetStateAction<string>>;
  status: string;
};
const DatabaseContext = createContext<DatabaseContextValue | null>(null);

export function useDatabase() {
  const value = useContext(DatabaseContext);
  if (!value) throw new Error('Database provider is missing');
  return value;
}

export function DatabaseStatus() {
  return <span role="status" className="text-xs text-slate-500">{useDatabase().status}</span>;
}

class DatabaseError extends Error {
  constructor(message: string, public conflict = false) {
    super(message);
  }
}

async function requestState(payload?: Data & { revision: number }) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch('/api/state', {
      method: payload ? 'PUT' : 'GET',
      headers: payload ? { 'Content-Type': 'application/json' } : undefined,
      body: payload ? JSON.stringify(payload) : undefined,
      signal: controller.signal,
      cache: 'no-store',
    });
    if (response.status === 409) {
      throw new DatabaseError('The database changed in another window. Reload to use the latest saved data.', true);
    }
    if (!response.ok) throw new DatabaseError(`Database request failed (${response.status}). Check that the backend is running and its data folder is writable.`);
    const result = await response.json();
    if (!Number.isSafeInteger(result.revision) || result.revision < 0 ||
        typeof result.initialized !== 'boolean' ||
        (result.initialized && !isStatePayload(result))) {
      throw new DatabaseError('The database returned invalid data. Your browser data has not been cleared.');
    }
    return result as Data & { initialized: boolean; revision: number };
  } catch (error) {
    if (error instanceof DatabaseError) throw error;
    throw new DatabaseError('Cannot connect to the database. Start the backend with npm run server, then retry.');
  } finally {
    window.clearTimeout(timeout);
  }
}

function migrationData(): Data {
  let pin = '';
  try {
    const stored = localStorage.getItem('bayer-mock-pin') || '';
    if (/^\d{4,6}$/.test(stored)) pin = stored;
  } catch {}
  return { shows: readShows(INITIAL_SHOWS), settings: { pin } };
}

export function DatabaseProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Data>({ shows: [], settings: { pin: '' } });
  const [loaded, setLoaded] = useState(false);
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [saveAttempt, setSaveAttempt] = useState(0);
  const [error, setError] = useState('');
  const [conflict, setConflict] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const revision = useRef(0);
  const saved = useRef('');
  const latest = useRef(data);
  const inFlight = useRef(false);
  const blocked = useRef(false);
  latest.current = data;

  useEffect(() => {
    let cancelled = false;
    setError('');
    const load = async () => {
      try {
        let remote = await requestState();
        if (cancelled) return;
        if (!remote.initialized) {
          try {
            remote = await requestState({ ...migrationData(), revision: remote.revision });
          } catch (failure) {
            if (!(failure instanceof DatabaseError) || !failure.conflict) throw failure;
            remote = await requestState();
          }
        }
        if (cancelled) return;
        const next = { shows: remote.shows, settings: remote.settings };
        revision.current = remote.revision;
        saved.current = JSON.stringify(next);
        setData(next);
        setLoaded(true);
      } catch (failure) {
        if (!cancelled) setError((failure as Error).message);
      }
    };
    void load();
    return () => { cancelled = true; };
  }, [loadAttempt]);

  useEffect(() => {
    if (!loaded) return;
    const changed = JSON.stringify(data) !== saved.current;
    setDirty(changed);
    if (!changed || inFlight.current || blocked.current) return;
    const timer = window.setTimeout(async () => {
      const snapshot = latest.current;
      inFlight.current = true;
      setSaving(true);
      try {
        const remote = await requestState({ ...snapshot, revision: revision.current });
        revision.current = remote.revision;
        saved.current = JSON.stringify(snapshot);
        setError('');
      } catch (failure) {
        blocked.current = true;
        setConflict(failure instanceof DatabaseError && failure.conflict);
        setError((failure as Error).message);
      } finally {
        inFlight.current = false;
        setSaving(false);
        setSaveAttempt(attempt => attempt + 1);
      }
    }, 200);
    return () => window.clearTimeout(timer);
  }, [data, loaded, saveAttempt]);

  useEffect(() => {
    if (!dirty && !saving) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty, saving]);

  const retry = () => {
    if (!loaded) setLoadAttempt(attempt => attempt + 1);
    else {
      blocked.current = false;
      setSaveAttempt(attempt => attempt + 1);
    }
  };
  const download = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(latest.current, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'lem-time-unsaved.json';
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  if (!loaded) {
    return <main className="mx-auto max-w-lg p-8">
      <h1>LEM-Time database</h1>
      {error ? <><p role="alert" className="my-4">{error}</p><button onClick={retry}>Retry connection</button></> :
        <p role="status">Loading saved shows…</p>}
    </main>;
  }
  return <DatabaseContext.Provider value={{
    shows: data.shows,
    setShows: update => setData(current => ({ ...current, shows: typeof update === 'function' ? update(current.shows) : update })),
    pin: data.settings.pin,
    setPin: update => setData(current => ({ ...current, settings: { pin: typeof update === 'function' ? update(current.settings.pin) : update } })),
    status: saving || dirty ? 'Saving to database…' : 'Saved to database',
  }}>
    {error ? <aside role="alert" className="sticky top-0 z-[60] border-b border-red-300 bg-red-50 p-3 text-red-900">
      <p>{error} Changes in this window are not saved.</p>
      <div className="mt-2 flex gap-4">
        {!conflict && <button onClick={retry}>Retry save</button>}
        <button onClick={download}>Download unsaved data</button>
        {conflict && <button onClick={() => window.location.reload()}>Reload saved data</button>}
      </div>
    </aside> : null}
    {children}
  </DatabaseContext.Provider>;
}
