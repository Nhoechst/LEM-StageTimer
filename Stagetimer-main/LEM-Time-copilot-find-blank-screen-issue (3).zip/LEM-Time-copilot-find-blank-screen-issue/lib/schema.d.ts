import type { Show } from '../data';

export type StatePayload = {
  revision: number;
  shows: Show[];
  settings: { pin: string };
};

export function isShow(value: unknown): value is Show;
export function isStatePayload(value: unknown): value is StatePayload;
